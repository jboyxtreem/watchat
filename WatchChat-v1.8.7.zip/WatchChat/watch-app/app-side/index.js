import { BaseSideService, settingsLib } from '@zeppos/zml/base-side'

function parseBody(response) {
  const body = response && response.body
  if (typeof body === 'string') {
    try { return JSON.parse(body) }
    catch (e) {
      const status = response && response.status ? ' (HTTP ' + response.status + ')' : ''
      throw new Error('Bridge returned a non-JSON response' + status + ': ' + body.slice(0, 90).replace(/\s+/g, ' '))
    }
  }
  return body || {}
}

function getConnection() {
  const url = String(settingsLib.getItem('bridgeUrl') || '').trim().replace(/\/+$/, '')
  const key = String(settingsLib.getItem('bridgeKey') || '').trim()
  if (!url || !key) throw new Error('Open WatchChat settings in the Zepp phone app and enter the bridge URL and key.')
  if (!/^https:\/\//i.test(url)) throw new Error('Bridge URL must start with https://')
  return { url, key }
}

async function callBridge(path, method, body) {
  const connection = getConnection()
  const options = {
    url: connection.url + path,
    method: method || 'GET',
    headers: {
      'X-WatchChat-Key': connection.key,
      'ngrok-skip-browser-warning': '1',
      'X-WatchChat-Client': 'zepp-watch'
    }
  }
  if (body !== undefined) {
    options.headers['Content-Type'] = 'application/json'
    options.body = JSON.stringify(body)
  }
  let response
  console.log('[WatchChat] PC target: ' + connection.url)
  console.log('[WatchChat] Requesting ' + method + ' ' + path)
  try {
    response = await fetch(options)
  } catch (error) {
    const detail = String(error && error.message ? error.message : error).slice(0, 120)
    console.log('[WatchChat] Fetch failed before an HTTP response: ' + detail)
    throw new Error('Phone could not contact the PC tunnel. Check the Bridge URL, phone internet connection and ngrok status. Details: ' + detail)
  }
  if (!response || !response.status) throw new Error('The phone network service returned no HTTP status. Reinstall/update WatchChat and inspect Side Service logs.')
  const data = parseBody(response)
  if (response && response.status && response.status >= 400) {
    throw new Error(data.error || ('PC bridge returned HTTP ' + response.status))
  }
  console.log('[WatchChat] PC bridge responded HTTP ' + (response && response.status ? response.status : 'unknown'))
  if (data && data.error) throw new Error(data.error)
  return data
}

// The watch only draws a short preview; full last-message text can be thousands of characters.
const slimChat = (c) => ({
  id: c.id, title: c.title, network: c.network, unreadCount: c.unreadCount,
  preview: Array.from(String(c.preview || '').replace(/\s+/g, ' ').trim()).slice(0, 80).join(''),
  ts: c.ts, isGroup: c.isGroup
})

const chatParam = (params) => {
  const id = String((params && params.chatId) || '')
  if (!id) throw new Error('Missing conversation ID.')
  return id
}


const DEFAULT_NOTIFICATION_POLL_MS = 10000
const NOTIFICATION_POLL_OPTIONS = [10000, 15000, 20000, 30000]
const NOTIFICATION_ENABLED_KEY = 'watchchatNotificationsEnabled'
const NOTIFICATION_POLL_KEY = 'watchchatNotificationPollMs'
const NOTIFICATION_QUEUE_KEY = 'watchchatNotificationQueue'
const NOTIFICATION_CURSOR_KEY = 'watchchatNotificationCursor'
const NOTIFICATION_SESSION_KEY = 'watchchatNotificationSession'

function readNotificationSettings() {
  const rawEnabled = settingsLib.getItem(NOTIFICATION_ENABLED_KEY)
  const rawInterval = Number(settingsLib.getItem(NOTIFICATION_POLL_KEY))
  return {
    enabled: rawEnabled === null || rawEnabled === undefined ? true : String(rawEnabled) !== '0',
    pollMs: NOTIFICATION_POLL_OPTIONS.includes(rawInterval) ? rawInterval : DEFAULT_NOTIFICATION_POLL_MS
  }
}

function readNotificationQueue() {
  try {
    const raw = settingsLib.getItem(NOTIFICATION_QUEUE_KEY)
    const value = typeof raw === 'string' ? JSON.parse(raw || '[]') : raw
    return Array.isArray(value) ? value : []
  } catch (error) { return [] }
}

function writeNotificationQueue(items) {
  try { settingsLib.setItem(NOTIFICATION_QUEUE_KEY, JSON.stringify(items.slice(-60))) }
  catch (error) { console.log('[WatchChat] Could not persist notification queue: ' + String(error && error.message ? error.message : error)) }
}

AppSideService(
  BaseSideService({
    onInit() {},
    onRun() {
      this.startNotificationPolling()
    },
    startNotificationPolling() {
      if (this._notificationTimer) { clearInterval(this._notificationTimer); this._notificationTimer = null }
      const config = readNotificationSettings()
      if (!config.enabled) return
      this._notificationTimer = setInterval(() => this.pollNotifications(), config.pollMs)
      this.pollNotifications()
    },
    async pollNotifications() {
      if (this._notificationPolling || !readNotificationSettings().enabled) return
      this._notificationPolling = true
      this._lastPoll = Date.now()
      try {
        const cursor = Math.max(0, Number(settingsLib.getItem(NOTIFICATION_CURSOR_KEY)) || 0)
        const session = String(settingsLib.getItem(NOTIFICATION_SESSION_KEY) || '')
        const result = await callBridge(
          '/notifications?after=' + cursor + '&session=' + encodeURIComponent(session),
          'GET'
        )
        // A settings change may happen while the network request is in flight.
        // Respect the latest toggle before persisting or forwarding any alerts.
        if (!readNotificationSettings().enabled) return
        const pending = readNotificationQueue()
        const ids = new Set(pending.map((item) => String(item.id || '')))
        const events = Array.isArray(result.items) ? result.items : []
        events.forEach((item) => {
          if (!item || !item.id || ids.has(String(item.id))) return
          pending.push(item)
          ids.add(String(item.id))
        })
        writeNotificationQueue(pending)
        if (result.session) settingsLib.setItem(NOTIFICATION_SESSION_KEY, String(result.session))
        if (Number.isFinite(Number(result.cursor))) settingsLib.setItem(NOTIFICATION_CURSOR_KEY, String(result.cursor))

        // This is the fast path while a WatchChat device page is connected.
        // The persisted queue is also returned to the watch on its next request.
        events.forEach((item) => {
          try {
            const sent = this.call({ method: 'WATCHCHAT_NOTIFICATION', params: item })
            if (sent && typeof sent.catch === 'function') {
              sent.catch((error) => console.log('[WatchChat] Live notification send failed: ' + String(error && error.message ? error.message : error)))
            }
          } catch (error) {
            console.log('[WatchChat] Live notification send failed: ' + String(error && error.message ? error.message : error))
          }
        })
      } catch (error) {
        const message = String(error && error.message ? error.message : error)
        if (!/Bridge URL|Bridge key|https:\/\//i.test(message)) console.log('[WatchChat] Notification poll failed: ' + message)
      } finally {
        this._notificationPolling = false
      }
    },
    async onRequest(req, res) {
      console.log('[WatchChat] Watch request received: ' + String(req && req.method || 'unknown'))
      try {
        const params = req.params || {}
        let result
        if (req.method === 'GET_NOTIFICATION_SETTINGS') {
          result = readNotificationSettings()
        } else if (req.method === 'SET_NOTIFICATION_SETTINGS') {
          const current = readNotificationSettings()
          const enabled = params.enabled === undefined ? current.enabled : params.enabled !== false
          const requestedInterval = Number(params.pollMs)
          const pollMs = NOTIFICATION_POLL_OPTIONS.includes(requestedInterval) ? requestedInterval : current.pollMs
          settingsLib.setItem(NOTIFICATION_ENABLED_KEY, enabled ? '1' : '0')
          settingsLib.setItem(NOTIFICATION_POLL_KEY, String(pollMs))
          if (!enabled) writeNotificationQueue([])
          this.startNotificationPolling()
          result = { enabled, pollMs }
        } else if (req.method === 'PING') {
          result = await callBridge('/health', 'GET')
        } else if (req.method === 'GET_NOTIFICATIONS') {
          // The phone-side poller is the fast path. The watch background service
          // asks for the persisted queue occasionally when WatchChat is closed.
          if (!readNotificationSettings().enabled) {
            result = { items: [] }
          } else {
            if (Date.now() - (this._lastPoll || 0) > 8000) await this.pollNotifications()
            result = { items: readNotificationQueue() }
          }
        } else if (req.method === 'ACK_NOTIFICATIONS') {
          const ids = new Set((Array.isArray(params.ids) ? params.ids : []).map((id) => String(id)))
          const pending = readNotificationQueue().filter((item) => !ids.has(String(item.id || '')))
          writeNotificationQueue(pending)
          result = { acknowledged: ids.size, remaining: pending.length }
        } else if (req.method === 'LIST_CHATS') {
          const limit = Math.min(100, Math.max(1, Number(params.limit) || 100))
          const offset = Math.max(0, Number(params.offset) || 0)
          result = await callBridge('/chats?limit=' + limit + '&offset=' + offset, 'GET')
          if (result && Array.isArray(result.items)) result.items = result.items.map(slimChat)
        } else if (req.method === 'LIST_CONTACTS') {
          const limit = Math.min(100, Math.max(1, Number(params.limit) || 100))
          const query = String(params.query || '').trim()
          const cursor = String(params.cursor || '')
          let path = '/contacts?limit=' + limit
          if (query) path += '&query=' + encodeURIComponent(query)
          else if (cursor) path += '&cursor=' + encodeURIComponent(cursor)
          result = await callBridge(path, 'GET')
        } else if (req.method === 'START_CHAT') {
          const accountID = String(params.accountID || '')
          const user = params.user && typeof params.user === 'object' ? params.user : {}
          result = await callBridge('/start-chat', 'POST', { accountID, user })
        } else if (req.method === 'GET_MESSAGES') {
          const limit = Math.min(100, Math.max(1, Number(params.limit) || 20))
          const offset = Math.max(0, Number(params.offset) || 0)
          result = await callBridge(
            '/messages?chat_id=' + encodeURIComponent(chatParam(params)) +
            '&limit=' + limit + '&offset=' + offset + (params.read ? '&read=1' : ''),
            'GET'
          )
        } else if (req.method === 'LOAD_OLDER') {
          const count = Math.min(100, Math.max(1, Number(params.count) || 50))
          result = await callBridge('/history', 'POST', { chat_id: chatParam(params), count })
        } else if (req.method === 'SEND_MESSAGE') {
          const text = String(params.text || '').trim()
          if (!text) throw new Error('Message cannot be empty.')
          result = await callBridge('/send', 'POST', { chat_id: chatParam(params), text })
        } else if (req.method === 'REFRESH_MESSAGE') {
          const messageId = String(params.messageId || '')
          if (!messageId) throw new Error('Missing message ID.')
          result = await callBridge('/message?chat_id=' + encodeURIComponent(chatParam(params)) + '&message_id=' + encodeURIComponent(messageId), 'GET')
        } else if (req.method === 'REACT_MESSAGE') {
          const messageId = String(params.messageId || '')
          const reactionKey = String(params.reactionKey || '').trim()
          if (!messageId || !reactionKey) throw new Error('Message and reaction are required.')
          result = await callBridge('/react', 'POST', { chat_id: chatParam(params), message_id: messageId, reaction_key: reactionKey })
        } else if (req.method === 'REMOVE_REACTION') {
          const messageId = String(params.messageId || '')
          const reactionKey = String(params.reactionKey || '').trim()
          if (!messageId || !reactionKey) throw new Error('Message and reaction are required.')
          result = await callBridge('/unreact', 'POST', { chat_id: chatParam(params), message_id: messageId, reaction_key: reactionKey })
        } else {
          throw new Error('Unknown WatchChat request: ' + String(req.method || ''))
        }
        res(null, { result })
      } catch (error) {
        const detail = String(error && error.message ? error.message : error)
        console.log('[WatchChat] Request failed: ' + detail)
        res(null, { error: detail })
      }
    },
    onSettingsChange() {},
    onDestroy() { if (this._notificationTimer) { clearInterval(this._notificationTimer); this._notificationTimer = null } }
  })
)
