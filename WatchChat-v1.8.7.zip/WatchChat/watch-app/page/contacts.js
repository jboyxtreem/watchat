import { back as routerBack, push, replace } from '@zos/router'
import * as hmUI from '@zos/ui'
import { SCROLL_LIST, setStatusBarVisible } from '@zos/ui'
import { px } from '@zos/utils'
import { py } from '../lib/ui'
import { onGesture } from '@zos/interaction'
import { BasePage } from '@zeppos/zml/base-page'
import { D as C, CENTER, clip, rect, text, appButton as button, clear } from '../lib/ui'
import { appendUniqueBy, shouldPrefetch, pageCanContinue } from '../lib/paging'
import { handleNotificationCall, handlePendingNotifications } from '../lib/notifications'

const PAGE_SIZE = 100
const PREFETCH_ROWS = 15
const MORE_ROW = 9
const PAD_ROW = 10
const HEAD_ROW = 11
const HEAD_H = 74
const LIST_TOP = 0
const LIST_HEIGHT = 480


function tv(x, y, w, h, key, color, size, action) {
  const v = { x: px(x), y: py(y), w: px(w), h: py(h), key, color, text_size: px(size) }
  if (action) v.action = true
  return v
}

// Native rounded rows (no PNG surfaces): lighter on the watch and wider than
// before - the list now spans almost the full width of the screen.
function makeConfig() {
  return [
    { type_id: 1, item_height: py(84), item_bg_color: 0x1a1b21, item_bg_radius: py(28),
      text_view: [
        tv(26, 10, 400, 36, 'name', 0xffffff, 26, true),
        tv(26, 48, 400, 28, 'detail', 0x9a9ca6, 19, true)
      ], text_view_count: 2 },
    { type_id: HEAD_ROW, item_height: py(112), item_bg_color: 0x000000, item_bg_radius: 0,
      text_view: [tv(95, 28, 290, 40, 'head', 0xffffff, 34), tv(95, 69, 290, 25, 'sub', 0x80828c, 18)], text_view_count: 2 },
    { type_id: MORE_ROW, item_height: py(72), item_bg_color: 0x1b3a5c, item_bg_radius: py(36),
      text_view: [tv(130, 18, 220, 34, 'more', 0xffffff, 24, true)], text_view_count: 1 },
    { type_id: PAD_ROW, item_height: py(90), item_bg_color: 0x000000, item_bg_radius: 0,
      text_view: [tv(0, 0, 10, 10, 'gap', 0x000000, 12)], text_view_count: 1 }
  ]
}

function makeData(contacts, hasMore, loadingMore) {
  const rows = [{ type: HEAD_ROW, data: { head: 'Contacts', sub: contacts.length ? contacts.length + (hasMore ? '+' : '') + ' people' : '' } }]
  contacts.forEach((contact) => rows.push({
    type: 1,
    data: {
      name: clip(contact.fullName || contact.name || contact.username || contact.phoneNumber || 'WhatsApp contact', 24),
      detail: clip(contact.phoneNumber || contact.username || contact.email || (contact.cannotMessage ? 'Unavailable on WhatsApp' : 'WhatsApp contact'), 34),
    }
  }))
  if (hasMore) rows.push({ type: MORE_ROW, data: { more: loadingMore ? 'Loading…' : 'Load more' } })
  rows.push({ type: PAD_ROW, data: { gap: '' } })
  const array = []
  const ranges = []
  let start = 0
  let previous = null
  rows.forEach((row, index) => {
    array.push(row.data)
    if (previous !== null && previous !== row.type) {
      ranges.push({ start, end: index - 1, type_id: previous })
      start = index
    }
    previous = row.type
  })
  if (previous !== null) ranges.push({ start, end: rows.length - 1, type_id: previous })
  return { array, ranges }
}

Page(
  BasePage({
    state: {
      widgets: [], list: null, contacts: [], cursor: '', hasMore: false,
      loading: false, loadingMore: false, starting: false, error: '',
      query: '', total: 0, built: false, autoCursor: ''
    },

    onInit() {
      try { onGesture({ callback: () => false }) } catch (e) {}
      this.notificationTimer = null
    },

    build() {
      try { setStatusBarVisible(false) } catch (e) {}
      this.state.built = true
      this.render()
      this.loadContacts('', '')
    },

    onDestroy() {
      this.killList()
      clear(this.state.widgets)
    },

    onCall(data) {
      handleNotificationCall(data, (request) => this.request(request))
    },

    fetchPendingNotifications() {
      this.request({ method: 'GET_NOTIFICATIONS', params: {} })
        .then((response) => handlePendingNotifications(response, (request) => this.request(request)))
        .catch(() => {})
    },

    killList() {
      if (this.state.list) { try { hmUI.deleteWidget(this.state.list) } catch (e) {} }
      this.state.list = null
    },

    updateList() {
      const s = this.state
      if (!s.list) { this.render(); return }
      const d = makeData(s.contacts, s.hasMore, s.loadingMore)
      try {
        s.list.setProperty(hmUI.prop.UPDATE_DATA, {
          data_type_config: d.ranges, data_type_config_count: d.ranges.length,
          data_array: d.array, data_count: d.array.length, on_page: 1
        })
      } catch (error) {
        console.log('[WatchChat] Contact list in-place update failed; rebuilding once: ' + String(error && error.message ? error.message : error))
        this.killList()
        this.render()
      }
    },

    render(viewIndex) {
      const s = this.state
      this.killList()
      clear(s.widgets)
      const w = s.widgets
      // Full-screen WhatsApp-inspired contact directory. No top colour bar;
      // the list begins close to the title and uses solid rounded rows.
      rect(w, 0, 0, 480, 480, 0x000000, 0)

      if (s.error && !s.contacts.length) {
        this.header()
        text(w, 92, 182, 296, 48, 'Could not load contacts', 18, C.text, CENTER)
        text(w, 96, 230, 288, 76, clip(s.error, 120), 11, C.sub, CENTER, true)
        button(w, 142, 330, 196, 40, 'TRY AGAIN', 11, () => this.loadContacts(s.query, ''), C.accent, 0xffffff)
        return
      }
      if (!s.loading && !s.contacts.length) {
        this.header()
        text(w, 100, 190, 280, 45, 'No contacts available', 18, C.text, CENTER)
        text(w, 106, 235, 268, 52, 'Connect WhatsApp in Beeper Desktop.', 11, C.sub, CENTER, true)
        button(w, 142, 318, 196, 40, 'RETRY', 11, () => this.loadContacts('', ''), C.accent, 0xffffff)
        return
      }
      if (s.loading && !s.contacts.length) {
        this.header()
        text(w, 105, 202, 270, 48, 'Loading contacts…', 17, C.text, CENTER)
        return
      }
      const d = makeData(s.contacts, s.hasMore, s.loadingMore)
      const cfg = makeConfig()
      s.list = hmUI.createWidget(hmUI.widget.SCROLL_LIST, {
        x: px(10), y: py(LIST_TOP), w: px(460), h: py(LIST_HEIGHT), item_space: py(10),
        item_config: cfg, item_config_count: cfg.length,
        data_array: d.array, data_count: d.array.length,
        data_type_config: d.ranges, data_type_config_count: d.ranges.length,
        enable_scroll_bar: false,
        item_click_func: (list, index) => {
          if (index === s.contacts.length + 1 && s.hasMore) this.loadMore(false)
          else if (index >= 1 && index <= s.contacts.length) this.openContact(s.contacts[index - 1])
        },
        item_focus_change_func: (list, index, focus) => this.onFocus(index, focus)
      })
      this.header()
    },

    header() {},

    back() {
      try { routerBack() }
      catch (error) {
        try { replace({ url: 'page/index' }) }
        catch (e) { hmUI.showToast({ text: 'Return to WatchChat from the app list' }) }
      }
    },

    loadContacts(query, cursor) {
      const s = this.state
      if (s.loading || s.loadingMore) return
      const search = ''
      s.query = ''
      s.loading = true
      s.error = ''
      if (!cursor) {
        s.contacts = []
        s.cursor = ''
        s.hasMore = false
        s.total = 0
      }
      this.render()
      this.request({ method: 'LIST_CONTACTS', params: { limit: PAGE_SIZE, cursor: cursor || '', query: search } })
        .then(({ result, error }) => {
          if (error) throw new Error(error)
          const data = result || {}
          const items = Array.isArray(data) ? data : (data.items || [])
          s.contacts = items.slice()
          s.cursor = String(data.nextCursor || data.oldestCursor || '')
          s.autoCursor = ''
          s.hasMore = !!data.hasMore && !!s.cursor
          s.total = Number(data.total) || s.contacts.length
          s.loading = false
          s.error = ''
          this.render()
        })
        .catch((error) => {
          s.loading = false
          s.error = String(error && error.message ? error.message : error)
          this.render()
        })
    },

    loadMore(automatic) {
      const s = this.state
      const cursor = s.cursor
      if (s.loading || s.loadingMore || !s.hasMore || !cursor) return
      if (automatic && s.autoCursor === cursor) return
      if (automatic) s.autoCursor = cursor
      s.loadingMore = true
      this.updateList()
      this.request({ method: 'LIST_CONTACTS', params: { limit: PAGE_SIZE, cursor, query: '' } })
        .then(({ result, error }) => {
          if (error) throw new Error(error)
          const data = result || {}
          const items = Array.isArray(data) ? data : (data.items || [])
          const added = appendUniqueBy(s.contacts, items, (contact) => contact && contact.id
            ? String(contact.accountID || '') + '|' + String(contact.id) : '')
          const next = String(data.nextCursor || data.oldestCursor || '')
          s.cursor = next
          s.hasMore = pageCanContinue(data.hasMore, !!next && next !== cursor, items.length)
          s.total = Number(data.total) || s.contacts.length
          s.loadingMore = false
          if (!added && items.length) console.log('[WatchChat] Duplicate-only contact page; cursor advanced.')
          this.updateList()
        })
        .catch((error) => {
          s.loadingMore = false
          s.autoCursor = ''
          hmUI.showToast({ text: String(error && error.message ? error.message : error).slice(0, 55) })
          this.updateList()
        })
    },

    onFocus(index, focus) {
      const s = this.state
      if (!focus || s.query || s.loading || s.loadingMore || !s.hasMore || !s.cursor) return
      if (shouldPrefetch(index - 1, s.contacts.length, PREFETCH_ROWS) && s.autoCursor !== s.cursor) {
        console.log('[WatchChat] Contact prefetch threshold reached at row ' + index + ' of ' + s.contacts.length)
        this.loadMore(true)
      }
    },

    openContact(contact) {
      const s = this.state
      if (!contact || s.starting) return
      if (contact.cannotMessage) {
        hmUI.showToast({ text: 'This contact cannot be messaged on WhatsApp' })
        return
      }
      s.starting = true
      hmUI.showToast({ text: 'Opening conversation…' })
      const user = {
        id: contact.id,
        fullName: contact.fullName || contact.name || '',
        phoneNumber: contact.phoneNumber || '',
        username: contact.username || '',
        email: contact.email || ''
      }
      this.request({ method: 'START_CHAT', params: { accountID: contact.accountID, user } })
        .then(({ result, error }) => {
          if (error) throw new Error(error)
          const chat = result && (result.chat || result)
          const chatId = String(chat && (chat.id || chat.chatID) || '')
          if (!chatId) throw new Error('Beeper did not return a conversation ID.')
          s.starting = false
          push({
            url: 'page/chat',
            params: JSON.stringify({ chatId, title: String(chat.title || user.fullName || 'Conversation'), network: 'WhatsApp', isGroup: false })
          })
        })
        .catch((error) => {
          s.starting = false
          hmUI.showToast({ text: String(error && error.message ? error.message : error).slice(0, 60) })
        })
    }
  })
)
