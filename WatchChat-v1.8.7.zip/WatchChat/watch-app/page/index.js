import * as hmUI from '@zos/ui'
import { getTextLayout } from '@zos/ui'
import { px } from '@zos/utils'
import { push } from '@zos/router'
import { onGesture, GESTURE_LEFT } from '@zos/interaction'
import { BasePage } from '@zeppos/zml/base-page'
import { handleNotificationCall, handlePendingNotifications } from '../lib/notifications'
import { ensureNotifyService } from '../lib/service'

// ---- item types -----------------------------------------------------------
const T = { CHAT: 1, UNREAD: 5, HEAD: 2, FOOT: 3, GAP: 4, INFO: 6, ERR: 7 }

function tv(x, y, w, h, key, color, size, action) {
  const view = { x: px(x), y: px(y), w: px(w), h: px(h), key, color, text_size: px(size) }
  if (action) view.action = true
  return view
}

function chatType(id, bg) {
  return {
    type_id: id,
    item_height: px(96),
    item_bg_color: bg,
    item_bg_radius: px(26),
    text_view: [
      tv(24, 10, 280, 36, 'title', 0xffffff, 26, true),
      tv(318, 14, 90, 28, 'time', 0x80828c, 18, true),
      tv(24, 52, 290, 30, 'preview', 0x9a9ca6, 20, true),
      tv(326, 50, 84, 30, 'badge', 0x3ddc84, 22, true)
    ],
    text_view_count: 4
  }
}

const ITEM_CONFIG = [
  chatType(T.CHAT, 0x1a1b21),
  chatType(T.UNREAD, 0x13322a),
  {
    type_id: T.HEAD, item_height: px(112), item_bg_color: 0x000000, item_bg_radius: 0,
    text_view: [
      tv(95, 28, 290, 40, 'head', 0xffffff, 34),
      tv(95, 69, 290, 25, 'sub', 0x80828c, 18)
    ],
    text_view_count: 2
  },
  {
    type_id: T.FOOT, item_height: px(72), item_bg_color: 0x1b3a5c, item_bg_radius: px(36),
    text_view: [tv(160, 20, 200, 34, 'label', 0xffffff, 26, true)],
    text_view_count: 1
  },
  {
    type_id: T.GAP, item_height: px(90), item_bg_color: 0x000000, item_bg_radius: 0,
    text_view: [tv(0, 0, 10, 10, 'gap', 0x000000, 12)],
    text_view_count: 1
  },
  {
    type_id: T.INFO, item_height: px(110), item_bg_color: 0x000000, item_bg_radius: 0,
    text_view: [tv(20, 20, 380, 34, 'l1', 0xaaaaaa, 22), tv(20, 58, 380, 34, 'l2', 0x80828c, 20)],
    text_view_count: 2
  },
  {
    type_id: T.ERR, item_height: px(130), item_bg_color: 0x000000, item_bg_radius: 0,
    text_view: [tv(20, 14, 380, 34, 'l1', 0xff7777, 21, true), tv(20, 50, 380, 34, 'l2', 0xff7777, 21, true), tv(20, 90, 380, 30, 'l3', 0x80828c, 18, true)],
    text_view_count: 3
  }
]

// ---- helpers --------------------------------------------------------------
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

function pad2(n) { return n < 10 ? '0' + n : String(n) }
function dayKey(d) { return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate() }

function listTime(value) {
  const ms = new Date(value).getTime()
  if (!ms) return ''
  const d = new Date(ms)
  const now = new Date()
  if (dayKey(d) === dayKey(now)) return pad2(d.getHours()) + ':' + pad2(d.getMinutes())
  if (dayKey(d) === dayKey(new Date(now.getTime() - 86400000))) return 'Yest'
  if (now.getTime() - ms < 6 * 86400000) return DAYS[d.getDay()]
  return d.getDate() + ' ' + MONTHS[d.getMonth()]
}

function fit(text, size, width) {
  const s = String(text || '').replace(/\s+/g, ' ').trim()
  if (!s) return ''
  try {
    const r = getTextLayout(s, { text_size: px(size), text_width: px(width), wrapped: 1, rows_max: 1 })
    if (r && typeof r.text === 'string' && r.text) return r.text
  } catch (e) {}
  const max = Math.floor(width / (size * 0.55))
  return s.length > max ? s.slice(0, max - 1) + '…' : s
}

function splitLines(message) {
  const s = String(message || '').replace(/\s+/g, ' ').trim()
  const parts = []
  let rest = s
  for (let i = 0; i < 2; i++) {
    if (rest.length <= 30) { parts.push(rest); rest = ''; break }
    let cut = rest.lastIndexOf(' ', 30)
    if (cut < 12) cut = 30
    parts.push(rest.slice(0, cut).trim())
    rest = rest.slice(cut).trim()
  }
  if (rest) parts[1] = (parts[1] || '').slice(0, 27) + '…'
  return parts
}

function unwrapItems(value) {
  for (let i = 0; i < 6; i++) {
    if (typeof value === 'string') {
      try { value = JSON.parse(value); continue } catch (e) { return [] }
    }
    if (Array.isArray(value)) return value
    if (!value || typeof value !== 'object') return []
    if (value.items !== undefined) { value = value.items; continue }
    if (value.result !== undefined) { value = value.result; continue }
    if (value.data !== undefined) { value = value.data; continue }
    if (value.body !== undefined) { value = value.body; continue }
    const keys = Object.keys(value)
    if (keys.length && keys.every((k) => /^\d+$/.test(k))) {
      return keys.sort((a, b) => Number(a) - Number(b)).map((k) => value[k])
    }
    return []
  }
  return []
}

const PAGE = 8            // chats fetched per request
const LOAD_AHEAD = 2      // start the next fetch when this close to the end
const FRESH_MS = 30000    // don't re-sync on resume if data is newer than this

function hasMoreOf(raw) {
  let value = raw
  for (let i = 0; i < 6; i++) {
    if (typeof value === 'string') { try { value = JSON.parse(value); continue } catch (e) { return null } }
    if (!value || typeof value !== 'object') return null
    if (value.hasMore !== undefined) return !!value.hasMore
    if (value.result !== undefined) { value = value.result; continue }
    if (value.data !== undefined) { value = value.data; continue }
    if (value.body !== undefined) { value = value.body; continue }
    return null
  }
  return null
}

const fallbackStore = { chats: null, messages: {} }
function store() {
  try {
    const g = getApp()._options.globalData
    if (!g.watchChat) g.watchChat = { chats: null, messages: {} }
    return g.watchChat
  } catch (e) { return fallbackStore }
}

// ---- page -----------------------------------------------------------------
Page(
  BasePage({
    state: { chats: [], loading: false, loadingMore: false, hasMore: false, error: '' },

    onInit() {
      this.state = { chats: [], loading: false, loadingMore: false, hasMore: false, error: '' }
      this.list = null
      this.actions = []
      this.ready = false
      this.notificationTimer = null
      this.registerSettingsGesture()
    },

    build() {
      const cached = store().chats
      if (cached && cached.length) {
        this.state.chats = cached
        this.state.hasMore = store().hasMore !== false
      }
      this.render()
      this.fetchPendingNotifications()
      ensureNotifyService()
      this.registerSettingsGesture()
      // Show cached chats instantly; only hit the bridge if there is nothing
      // cached or the cache is stale.
      if (!cached || !cached.length || Date.now() - (store().stamp || 0) > FRESH_MS) this.loadChats()
      else this.ready = true
    },

    onResume() {
      this.registerSettingsGesture()
      this.fetchPendingNotifications()
      if (!this.ready) return
      if (Date.now() - (store().stamp || 0) > FRESH_MS) this.loadChats()
      else this.render()   // just redraw (e.g. a chat you opened is now read)
    },

    onDestroy() {
      this.list = null
    },

    registerSettingsGesture() {
      try {
        onGesture({ callback: (event) => {
          if (event === GESTURE_LEFT) {
            push({ url: 'page/settings' })
            return true
          }
          return false
        } })
      } catch (error) { console.log('[WatchChat] Settings swipe unavailable: ' + String(error && error.message ? error.message : error)) }
    },

    onCall(data) {
      handleNotificationCall(data, (request) => this.request(request))
    },

    fetchPendingNotifications() {
      this.request({ method: 'GET_NOTIFICATIONS', params: {} })
        .then((response) => handlePendingNotifications(response, (request) => this.request(request)))
        .catch(() => {})
    },



    buildRows() {
      const s = this.state
      const rows = []
      const types = []
      const actions = []
      const add = (type, data, action) => {
        rows.push(Object.assign({ title: '', time: '', preview: '', badge: '', head: '', sub: '', label: '', l1: '', l2: '', l3: '', gap: '' }, data))
        types.push(type)
        actions.push(action || null)
      }

      let sub = ''
      if (s.loading) sub = 'Syncing…'
      else if (s.error && s.chats.length) sub = 'Offline'
      else if (s.chats.length) sub = s.chats.length + (s.hasMore ? '+' : '') + ' chats'
      add(T.HEAD, {
        head: 'WatchChat', sub
      })

      if (s.error && !s.chats.length) {
        const lines = splitLines(s.error)
        add(T.ERR, { l1: lines[0] || '', l2: lines[1] || '', l3: 'Check the PC bridge, then Refresh' }, { type: 'refresh' })
      } else if (!s.chats.length) {
        add(T.INFO, s.loading ? { l1: 'Loading chats…' } : { l1: 'No chats yet', l2: 'Open WhatsApp on your phone' })
      }

      s.chats.forEach((chat) => {
        const unread = Number(chat.unreadCount || 0)
        add(unread > 0 ? T.UNREAD : T.CHAT, {
          title: fit(chat.title || 'Conversation', 26, 270),
          time: listTime(chat.lastActivity),
          preview: fit(chat.preview || 'No messages yet', 20, 285),
          badge: unread > 0 ? '● ' + (unread > 99 ? '99+' : unread) : ''
        }, { type: 'chat', chat })
      })

      if (s.hasMore) add(T.FOOT, { label: s.loadingMore ? 'Loading…' : 'Load more' }, { type: 'more' })
      else add(T.FOOT, { label: 'Refresh' }, { type: 'refresh' })
      add(T.GAP, {})

      const config = []
      types.forEach((t, i) => {
        const last = config[config.length - 1]
        if (last && last.type_id === t && last.end === i - 1) last.end = i
        else config.push({ start: i, end: i, type_id: t })
      })
      return { rows, config, actions }
    },

    render() {
      const built = this.buildRows()
      this.actions = built.actions
      const data = {
        data_type_config: built.config,
        data_type_config_count: built.config.length,
        data_array: built.rows,
        data_count: built.rows.length
      }
      if (!this.list) {
        this.list = hmUI.createWidget(hmUI.widget.SCROLL_LIST, Object.assign({
          x: px(30), y: 0, w: px(420), h: px(480),
          item_space: px(10),
          item_config: ITEM_CONFIG,
          item_config_count: ITEM_CONFIG.length,
          item_click_func: (list, index, dataKey) => this.onItem(index, dataKey),
          item_focus_change_func: (list, index, focus) => this.onFocus(index, focus)
        }, data))
      } else {
        this.list.setProperty(hmUI.prop.UPDATE_DATA, Object.assign(data, { on_page: 1 }))
      }
    },

    onItem(index, dataKey) {
      // Navigation controls are action-enabled views inside the native list.
      // This keeps their touch targets in the list's own event layer rather
      // than placing floating widgets over a full-screen SCROLL_LIST.
      const action = this.actions[index]
      if (!action) return
      if (action.type === 'refresh') { this.loadChats(); return }
      if (action.type === 'more') { this.loadMore(); return }
      if (action.type === 'chat') {
        const chat = action.chat
        chat.unreadCount = 0   // mark it read locally; the bridge marks it read when the chat opens
        push({
          url: 'page/chat',
          params: JSON.stringify({ chatId: chat.id, title: chat.title || 'Conversation', network: chat.network || '' })
        })
      }
    },

    // Re-fetch what is already on screen (at least one page) so a refresh never
    // collapses the list or resets the scroll position.
    loadChats() {
      if (this.state.loading || this.state.loadingMore) return
      this.state.loading = true
      this.render()
      const limit = Math.min(100, Math.max(PAGE, this.state.chats.length))
      this.request({ method: 'LIST_CHATS', params: { limit, offset: 0 } })
        .then((response) => {
          if (response && response.error) throw new Error(response.error)
          const raw = response && response.result !== undefined ? response.result : response
          const items = unwrapItems(raw).filter((c) => c && c.id)
          const more = hasMoreOf(raw)
          this.state.chats = items
          this.state.hasMore = more === null ? items.length >= limit : more
          this.state.error = ''
          const g = store()
          g.chats = items; g.hasMore = this.state.hasMore; g.stamp = Date.now()
        })
        .catch((error) => {
          this.state.error = String(error && error.message ? error.message : error)
        })
        .then(() => {
          this.state.loading = false
          this.ready = true
          this.render()
        })
    },

    // Called by the list as rows come into focus: fetch the next 8 a little
    // before the user reaches the bottom so scrolling never waits.
    onFocus(index, focus) {
      const s = this.state
      if (!focus || !s.hasMore || s.loading || s.loadingMore || !s.chats.length) return
      if (index >= s.chats.length - LOAD_AHEAD) this.loadMore()
    },

    loadMore() {
      const s = this.state
      if (s.loading || s.loadingMore || !s.hasMore) return
      s.loadingMore = true
      this.render()
      this.request({ method: 'LIST_CHATS', params: { limit: PAGE, offset: s.chats.length } })
        .then((response) => {
          if (response && response.error) throw new Error(response.error)
          const raw = response && response.result !== undefined ? response.result : response
          const items = unwrapItems(raw).filter((c) => c && c.id)
          const seen = new Set(s.chats.map((c) => c.id))
          const fresh = items.filter((c) => !seen.has(c.id))
          s.chats = s.chats.concat(fresh)
          const more = hasMoreOf(raw)
          s.hasMore = (more === null ? items.length >= PAGE : more) && fresh.length > 0
          const g = store()
          g.chats = s.chats; g.hasMore = s.hasMore; g.stamp = Date.now()
        })
        .catch(() => {
          // keep what we have; the footer lets the user tap to retry
        })
        .then(() => {
          s.loadingMore = false
          this.render()
        })
    }
  })
)
