import * as hmUI from '@zos/ui'
import { px } from '@zos/utils'
import { onGesture, showToast } from '@zos/interaction'
import { BasePage } from '@zeppos/zml/base-page'
import { getKeyboard, setKeyboard, getInputDisplay, setInputDisplay, getCollapseHeader, setCollapseHeader } from '../lib/prefs'

const T = { HEAD: 1, LABEL: 2, OPT: 3, OPT_ON: 4, GAP: 5, INFO: 6 }
const POLL_OPTIONS = [10000, 15000, 20000, 30000]

function tv(x, y, w, h, key, color, size, action) {
  const v = { x: px(x), y: px(y), w: px(w), h: px(h), key, color, text_size: px(size) }
  if (action) v.action = true
  return v
}

const ITEM_CONFIG = [
  { type_id: T.HEAD, item_height: px(112), item_bg_color: 0x000000, item_bg_radius: 0,
    text_view: [tv(95, 28, 290, 40, 'a', 0xffffff, 34), tv(95, 69, 290, 25, 'b', 0x80828c, 18)], text_view_count: 2 },
  { type_id: T.LABEL, item_height: px(46), item_bg_color: 0x000000, item_bg_radius: 0,
    text_view: [tv(14, 8, 380, 30, 'a', 0x80828c, 20)], text_view_count: 1 },
  { type_id: T.OPT, item_height: px(84), item_bg_color: 0x1a1b21, item_bg_radius: px(26),
    text_view: [tv(24, 24, 370, 36, 'a', 0xffffff, 26, true)], text_view_count: 1 },
  { type_id: T.OPT_ON, item_height: px(84), item_bg_color: 0x13322a, item_bg_radius: px(26),
    text_view: [tv(24, 24, 370, 36, 'a', 0x3ddc84, 26, true)], text_view_count: 1 },
  { type_id: T.GAP, item_height: px(26), item_bg_color: 0x000000, item_bg_radius: 0,
    text_view: [tv(0, 0, 10, 10, 'a', 0x000000, 12)], text_view_count: 1 },
  { type_id: T.INFO, item_height: px(92), item_bg_color: 0x000000, item_bg_radius: 0,
    text_view: [tv(20, 8, 390, 30, 'a', 0xaaaaaa, 19), tv(20, 42, 390, 34, 'b', 0x80828c, 17)], text_view_count: 2 }
]

function unwrap(response) {
  return response && response.result !== undefined ? response.result : (response || {})
}

Page(
  BasePage({
    onInit() {
      this.list = null
      this.inputDisplay = getInputDisplay()
      this.collapseHeader = getCollapseHeader()
      this.notificationEnabled = true
      this.notificationPollMs = 10000
      this.notificationStatus = 'Loading notification settings…'
      this.notificationSaving = false
      // Child page: don't let the inbox's left-swipe stack another Settings page.
      try { onGesture({ callback: () => false }) } catch (error) {}
    },

    build() {
      this.render()
      this.loadNotificationSettings()
    },

    onDestroy() { this.list = null },

    render() {
      const mode = getKeyboard()
      const row = (type, a, b) => ({ type, d: { a: a || '', b: b || '' } })
      const toggleLabel = this.notificationEnabled ? '✓  Notifications on' : 'Notifications off'
      const pollLabel = 'Check every ' + Math.round(this.notificationPollMs / 1000) + ' seconds'
      const rows = [
        row(T.HEAD, 'Settings', 'Swipe right to go back'),
        row(T.LABEL, 'REPLY KEYBOARD'),
        row(mode === 'keyflow' ? T.OPT_ON : T.OPT, (mode === 'keyflow' ? '✓  ' : '') + 'Keyflow'),
        row(mode === 'system' ? T.OPT_ON : T.OPT, (mode === 'system' ? '✓  ' : '') + 'System keyboard'),
        row(T.GAP),
        row(T.LABEL, 'NOTIFICATIONS'),
        row(this.notificationEnabled ? T.OPT_ON : T.OPT, toggleLabel),
        row(T.OPT, pollLabel),
        row(T.GAP),
        row(T.LABEL, 'MESSAGE INPUT'),
        row(this.inputDisplay === 'horizontal' ? T.OPT_ON : T.OPT, (this.inputDisplay === 'horizontal' ? '✓  ' : '') + 'Horizontal scroll'),
        row(this.inputDisplay === 'wrap' ? T.OPT_ON : T.OPT, (this.inputDisplay === 'wrap' ? '✓  ' : '') + 'Wrap text'),
        row(T.GAP),
        row(T.LABEL, 'CHAT HEADER'),
        row(this.collapseHeader ? T.OPT_ON : T.OPT, this.collapseHeader ? '✓  Collapse banner on scroll' : 'Collapse banner on scroll'),
        row(T.INFO, 'Phone → PC → Watch', this.notificationStatus),
        row(T.GAP)
      ]
      this.actions = [null, null, 'keyflow', 'system', null, null, 'toggleNotifications', 'cyclePoll', null, null, 'horizontal', 'wrap', null, null, 'toggleHeader', null]
      const config = []
      rows.forEach((r, i) => {
        const last = config[config.length - 1]
        if (last && last.type_id === r.type && last.end === i - 1) last.end = i
        else config.push({ start: i, end: i, type_id: r.type })
      })
      const data = {
        data_type_config: config, data_type_config_count: config.length,
        data_array: rows.map((r) => r.d), data_count: rows.length
      }
      if (!this.list) {
        this.list = hmUI.createWidget(hmUI.widget.SCROLL_LIST, Object.assign({
          x: px(30), y: 0, w: px(420), h: px(480), item_space: px(10),
          item_config: ITEM_CONFIG, item_config_count: ITEM_CONFIG.length,
          item_click_func: (list, index) => this.choose(this.actions[index])
        }, data))
      } else {
        this.list.setProperty(hmUI.prop.UPDATE_DATA, Object.assign(data, { on_page: 1 }))
      }
    },

    loadNotificationSettings() {
      this.request({ method: 'GET_NOTIFICATION_SETTINGS', params: {} })
        .then((response) => {
          const value = unwrap(response)
          if (value.error) throw new Error(value.error)
          this.notificationEnabled = value.enabled !== false
          const interval = Number(value.pollMs)
          this.notificationPollMs = POLL_OPTIONS.includes(interval) ? interval : 10000
          this.notificationStatus = this.notificationEnabled
            ? 'Automatic checks are enabled'
            : 'Notifications are paused'
          this.render()
        })
        .catch(() => {
          this.notificationStatus = 'Open the Zepp phone app to connect'
          this.render()
        })
    },

    saveNotificationSettings(next) {
      if (this.notificationSaving) return
      const previous = {
        enabled: this.notificationEnabled,
        pollMs: this.notificationPollMs
      }
      this.notificationEnabled = next.enabled
      this.notificationPollMs = next.pollMs
      this.notificationSaving = true
      this.notificationStatus = 'Saving…'
      this.render()
      this.request({ method: 'SET_NOTIFICATION_SETTINGS', params: next })
        .then((response) => {
          const value = unwrap(response)
          if (value.error) throw new Error(value.error)
          this.notificationEnabled = value.enabled !== false
          const interval = Number(value.pollMs)
          this.notificationPollMs = POLL_OPTIONS.includes(interval) ? interval : next.pollMs
          this.notificationStatus = this.notificationEnabled
            ? 'Checking Beeper automatically'
            : 'Notifications are paused'
          this.notificationSaving = false
          this.render()
          try { showToast({ content: 'Notification settings saved' }) } catch (e) {}
        })
        .catch((error) => {
          this.notificationEnabled = previous.enabled
          this.notificationPollMs = previous.pollMs
          this.notificationStatus = 'Could not save. Reopen the phone app.'
          this.notificationSaving = false
          this.render()
          try { showToast({ content: String(error && error.message ? error.message : error).slice(0, 60) }) } catch (e) {}
        })
    },

    choose(action) {
      if (!action || this.notificationSaving) return
      if (action === 'keyflow' || action === 'system') {
        const saved = setKeyboard(action)
        try { showToast({ content: (action === 'keyflow' ? 'Keyflow' : 'System keyboard') + (saved ? ' selected' : ' (this session)') }) } catch (e) {}
        this.render()
        return
      }
      if (action === 'horizontal' || action === 'wrap') {
        const saved = setInputDisplay(action)
        this.inputDisplay = action
        this.render()
        try { showToast({ content: (action === 'horizontal' ? 'Horizontal scrolling' : 'Wrapped text') + (saved ? ' selected' : ' (this session)') }) } catch (e) {}
        return
      }
      if (action === 'toggleHeader') {
        const saved = setCollapseHeader(!this.collapseHeader)
        this.collapseHeader = !this.collapseHeader
        this.render()
        try { showToast({ content: 'Chat banner ' + (this.collapseHeader ? 'will collapse' : 'stays visible') + (saved ? '' : ' (this session)') }) } catch (e) {}
        return
      }
      if (action === 'toggleNotifications') {
        this.saveNotificationSettings({
          enabled: !this.notificationEnabled,
          pollMs: this.notificationPollMs
        })
        return
      }
      if (action === 'cyclePoll') {
        const current = POLL_OPTIONS.indexOf(this.notificationPollMs)
        const next = POLL_OPTIONS[(current + 1 + POLL_OPTIONS.length) % POLL_OPTIONS.length]
        this.saveNotificationSettings({ enabled: this.notificationEnabled, pollMs: next })
      }
    }
  })
)
