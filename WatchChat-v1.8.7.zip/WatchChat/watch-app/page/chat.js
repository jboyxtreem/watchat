import * as hmUI from '@zos/ui'
import { createKeyboard, deleteKeyboard, inputType, getTextLayout } from '@zos/ui'
import { openKeyboard as openKeyflow } from '../lib/keyboard'
import { getKeyboard, getCollapseHeader } from '../lib/prefs'
import { px } from '@zos/utils'
import { showToast, onGesture } from '@zos/interaction'
import { BasePage } from '@zeppos/zml/base-page'
import { handleNotificationCall } from '../lib/notifications'

// ---- layout constants (480 px design width) --------------------------------
const SCREEN = 480
const MARGIN = 40
const BUBBLE_MAX_W = 330
const PAD_X = 16
const PAD_Y = 10
const FONT = 24
const HEADER_H = 140
const HEADER_BG = 0x050818
const COMPOSER_H = 76
const KEYBOARD_VIEW_H = 232
const COMPOSER_Y = 390
const NORMAL_VIEW_H = COMPOSER_Y - HEADER_H
const SEP_H = 36
const BATCH = 20
const MAX_MESSAGES = 80
const GAP_MS = 15 * 60 * 1000
const TICK_MS = 800
const POLL_TICKS = 13 // ~10 s

const COLOR = {
  own: 0x0b6b4f, ownPending: 0x0f4a38, ownFailed: 0x6b2430, other: 0x2b2d35,
  text: 0xffffff, dim: 0x7d7f88, err: 0xff7777, reply: 0x1769aa, replyPress: 0x2787cc
}
const NAME_COLORS = [0x6cb6ff, 0xf0a35e, 0xb28cff, 0x5ed3a8, 0xff7b9c, 0xe3d36b]

// ---- helpers ----------------------------------------------------------------
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

function pad2(n) { return n < 10 ? '0' + n : String(n) }
function dayKey(ts) { const d = new Date(ts); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate() }
function clock(ts) { const d = new Date(ts); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()) }

function dayLabel(ts) {
  const now = Date.now()
  const k = dayKey(ts)
  if (k === dayKey(now)) return 'Today'
  if (k === dayKey(now - 86400000)) return 'Yesterday'
  const d = new Date(ts)
  const base = DAYS[d.getDay()] + ' ' + d.getDate() + ' ' + MONTHS[d.getMonth()]
  return d.getFullYear() === new Date(now).getFullYear() ? base : base + ' ' + d.getFullYear()
}

function sepText(ts, withDay) {
  if (!ts) return ''
  return withDay ? dayLabel(ts) + ' ' + clock(ts) : clock(ts)
}

function notify(message) {
  try { showToast({ content: String(message).slice(0, 60) }) } catch (e) {}
}

function errText(error) {
  return String(error && error.message ? error.message : error)
}

function nameColor(name) {
  let h = 0
  for (let i = 0; i < name.length; i++) h = (h + name.charCodeAt(i)) % 997
  return NAME_COLORS[h % NAME_COLORS.length]
}

function fit(text, size, width) {
  const s = String(text || '').replace(/\s+/g, ' ').trim()
  if (!s) return ''
  try {
    const r = getTextLayout(s, { text_size: px(size), text_width: px(width), wrapped: 1, rows_max: 1 })
    if (r && typeof r.text === 'string' && r.text) return r.text
  } catch (e) {}
  const max = Math.floor(width / (size * 0.55))
  return s.length > max ? s.slice(0, max - 1) + '…' : s
}

function bodyOf(m) {
  let t = String(m.text == null ? '' : m.text)
    .replace(/\r/g, '').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim()
  if (!t) t = m.type && m.type !== 'TEXT' ? '[' + String(m.type).toLowerCase() + ']' : '(empty)'
  if (t.length > 500) t = t.slice(0, 497) + '…'
  return t
}

function toMs(v) {
  const n = Date.parse(v)
  return isNaN(n) ? 0 : n
}

function normMessage(m) {
  return {
    id: String(m.id || ''),
    text: m.text,
    type: m.type,
    own: !!m.isSender,
    sender: m.isSender ? '' : String(m.senderName || ''),
    ts: toMs(m.timestamp),
    reactions: Array.isArray(m.reactions) ? m.reactions.slice(0, 6) : []
  }
}

function merge(a, b) {
  const map = new Map()
  a.concat(b).forEach((m, i) => { map.set(m.id || ('x' + i), m) })
  return Array.from(map.values()).sort((x, y) => x.ts - y.ts)
}

function parseMessages(raw) {
  let value = raw
  for (let i = 0; i < 6; i++) {
    if (typeof value === 'string') {
      try { value = JSON.parse(value); continue } catch (e) { break }
    }
    if (Array.isArray(value)) return { items: value, hasMore: false }
    if (!value || typeof value !== 'object') break
    if (value.items !== undefined) {
      let items = value.items
      if (typeof items === 'string') { try { items = JSON.parse(items) } catch (e) { items = [] } }
      if (items && !Array.isArray(items) && typeof items === 'object') {
        const keys = Object.keys(items)
        items = keys.every((k) => /^\d+$/.test(k)) ? keys.sort((a, b) => Number(a) - Number(b)).map((k) => items[k]) : []
      }
      return { items: Array.isArray(items) ? items : [], hasMore: !!value.hasMore }
    }
    if (value.result !== undefined) { value = value.result; continue }
    if (value.data !== undefined) { value = value.data; continue }
    if (value.body !== undefined) { value = value.body; continue }
    break
  }
  return { items: [], hasMore: false }
}

const fallbackStore = { chats: null, messages: {} }
function store() {
  try {
    const g = getApp()._options.globalData
    if (!g.watchChat) g.watchChat = { chats: null, messages: {} }
    return g.watchChat
  } catch (e) { return fallbackStore }
}

function measure(text) {
  const maxTextW = BUBBLE_MAX_W - PAD_X * 2
  try {
    if (text.indexOf('\n') < 0) {
      const one = getTextLayout(text, { text_size: px(FONT), text_width: 0, wrapped: 0 })
      if (one && one.width > 0 && one.width <= maxTextW) {
        return { tw: Math.max(24, Math.ceil(one.width) + 4), th: Math.ceil(one.height) }
      }
    }
    const wr = getTextLayout(text, { text_size: px(FONT), text_width: px(maxTextW), wrapped: 1 })
    if (wr && wr.height > 0) return { tw: maxTextW, th: Math.ceil(wr.height) }
  } catch (e) {}
  const cpl = Math.floor(maxTextW / (FONT * 0.55))
  const lines = text.split('\n').reduce((n, line) => n + Math.max(1, Math.ceil(line.length / cpl)), 0)
  return { tw: maxTextW, th: lines * Math.round(FONT * 1.3) }
}

function computeLayout(messages, isGroup) {
  const items = []
  let y = 0
  let prevTs = 0
  let prevDay = -1
  let prevKey = null
  messages.forEach((m) => {
    const ts = m.ts || prevTs
    const day = ts ? dayKey(ts) : prevDay
    const key = m.own ? 'me' : (m.sender || 'them')
    let fresh = false
    if (prevDay === -1 || day !== prevDay || ts - prevTs > GAP_MS) {
      const label = sepText(ts, prevDay === -1 || day !== prevDay)
      if (label) { items.push({ k: 'sep', y, text: label }); y += SEP_H }
      fresh = true
    } else {
      y += key !== prevKey ? 10 : 4
    }
    if (isGroup && !m.own && (fresh || key !== prevKey)) {
      items.push({ k: 'name', y, text: fit(m.sender || 'Someone', 18, 260), color: nameColor(m.sender || '') })
      y += 24
    }
    const text = bodyOf(m)
    const dim = measure(text)
    const w = dim.tw + PAD_X * 2
    const h = dim.th + PAD_Y * 2
    const reactions = Array.isArray(m.reactions) ? m.reactions.slice(0, 6) : []
    items.push({
      k: 'bubble', x: m.own ? SCREEN - MARGIN - w : MARGIN, y, w, h, tw: dim.tw, th: dim.th,
      text, own: m.own, pending: !!m.pending, failed: !!m.failed, reactions
    })
    y += h
    if (reactions.length) {
      const label = reactions.map((r) => String(r.key || r.reactionKey || '') + (Number(r.count) > 1 ? String(r.count) : '')).filter(Boolean).join('  ')
      const rw = Math.min(220, Math.max(56, label.length * 18 + 24))
      items.push({ k: 'reactions', x: m.own ? SCREEN - MARGIN - rw : MARGIN + 12, y, w: rw, h: 34, text: label, mine: reactions.some((r) => !!r.mine) })
      y += 38
    }
    items[items.length - 1].key = key
    prevTs = ts
    prevDay = day
    prevKey = key
  })
  // Only the last bubble of a run gets the pointed corner (like WhatsApp).
  let nextBubble = null
  for (let i = items.length - 1; i >= 0; i--) {
    const it = items[i]
    if (it.k === 'sep') nextBubble = null
    else if (it.k === 'bubble') {
      it.tail = !nextBubble || nextBubble.key !== it.key
      nextBubble = it
    }
  }
  return { items, end: y }
}

function freshState() {
  return {
    chatId: '', title: 'Conversation', isGroup: false, headerCollapsed: false,
    messages: [], pending: [],
    hasMore: false, exhausted: false,
    loadingFirst: true, loadingOlder: false,
    error: '', offline: false,
    contentH: SCREEN, viewOffset: 0, keyboardOpen: false,
    olderRetryAt: 0
  }
}

// ---- page -------------------------------------------------------------------
Page(
  BasePage({
    state: freshState(),

    onInit(params) {
      this.state = freshState()
      this.widgets = []
      this.statusWidget = null
      this.timer = null
      this.ticks = 0
      this.ready = false
      this.polling = false
      try { onGesture({ callback: () => false }) } catch (e) {}
      try {
        const data = JSON.parse(params || '{}')
        this.state.chatId = String(data.chatId || '')
        this.state.title = String(data.title || 'Conversation')
        this.state.isGroup = this.state.chatId.slice(-5) === '@g.us'
      } catch (e) {
        this.state.error = 'Could not open this conversation.'
        this.state.loadingFirst = false
      }
    },

    build() {
      const s = this.state
      const cached = store().messages[s.chatId]
      if (cached && cached.length) s.messages = cached.slice()
      this.rebuild('bottom')
      if (s.chatId) {
        this.loadLatest()
        this.timer = setInterval(() => this.tick(), TICK_MS)
      }
    },

    // Stop polling while the screen is off / page hidden (big battery + BLE saving).
    onHide() {
      if (this.timer) { clearInterval(this.timer); this.timer = null }
    },

    onShow() {
      if (!this.timer && this.state.chatId && this.widgets) this.timer = setInterval(() => this.tick(), TICK_MS)
    },

    onDestroy() {
      if (this.timer) { clearInterval(this.timer); this.timer = null }
      this.clearWidgets()
    },

    onCall(data) {
      handleNotificationCall(data, (request) => this.request(request))
    },

    // ---- widgets ---------------------------------------------------------
    clearWidgets() {
      ;(this.widgets || []).forEach((w) => { try { hmUI.deleteWidget(w) } catch (e) {} })
      this.widgets = []
      this.statusWidget = null
      this.headerView = null
      this.messageView = null
    },

    add(type, props) {
      const w = hmUI.createWidget(type, props)
      this.widgets.push(w)
      return w
    },

    addMessageWidget(type, props) {
      if (!this.messageView) return null
      return this.messageView.createWidget(type, props)
    },

    statusText() {
      const s = this.state
      if (s.offline) return 'Offline - retrying'
      if (s.loadingOlder) return 'Loading earlier messages…'
      if (s.loadingFirst && s.messages.length) return 'Updating…'
      if (s.messages.length >= MAX_MESSAGES) return 'Showing latest ' + MAX_MESSAGES + ' messages'
      if (s.exhausted) return 'Beginning of conversation'
      if (s.hasMore) return 'Scroll up for earlier'
      return ''
    },

    updateStatus() {
      try {
        if (this.statusWidget) this.statusWidget.setProperty(hmUI.prop.TEXT, this.statusText())
      } catch (e) {}
    },

    visible() {
      return this.state.messages.concat(this.state.pending)
    },

    rebuild(target) {
      const s = this.state
      this.clearWidgets()

      const composing = !!s.keyboardOpen
      const collapseHeader = getCollapseHeader() && !composing && !!s.headerCollapsed
      const viewY = (composing || collapseHeader) ? 0 : HEADER_H
      const viewH = composing ? KEYBOARD_VIEW_H : (collapseHeader ? COMPOSER_Y : NORMAL_VIEW_H)
      const list = this.visible()
      let end = 0
      let showComposer = true
      let layout = null
      let emptyText = ''
      let retryY = 0

      if (!list.length) {
        emptyText = s.error ? s.error : (s.loadingFirst ? 'Loading messages…' : 'No messages yet')
        retryY = Math.max(18, Math.floor((viewH - 110) / 2))
        end = retryY + (s.error ? 182 : 120)
        if (s.error) showComposer = false
      } else {
        layout = computeLayout(list, s.isGroup)
        end = layout.end
      }

      // The composer is fixed below the normal message viewport. During
      // composing, the header/composer disappear and the independent message
      // viewport expands to the top 232 px above the fixed Keyflow overlay.
      const composerY = COMPOSER_Y
      if (!composing && showComposer) end = Math.max(end, 0)
      const contentH = end + (composing ? 24 : 24)
      s.contentH = contentH
      const scrollPos = this.applyScroll(target, viewH)
      this.lastScrollEventOffset = scrollPos

      // The chat banner is one parent widget, not several independent text
      // widgets. When collapsed, this complete 140 px container is omitted;
      // the message viewport then starts at y=0 and expands into its space.
      // Keeping title, status and background inside this parent prevents a
      // leftover banner surface from remaining after the title is hidden.
      if (!composing && !collapseHeader) {
        this.headerView = this.add(hmUI.widget.VIEW_CONTAINER, {
          x: px(0), y: px(0), w: px(SCREEN), h: px(HEADER_H), scroll_enable: 0
        })
        this.headerView.createWidget(hmUI.widget.FILL_RECT, {
          x: px(0), y: px(0), w: px(SCREEN), h: px(HEADER_H),
          color: HEADER_BG
        })
        this.headerView.createWidget(hmUI.widget.TEXT, {
          x: px(96), y: px(46), w: px(288), h: px(42), text: fit(s.title, 30, 280),
          text_size: px(30), color: COLOR.text,
          align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V
        })
        this.statusWidget = this.headerView.createWidget(hmUI.widget.TEXT, {
          x: px(80), y: px(92), w: px(320), h: px(28), text: this.statusText(),
          text_size: px(18), color: COLOR.dim,
          align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V
        })
      } else {
        this.headerView = null
        this.statusWidget = null
      }

      this.messageView = this.add(hmUI.widget.VIEW_CONTAINER, {
        x: px(0), y: px(viewY), w: px(SCREEN), h: px(viewH),
        scroll_enable: 1, pos_y: px(-scrollPos), bounce: 1,
        scroll_frame_func: (info) => this.onMessageScroll(info),
        scroll_complete_func: (info) => this.onMessageScroll(info)
      })

      if (emptyText) {
        this.addMessageWidget(hmUI.widget.TEXT, {
          x: px(55), y: px(retryY), w: px(370), h: px(110), text: emptyText,
          text_size: px(s.error ? 20 : 22), color: s.error ? COLOR.err : 0xaaaaaa,
          align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.WRAP
        })
        if (s.error) {
          this.addMessageWidget(hmUI.widget.BUTTON, {
            x: px(150), y: px(retryY + 120), w: px(180), h: px(56), radius: px(20),
            normal_color: 0x2c2c2e, press_color: 0x48484a, text: 'Retry', text_size: px(24), color: COLOR.text,
            click_func: () => this.retry()
          })
        }
      } else if (layout) {
        layout.items.forEach((it) => {
          if (it.k === 'sep') {
            this.addMessageWidget(hmUI.widget.TEXT, {
              x: px(80), y: px(it.y + 4), w: px(320), h: px(26), text: it.text,
              text_size: px(18), color: COLOR.dim,
              align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V
            })
          } else if (it.k === 'name') {
            this.addMessageWidget(hmUI.widget.TEXT, {
              x: px(MARGIN + 12), y: px(it.y), w: px(280), h: px(22), text: it.text,
              text_size: px(18), color: it.color,
              align_h: hmUI.align.LEFT, align_v: hmUI.align.CENTER_V
            })
          } else if (it.k === 'reactions') {
            this.addMessageWidget(hmUI.widget.FILL_RECT, { x: px(it.x), y: px(it.y), w: px(it.w), h: px(it.h), radius: px(16), color: it.mine ? 0x244b3e : 0x24262d })
            this.addMessageWidget(hmUI.widget.TEXT, {
              x: px(it.x + 10), y: px(it.y + 2), w: px(it.w - 20), h: px(it.h - 4), text: it.text,
              text_size: px(20), color: COLOR.text, align_h: hmUI.align.CENTER_H, align_v: hmUI.align.CENTER_V
            })
          } else {
            const color = it.own ? (it.failed ? COLOR.ownFailed : (it.pending ? COLOR.ownPending : COLOR.own)) : COLOR.other
            this.addMessageWidget(hmUI.widget.FILL_RECT, { x: px(it.x), y: px(it.y), w: px(it.w), h: px(it.h), radius: px(22), color })
            if (it.tail) {
              this.addMessageWidget(hmUI.widget.FILL_RECT, {
                x: px(it.own ? it.x + it.w - 14 : it.x), y: px(it.y + it.h - 14), w: px(14), h: px(14), color
              })
            }
            this.addMessageWidget(hmUI.widget.TEXT, {
              x: px(it.x + PAD_X), y: px(it.y + PAD_Y), w: px(it.tw), h: px(it.th + 2),
              text: it.text, text_size: px(FONT), color: COLOR.text,
              align_h: hmUI.align.LEFT, align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.WRAP
            })
          }
        })
      }

      if (!composing && showComposer) {
        this.add(hmUI.widget.BUTTON, {
          x: px(42), y: px(composerY), w: px(396), h: px(60), radius: px(20),
          normal_color: 0x1a1b21, press_color: 0x30323a,
          text: 'Message…', text_size: px(23), color: 0x858791,
          align_h: hmUI.align.LEFT,
          click_func: () => this.openKeyboard()
        })
      }

      this.ready = false
      setTimeout(() => { this.ready = true; this.lastScrollEventOffset = this.state.viewOffset }, 220)
    },

    // ---- independent message scrolling ----------------------------------
    safeTop() {
      return Math.max(0, Math.abs(Number(this.state.viewOffset) || 0))
    },

    currentViewport() {
      const s = this.state
      return s.keyboardOpen ? KEYBOARD_VIEW_H : (getCollapseHeader() && s.headerCollapsed ? COMPOSER_Y : NORMAL_VIEW_H)
    },

    isNearBottom(offset) {
      const viewport = this.currentViewport()
      const maxScroll = Math.max(0, this.state.contentH - viewport)
      return maxScroll === 0 || (maxScroll - Math.abs(Number(offset) || 0)) < 90
    },

    applyScroll(target, viewport) {
      const s = this.state
      const maxScroll = Math.max(0, s.contentH - viewport)
      let offset = s.viewOffset || 0
      if (target === 'bottom') offset = maxScroll
      else if (target && target.preserve) offset = (Number(target.top) || 0) + Math.max(0, s.contentH - target.oldH)
      else if (typeof target === 'number') offset = Math.abs(target)
      offset = Math.max(0, Math.min(maxScroll, offset))
      s.viewOffset = offset
      return offset
    },

    onMessageScroll(info) {
      const s = this.state
      const raw = Number(info && info.yoffset)
      const previous = this.lastScrollEventOffset
      if (Number.isFinite(raw)) s.viewOffset = Math.max(0, Math.abs(raw))
      if (this.ready && Number.isFinite(raw) && previous !== undefined && Math.abs(s.viewOffset - previous) > 4 && !s.keyboardOpen && getCollapseHeader()) {
        const movingUp = s.viewOffset < previous
        // Collapse after any real scroll away from the top, including when
        // the conversation initially opens at its latest (bottom) position.
        const shouldCollapse = !s.headerCollapsed && s.viewOffset > 24
        const shouldExpand = s.headerCollapsed && movingUp && s.viewOffset < 24
        if (shouldCollapse || shouldExpand) {
          s.headerCollapsed = shouldCollapse
          const preserved = s.viewOffset
          this.rebuild(preserved)
          return
        }
      }
      if (Number.isFinite(raw)) this.lastScrollEventOffset = Math.abs(raw)
      if (!this.canLoadOlder()) return
      const viewport = this.currentViewport()
      const atTop = s.viewOffset < 55
      const tall = s.contentH > viewport + 80
      if (atTop && (s.hasMore || tall)) this.loadOlder()
    },

    // ---- loading ---------------------------------------------------------
    setOffline(flag) {
      if (this.state.offline === flag) return
      this.state.offline = flag
      this.updateStatus()
    },

    retry() {
      this.state.error = ''
      this.state.loadingFirst = true
      this.rebuild('bottom')
      this.loadLatest()
    },

    loadLatest() {
      const s = this.state
      this.request({ method: 'GET_MESSAGES', params: { chatId: s.chatId, limit: BATCH, offset: 0, read: 1 } })
        .then((response) => {
          if (response && response.error) throw new Error(response.error)
          const parsed = parseMessages(response)
          s.messages = merge([], parsed.items.map(normMessage))
          s.hasMore = parsed.hasMore
          s.error = ''
          s.offline = false
          s.loadingFirst = false
          this.reconcilePending()
          store().messages[s.chatId] = s.messages.slice(-40)
          this.rebuild('bottom')
        })
        .catch((error) => {
          s.loadingFirst = false
          if (s.messages.length) s.offline = true
          else s.error = errText(error)
          this.rebuild('bottom')
        })
    },

    reconcilePending() {
      const s = this.state
      const now = Date.now()
      s.pending = s.pending.filter((p) => {
        if (p.failed) return true
        const text = bodyOf(p)
        const delivered = s.messages.some((m) => m.own && bodyOf(m) === text && m.ts >= p.ts - 600000)
        if (delivered) return false
        if (p.sentOk && now - p.sentOk > 30000) return false
        return true
      })
    },

    pollNew() {
      const s = this.state
      if (s.loadingFirst || s.loadingOlder || s.keyboardOpen || this.polling) return
      this.polling = true
      this.request({ method: 'GET_MESSAGES', params: { chatId: s.chatId, limit: BATCH, offset: 0 } })
        .then((response) => {
          if (response && response.error) throw new Error(response.error)
          const incoming = parseMessages(response).items.map(normMessage)
          const before = s.messages
          const reactionChanged = incoming.some((next) => {
            const old = before.find((m) => m.id === next.id)
            if (!old) return false
            const a = Array.isArray(old.reactions) ? old.reactions : []
            const b = Array.isArray(next.reactions) ? next.reactions : []
            if (a.length !== b.length) return true
            return a.some((r, i) => String(r.key || r.reactionKey || '') !== String(b[i]?.key || b[i]?.reactionKey || '') ||
              Number(r.count || 0) !== Number(b[i]?.count || 0) || !!r.mine !== !!b[i]?.mine)
          })
          const merged = merge(before, incoming)
          const grew = merged.length !== before.length ||
            (merged.length && before.length && merged[merged.length - 1].id !== before[before.length - 1].id)
          const pendingBefore = s.pending.length
          s.messages = merged.length > MAX_MESSAGES ? merged.slice(-MAX_MESSAGES) : merged
          this.reconcilePending()
          store().messages[s.chatId] = s.messages.slice(-40)
          this.setOffline(false)
          if (grew || reactionChanged || s.pending.length !== pendingBefore) {
            const top = this.safeTop()
            this.rebuild(this.isNearBottom(top) ? 'bottom' : top)
          }
        })
        .catch(() => { this.setOffline(true) })
        .then(() => { this.polling = false })
    },

    canLoadOlder() {
      const s = this.state
      return this.ready && !s.loadingFirst && !s.loadingOlder && !s.exhausted &&
        !this.polling && s.messages.length < MAX_MESSAGES && Date.now() >= s.olderRetryAt
    },

    tick() {
      const s = this.state
      this.ticks++
      if (!this.ready) return
      if (this.ticks % POLL_TICKS === 0) this.pollNew()
    },

    loadOlder() {
      const s = this.state
      s.loadingOlder = true
      this.updateStatus()

      const fetchBatch = () => this.request({
        method: 'GET_MESSAGES', params: { chatId: s.chatId, limit: BATCH, offset: s.messages.length }
      }).then((response) => {
        if (response && response.error) throw new Error(response.error)
        const parsed = parseMessages(response)
        const merged = merge(s.messages, parsed.items.map(normMessage))
        const added = merged.length - s.messages.length
        s.messages = merged
        s.hasMore = parsed.hasMore
        return added
      })

      const job = s.hasMore
        ? fetchBatch()
        : this.request({ method: 'LOAD_OLDER', params: { chatId: s.chatId, count: 50 } }).then((response) => {
            if (response && response.error) throw new Error(response.error)
            const r = response && response.result !== undefined ? response.result : response
            return r && r.itemsAdded ? fetchBatch() : 0
          })

      job.then((added) => {
        s.loadingOlder = false
        if (added <= 0) { s.exhausted = true; s.hasMore = false }
        if (s.messages.length >= MAX_MESSAGES) { s.exhausted = true; s.hasMore = false }
        if (added > 0) {
          store().messages[s.chatId] = s.messages.slice(-40)
          this.rebuild({ preserve: true, top: this.safeTop(), oldH: s.contentH })
        } else {
          this.updateStatus()
        }
      }).catch((error) => {
        s.loadingOlder = false
        const text = errText(error)
        // the bridge answers 409 when WhatsApp has no earlier-message cursor: nothing more to load
        if (/earlier-message|not connected/i.test(text)) s.exhausted = true
        else s.olderRetryAt = Date.now() + 8000
        this.updateStatus()
      })
    },

    // ---- sending ---------------------------------------------------------
    keyboardDone() {
      const s = this.state
      if (!s.keyboardOpen) return
      s.keyboardOpen = false
      this.rebuild('bottom')
    },

    openKeyboard() {
      const s = this.state
      if (s.keyboardOpen) return
      s.keyboardOpen = true
      this.rebuild('bottom')
      setTimeout(() => {
        if (!s.keyboardOpen) return
        try {
          if (getKeyboard() === 'keyflow') {
            try {
              openKeyflow({
                onSend: (message) => { this.keyboardDone(); this.send(message) },
                onClose: () => this.keyboardDone()
              })
              return
            } catch (err) {
              notify('Keyflow: ' + errText(err))
            }
          }
          createKeyboard({
            inputType: inputType.CHAT || inputType.CHAR,
            text: '',
            onComplete: (_, result) => {
              const message = String(result && result.data ? result.data : '').trim()
              try { deleteKeyboard() } catch (e) {}
              this.keyboardDone()
              if (message) this.send(message)
            },
            onCancel: () => { try { deleteKeyboard() } catch (e) {} this.keyboardDone() }
          })
        } catch (e) {
          this.keyboardDone()
          notify('Keyboard unavailable')
        }
      }, 80)
    },

    send(text) {
      const s = this.state
      const lastTs = s.messages.length ? s.messages[s.messages.length - 1].ts : 0
      const p = {
        id: 'p' + Date.now(), text, type: 'TEXT', own: true, sender: '',
        ts: Math.max(Date.now(), lastTs), pending: true, failed: false, sentOk: 0
      }
      s.pending.push(p)
      this.rebuild('bottom')
      this.request({ method: 'SEND_MESSAGE', params: { chatId: s.chatId, text } })
        .then((response) => {
          if (response && response.error) throw new Error(response.error)
          p.sentOk = Date.now()
          this.pollNew()
        })
        .catch((error) => {
          p.failed = true
          p.pending = false
          notify(errText(error))
          this.rebuild('bottom')
        })
    }
  })
)
