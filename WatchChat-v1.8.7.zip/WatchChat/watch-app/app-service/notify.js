import { BasePage } from '@zeppos/zml/base-page'
import { exit } from '@zos/app-service'
import { set as setAlarm } from '@zos/alarm'
import { handlePendingNotifications } from '../lib/notifications'

const INTERVAL_S = 60   // how often the watch wakes to ask the phone
const HARD_STOP_MS = 25000

// Short background service: woken by an alarm, asks the phone (Side Service)
// for queued WhatsApp notifications, shows them, re-arms the alarm, exits.
AppService(
  BasePage({
    onInit() {
      this.finished = false
      this.guard = setTimeout(() => this.finish(), HARD_STOP_MS)
      try {
        this.request({ method: 'GET_NOTIFICATIONS', params: {} })
          .then((response) => handlePendingNotifications(response, (req) => this.request(req)))
          .catch(() => {})
          .then(() => setTimeout(() => this.finish(), 1500))
      } catch (error) {
        this.finish()
      }
    },

    finish() {
      if (this.finished) return
      this.finished = true
      try { clearTimeout(this.guard) } catch (e) {}
      try { setAlarm({ url: 'app-service/notify', delay: INTERVAL_S, store: true }) } catch (e) {}
      try { exit() } catch (e) {}
    },

    onDestroy() {}
  })
)
