AppSettingsPage({
  build(props) {
    const store = props.settingsStorage
    const field = (label, key, max) => TextInput({
      label,
      value: store.getItem(key) || '',
      maxLength: max,
      subStyle: { color: '#ffffff', fontSize: '14px' },
      onChange: (value) => store.setItem(key, String(value || '').trim())
    })
    return View({ style: { padding: '16px 18px', backgroundColor: '#000000' } }, [
      Text({ style: { color: '#22c55e', fontSize: '18px', marginBottom: '8px' } }, 'WatchChat connection'),
      Text({ style: { color: '#8a919d', fontSize: '13px', marginBottom: '12px' } },
        'Copy both values from WATCH-SETTINGS.txt (created by setup) on your PC.'),
      field('Bridge URL (https://your-ngrok-domain)', 'bridgeUrl', 150),
      field('Bridge key', 'bridgeKey', 100),
      Text({ style: { color: '#8a919d', fontSize: '12px', marginTop: '14px' } },
        'Keyboard choice (Keyflow or system) is switched on the watch, on the chat list screen.')
    ])
  }
})
