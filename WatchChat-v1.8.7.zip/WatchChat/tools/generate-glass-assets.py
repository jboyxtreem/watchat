import numpy as np, os, glob, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont
SS=4
ROOT=sys.argv[1] if len(sys.argv)>1 else '/home/claude/full/WatchChat-Easy/watch-app/assets'
BG=np.array([5,8,24],float)
READ=(42,45,120); UNREAD=(15,111,130); OWN=(14,165,183); OTHER=(63,75,168); AQUA=(29,233,182); COMPOSER=(36,40,110)
down=lambda im,w,h: im.resize((w,h),Image.LANCZOS)
def save(im,name):
    for p in ('balance2','balance2.r','balance2.s'): im.save(os.path.join(ROOT,p,name),optimize=True)
def backdrop(w,h):
    x=np.arange(w,dtype=float); col=np.zeros((w,3))+BG
    col+=np.exp(-((x-0)/190)**2)[:,None]*np.array([6,22,84])
    return Image.fromarray(np.repeat(np.clip(col,0,255)[None],h,axis=0).astype('uint8'),'RGB')
def rr(W,H,x0,y0,x1,y1,r):
    m=Image.new('L',(W*SS,H*SS),0); ImageDraw.Draw(m).rounded_rectangle([x0*SS,y0*SS,x1*SS,y1*SS],r*SS,fill=255); return m
def fill(W,H,mask,color,bg=None):
    base=(bg.resize((W*SS,H*SS)).convert('RGBA') if bg is not None else Image.new('RGBA',(W*SS,H*SS),(0,0,0,0)))
    base.alpha_composite(Image.composite(Image.new('RGBA',(W*SS,H*SS),color+(255,)),Image.new('RGBA',(W*SS,H*SS),(0,0,0,0)),mask)); return down(base,W,H)
def tile(h,color): return fill(480,h,rr(480,h,40,3,439,h-4,min(34,(h-6)/2)),color,backdrop(480,h)).convert('RGB')
save(tile(84,READ),'wa_row_chat.png'); save(tile(76,READ),'wa_row_chat_compact.png')
save(tile(84,UNREAD),'wa_row_unread.png'); save(tile(76,UNREAD),'wa_row_unread_compact.png')
save(tile(76,READ),'wa_row_contact.png'); save(tile(62,READ),'wa_row_setting.png')
save(backdrop(480,480),'wa_backdrop.png')
save(Image.new('RGBA',(480,84),(0,0,0,0)),'wa_head.png')
for n in (22,30,32): save(backdrop(480,n),f'wa_blank_{n}.png')
hb=lambda n:22+20*n
for n in range(1,9):
    save(backdrop(480,hb(n)+2),f'wa_wallpaper_dark_{n}.png'); save(backdrop(480,hb(n)+2+24),f'wa_wallpaper_dark_s{n}.png')
def bez(p0,p1,p2,k=24): return [((1-t)**2*p0[0]+2*(1-t)*t*p1[0]+t*t*p2[0],(1-t)**2*p0[1]+2*(1-t)*t*p1[1]+t*t*p2[1]) for t in np.linspace(0,1,k)]
def bubble(w,h,own):
    m=Image.new('L',(w*SS,h*SS),0); d=ImageDraw.Draw(m); r=min(22,(h-6)/2)
    if own: d.rounded_rectangle([1*SS,1*SS,(w-9)*SS,(h-5)*SS],r*SS,fill=255)
    else: d.rounded_rectangle([9*SS,1*SS,(w-2)*SS,(h-5)*SS],r*SS,fill=255)
    if own: pts=bez((w-9,h-28),(w-9,h-9),(w-1.5,h-2.5))+bez((w-1.5,h-2.5),(w-12,h-1.5),(w-22,h-6))
    else: pts=bez((9,h-28),(9,h-9),(1.5,h-2.5))+bez((1.5,h-2.5),(12,h-1.5),(22,h-6))
    d.polygon([(x*SS,y*SS) for x,y in pts],fill=255)
    return fill(w,h,m.filter(ImageFilter.GaussianBlur(SS*0.4)),OWN if own else OTHER)
for wd in (152,232,330):
    for n in range(1,9):
        for own in (True,False): save(bubble(wd,hb(n),own),f"wa_bubble_{'m' if own else 'o'}_{wd}_{n}_dark.png")
save(fill(20,20,rr(20,20,0,0,19,19,10),AQUA),'wa_unread_badge.png')
bd=backdrop(480,58).crop((104,0,376,58)); save(fill(272,58,rr(272,58,0,0,271,57,29),COMPOSER,bd).convert('RGB'),'wa_composer.png'); print('ok')
