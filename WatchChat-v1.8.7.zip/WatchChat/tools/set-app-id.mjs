import { readFile, writeFile } from 'node:fs/promises'

const [manifestPath, rawId] = process.argv.slice(2)
if (!manifestPath || !/^[1-9][0-9]{0,9}$/.test(String(rawId || ''))) {
  console.error('A valid numeric Zepp appId is required.')
  process.exit(1)
}

const appId = Number(rawId)
if (!Number.isSafeInteger(appId) || appId <= 0 || appId > 2147483647) {
  console.error('The Zepp appId is outside the supported numeric range.')
  process.exit(1)
}

const manifest = JSON.parse(await readFile(manifestPath, 'utf8'))
if (!manifest.app || typeof manifest.app !== 'object') {
  throw new Error('The watch app manifest is missing its app section.')
}
manifest.app.appId = appId
await writeFile(manifestPath, JSON.stringify(manifest, null, 2) + '\n')
console.log('Using Zepp appId ' + appId + ' for this build.')
