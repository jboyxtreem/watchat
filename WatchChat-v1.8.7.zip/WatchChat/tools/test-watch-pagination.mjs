import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

// Load the exact pure helper used by the Zepp pages without changing the
// watch project's bundler/module settings.
const source = await readFile(new URL('../watch-app/lib/paging.js', import.meta.url), 'utf8')
const paging = await import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'))
const { appendUniqueBy, shouldPrefetch, advanceOffset, pageCanContinue } = paging

const collected = []
let offset = 0
let hasMore = true
while (hasMore) {
  const page = Array.from({ length: Math.min(100, 237 - offset) }, (_, i) => ({ id: `chat-${offset + i + 1}` }))
  const added = appendUniqueBy(collected, page, (item) => item.id)
  assert.equal(added, page.length)
  const next = advanceOffset(offset, page.length)
  hasMore = pageCanContinue(next < 237, next > offset, page.length)
  offset = next
}
assert.equal(collected.length, 237)
assert.equal(new Set(collected.map((item) => item.id)).size, 237)
assert.equal(offset, 237)

// Overlapping cursor pages don't duplicate rows, but can still advance while
// the server cursor progresses. An empty page or repeated cursor stops.
const overlapping = [{ id: 'a' }, { id: 'b' }, { id: 'c' }]
assert.equal(appendUniqueBy(overlapping, [{ id: 'b' }, { id: 'c' }, { id: 'd' }], (x) => x.id), 1)
assert.deepEqual(overlapping.map((x) => x.id), ['a', 'b', 'c', 'd'])
assert.equal(pageCanContinue(true, true, 3), true)
assert.equal(pageCanContinue(true, false, 3), false)
assert.equal(pageCanContinue(true, true, 0), false)

// Prefetch begins 15 rows before the end of the 100-row batch.
assert.equal(shouldPrefetch(84, 100, 15), false)
assert.equal(shouldPrefetch(85, 100, 15), true)
assert.equal(shouldPrefetch(99, 100, 15), true)
assert.equal(shouldPrefetch(0, 6, 15), true)

// Contact pages use accountID + contact ID as a stable identity across cursors.
const contacts = []
const contactPages = [
  [{ accountID: 'wa', id: '1' }, { accountID: 'wa', id: '2' }],
  [{ accountID: 'wa', id: '2' }, { accountID: 'wa', id: '3' }],
  [{ accountID: 'wa', id: '4' }]
]
let cursorIndex = 0
let cursor = 'cursor-0'
let contactHasMore = true
while (contactHasMore) {
  const page = contactPages[cursorIndex] || []
  appendUniqueBy(contacts, page, (item) => item.id ? `${item.accountID}|${item.id}` : '')
  const nextCursor = cursorIndex < 2 ? `cursor-${cursorIndex + 1}` : ''
  contactHasMore = pageCanContinue(true, !!nextCursor && nextCursor !== cursor, page.length)
  if (contactHasMore) cursor = nextCursor
  cursorIndex++
}
assert.deepEqual(contacts.map((item) => item.id), ['1', '2', '3', '4'])
assert.equal(contactHasMore, false)

console.log('PASS: 237 chats across three 100-item-or-smaller pages; no duplicates.')
console.log('PASS: overlapping chat/contact pages deduplicated while pagination progresses.')
console.log('PASS: empty/repeated cursors stop and the 15-row prefetch threshold is correct for 100-item batches.')
