import assert from 'node:assert/strict'
import { readdir, access, readFile } from 'node:fs/promises'
import { join } from 'node:path'

const assetsRoot = new URL('../watch-app/assets/', import.meta.url)
const folders = await readdir(assetsRoot)
const required = ['wa_row_chat.png', 'wa_row_chat_compact.png', 'wa_row_unread.png', 'wa_row_unread_compact.png', 'wa_row_contact.png', 'wa_row_setting.png', 'wa_nav_button.png']
const widths = [152, 232, 330]
for (const folder of folders.filter((name) => name.startsWith('balance2'))) {
  const base = join(new URL(folder + '/', assetsRoot).pathname)
  for (const name of required) await access(join(base, name))
  for (let n = 1; n <= 8; n++) {
    await access(join(base, `wa_wallpaper_${n}.png`))
    await access(join(base, `wa_wallpaper_dark_${n}.png`))
    for (const width of widths) for (const side of ['m', 'o']) for (const suffix of ['', '_dark']) {
      await access(join(base, `wa_bubble_${side}_${width}_${n}${suffix}.png`))
    }
  }
}
const indexSource = await readFile(new URL('../watch-app/page/index.js', import.meta.url), 'utf8')
const contactsSource = await readFile(new URL('../watch-app/page/contacts.js', import.meta.url), 'utf8')
assert.match(indexSource, /const PAGE = 8/)
assert.match(indexSource, /const LOAD_AHEAD = 2/)
assert.match(contactsSource, /const PAGE_SIZE = 100/)
assert.match(contactsSource, /const PREFETCH_ROWS = 15/)
console.log(`PASS: all row, wallpaper, and bubble-tail assets exist across ${folders.length} asset packs.`)
console.log('PASS: chats load 8 at a time with a 2-row load-ahead; contacts load 100 at a time and prefetch 15 rows before the end.')
