import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

const indexSource = await readFile(new URL('../watch-app/page/index.js', import.meta.url), 'utf8')
const contactsSource = await readFile(new URL('../watch-app/page/contacts.js', import.meta.url), 'utf8')
const settingsSource = await readFile(new URL('../watch-app/page/settings.js', import.meta.url), 'utf8')

// The inbox has no People/Search/Settings buttons. Settings is reached by the
// documented left-swipe gesture and child pages restore normal swipe handling.
assert.match(indexSource, /onGesture, GESTURE_LEFT/)
assert.match(indexSource, /event === GESTURE_LEFT/)
assert.match(indexSource, /push\(\{ url: 'page\/settings' \}\)/)
assert.match(indexSource, /tv\(24, 10, 280, 36, 'title', 0xffffff, 26, true\)/)
assert.match(indexSource, /tv\(160, 20, 200, 34, 'label', 0xffffff, 26, true\)/)
assert.match(indexSource, /add\(T\.ERR, \{[^\n]+\}, \{ type: 'refresh' \}\)/)
assert.doesNotMatch(indexSource, /navPeople|navSearch|navSettings|PEOPLE|SEARCH/)
assert.doesNotMatch(contactsSource, /openSearch|Find|SEARCH/)
assert.match(contactsSource, /tv\(26, 10, 400, 36, 'name', 0xffffff, 26, true\)/)
assert.match(contactsSource, /tv\(26, 48, 400, 28, 'detail', 0x9a9ca6, 19, true\)/)
assert.match(contactsSource, /tv\(130, 18, 220, 34, 'more', 0xffffff, 24, true\)/)
assert.match(settingsSource, /REPLY KEYBOARD/)
assert.match(settingsSource, /this\.choose\(this\.actions\[index\]\)/)
assert.match(settingsSource, /GET_NOTIFICATION_SETTINGS/)
assert.match(settingsSource, /SET_NOTIFICATION_SETTINGS/)
assert.match(settingsSource, /toggleNotifications/)
assert.match(settingsSource, /cyclePoll/)

console.log('PASS: the chats screen has no redundant top buttons; Settings opens with a left swipe.')
console.log('PASS: Settings retains both keyboard choices and adds working notification controls.')
