# Security and privacy notes

WatchChat handles private WhatsApp content and a Beeper Desktop API token. Treat the
configured project folder as sensitive.

## Protect these files

- `WATCH-SETTINGS.txt` — WatchChat relay URL and private bridge key
- `bridge/.env` — private bridge key and Beeper Desktop API access token
- ngrok configuration, tunnel tokens and private logs

Do not commit, upload, email or share these files. Use the included ignore rules and
review the contents of any ZIP before distributing it. The Beeper token can access
Beeper Desktop API endpoints on the PC, so do not disclose it.

## API exposure model

Beeper Desktop API is designed to listen on localhost by default. WatchChat calls it
from the same PC at `127.0.0.1:23373`. WatchChat's separate relay listens on
`127.0.0.1:8080` and checks a private WatchChat key on every request. ngrok exposes
only that WatchChat relay to the Zepp phone app.

**Do not turn on Beeper Settings → Integrations → Advanced → Remote Access for this
project.** WatchChat does not need Beeper's API exposed to the network. Beeper warns
that exposing its API can allow others to access chat history and send messages.

The current bridge keeps its working chat/message cache in memory and does not write
that cache to a local JSON file. Beeper maintains its own application data. Protect
your Windows account, keep your PC updated and do not run unknown scripts in the
configured project folder.

## Reporting an issue

When reporting a problem, include the app version, watch model, firmware/Zepp app
versions if known, and a concise description of the steps and error. Redact bridge
keys, Beeper tokens, tunnel tokens, WhatsApp phone numbers, message contents and
private details from screenshots and logs.

## WhatsApp connection

Beeper connects to WhatsApp using WhatsApp's linked-device system. This is not the
WhatsApp Business Platform/API. WhatsApp linked-device limits and connection expiry
still apply. Beeper documents that WhatsApp on the primary phone must be opened at
least once every 12–14 days to keep linked devices connected. Some WhatsApp features
are unsupported in Beeper. WatchChat is not affiliated with WhatsApp, Meta or Beeper.
