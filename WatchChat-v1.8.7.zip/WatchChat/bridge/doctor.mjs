// Check the local Beeper connection, WatchChat relay and ngrok tunnel.
import { readFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { hasNgrokToken } from './ngrok-config.mjs'

const ROOT = path.dirname(fileURLToPath(import.meta.url))
const ok = message => console.log('  [OK]  ' + message)
const bad = (message, fix) => console.log('  [FIX] ' + message + '\n        ' + fix)
const read = async name => existsSync(path.join(ROOT, name)) ? readFile(path.join(ROOT, name), 'utf8') : ''
const env = await read('.env')
const envValue = name => ((env.match(new RegExp('^' + name + '=(.*)$', 'm')) || [])[1] || '').trim().replace(/^['"]|['"]$/g, '')

console.log('\nWatchChat connection check\n')

const major = Number(process.versions.node.split('.')[0])
if (major >= 22) ok('Node.js ' + process.versions.node)
else bad('Node.js 22 or later is required.', 'Open WatchChat.bat and choose Set up or repair WatchChat.')

if (existsSync(path.join(ROOT, 'server.mjs')) && existsSync(path.join(ROOT, 'package.json'))) ok('Bridge runtime files are present')
else bad('Bridge runtime files are missing.', 'Re-extract WatchChat and choose Set up or repair WatchChat.')

const PORT = Number(envValue('PORT') || 8080)
const key = envValue('WATCHCHAT_BRIDGE_KEY')
if (key.length >= 32 && !key.includes('CHANGE_ME')) ok('Private WatchChat bridge key is present')
else bad('The bridge key is missing.', 'Open WatchChat.bat and choose Set up or repair WatchChat.')

const beeperToken = envValue('BEEPER_ACCESS_TOKEN')
if (beeperToken.length > 0) ok('Beeper Desktop API token is saved privately on this PC')
else bad('The Beeper API token is missing.', 'Open Beeper Desktop, enable its Desktop API, create an approved connection token, then run Setup / Repair.')

const domain = (await read('ngrok-domain.txt')).trim()
const validDomain = /^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/i.test(domain)
if (validDomain) ok('ngrok development domain is saved')
else bad('The ngrok domain is missing or invalid.', 'Open WatchChat.bat and choose Set up or repair WatchChat.')

const ngrok = spawnSync('ngrok', ['version'], { shell: false, stdio: 'ignore', windowsHide: true })
const hasNgrokToken_ = ngrok.status === 0 && hasNgrokToken()
let tokenNote = false
if (ngrok.status !== 0) bad('ngrok is not available in PATH.', 'Open WatchChat.bat and choose Set up or repair WatchChat.')
else if (!hasNgrokToken_) tokenNote = true
else {
  const configCheck = spawnSync('ngrok', ['config', 'check'], { shell: false, stdio: 'ignore', windowsHide: true })
  if (configCheck.status === 0) ok('ngrok is installed, with an account token and valid configuration')
  else bad('The ngrok configuration is invalid.', 'Run `ngrok config check` in a terminal, fix the reported issue, then run Setup / Repair.')
}

async function get(url) {
  try {
    const response = await fetch(url, {
      headers: {
        'X-WatchChat-Key': key,
        'ngrok-skip-browser-warning': '1',
        'X-WatchChat-Client': 'pc-doctor'
      },
      signal: AbortSignal.timeout(8000)
    })
    return { status: response.status, body: await response.json().catch(() => ({})) }
  } catch { return null }
}

let agentTunnel = false
try {
  const response = await fetch('http://127.0.0.1:4040/api/tunnels', { signal: AbortSignal.timeout(2500) })
  const data = await response.json().catch(() => ({}))
  const expected = 'https://' + domain
  const matching = Array.isArray(data.tunnels)
    ? data.tunnels.find(t => String(t.public_url || '').replace(/\/$/, '') === expected)
    : null
  if (matching) {
    const upstream = String(matching.config?.addr || '')
    agentTunnel = upstream.includes(':' + PORT)
    if (agentTunnel) ok('ngrok agent is serving the saved domain and forwarding to WatchChat port ' + PORT)
    else bad('ngrok has the saved domain open, but it forwards to ' + (upstream || 'an unknown address') + ' instead of WatchChat port ' + PORT + '.', 'Stop the old ngrok session and start WatchChat again so it creates the correct tunnel.')
  } else {
    bad('ngrok is installed, but the expected public endpoint is not active in the local agent.', 'Start WatchChat and inspect the ngrok startup output. Confirm that this domain is assigned to this ngrok account.')
  }
} catch {
  bad('The ngrok local agent API is not responding on 127.0.0.1:4040.', 'Start WatchChat. If it is already running, inspect the ngrok window for an authentication, domain or network error.')
}

const local = key.length >= 32 ? await get('http://127.0.0.1:' + PORT + '/health') : null
if (!local) bad('The WatchChat relay is not responding on this PC.', 'Open WatchChat.bat and choose Start WatchChat.')
else if (local.status === 401) bad('A service on port ' + PORT + ' rejected the key saved in this WatchChat folder (HTTP 401). This does not mean your saved key is wrong; another or older relay may be running, or the live process may have started with a different environment.', 'Do not run Setup / Repair or regenerate your key. Choose Stop WatchChat, close any other WatchChat windows, then start WatchChat again from this folder. If the port is still occupied, close the other process using it.')
else if (local.status !== 200) bad('The local relay returned HTTP ' + local.status + '.', 'Open WatchChat.bat, choose Stop WatchChat, then start it again. Check bridge\\server.log if the problem continues.')
else {
  ok('The local WatchChat relay is running')
  const state = String(local.body.whatsapp || 'unknown')
  const localChats = await get('http://127.0.0.1:' + PORT + '/chats?limit=1&offset=0')
  if (localChats?.status === 200) ok('The local /chats endpoint responds with JSON')
  else bad('The local /chats endpoint failed (HTTP ' + String(localChats?.status || 'no response') + ').', 'Check the WatchChat PC console for Beeper API errors.')

  if (state === 'connected') ok('WhatsApp is connected in Beeper (' + Number(local.body.accounts || 0) + ' account(s))')
  else if (state === 'not-configured') bad('No WhatsApp account is connected in Beeper.', 'Open Beeper Desktop > Accounts > Add an Account > WhatsApp, then link your phone.')
  else if (state === 'setup-required') bad('WatchChat has no Beeper API token.', 'Open Beeper Settings > Integrations, enable the Desktop API and create an approved connection token. Run Setup / Repair.')
  else if (state === 'auth-error') bad('Beeper rejected the saved API token.', 'Create a fresh approved connection token in Beeper Settings > Integrations and run Setup / Repair.')
  else if (state === 'connecting') bad('Beeper is still connecting WhatsApp.', 'Wait for Beeper to finish connecting, then run the check again.')
  else if (state === 'disconnected') bad('WhatsApp needs reconnecting in Beeper.', 'Open Beeper Desktop > Accounts and reconnect the WhatsApp account.')
  else bad('Beeper Desktop API is unavailable.', 'Open Beeper Desktop and make sure its Desktop API is enabled and running.')
}

let remoteOk = false
if (validDomain && local?.status === 200 && agentTunnel) {
  const remote = await get('https://' + domain + '/health')
  if (remote?.status === 200) {
    remoteOk = true
    ok('The ngrok tunnel can reach /health')
    const remoteChats = await get('https://' + domain + '/chats?limit=1&offset=0')
    if (remoteChats?.status === 200) ok('The ngrok tunnel can reach /chats and receives JSON')
    else bad('ngrok /chats failed (HTTP ' + String(remoteChats?.status || 'no response') + ').', 'Check the WatchChat PC console and tunnel request log.')
  } else if (remote?.status === 401) bad('The public tunnel reached a relay that rejected this folder’s saved key (HTTP 401).', 'Check that ngrok forwards to this WatchChat bridge on port ' + PORT + ', then stop and restart WatchChat. Do not regenerate the key unless you intentionally want to replace the watch pairing.')
  else bad('The ngrok public URL did not return the WatchChat health response.', 'Check the ngrok startup output and Traffic Inspector. Restart WatchChat after correcting any domain or connection error.')
}

if (tokenNote) {
  if (remoteOk) ok('ngrok account token is working (confirmed by the tunnel test)')
  else bad('The ngrok account token could not be found.', 'Open WatchChat.bat and choose Set up or repair WatchChat.')
}
console.log('')
