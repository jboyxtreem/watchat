// Finds out whether ngrok has an account token saved, wherever ngrok keeps its config.
// The Microsoft Store build of ngrok stores it in a different folder from the standalone build,
// so ask ngrok where its config is instead of guessing one path.
import { spawnSync } from 'node:child_process'
import { readFileSync, readdirSync } from 'node:fs'
import path from 'node:path'

function tokenFrom(text) {
  const m = String(text).match(/^\s*authtoken\s*:\s*(.*?)\s*$/m)
  return (m?.[1] || '').replace(/\s+#.*$/, '').replace(/^['"]|['"]$/g, '').trim()
}

export function hasNgrokToken() {
  if (process.env.NGROK_AUTHTOKEN?.trim()) return true
  const paths = []
  const r = spawnSync('ngrok', ['config', 'check'], { encoding: 'utf8', windowsHide: true, shell: false })
  const m = ((r.stdout || '') + '\n' + (r.stderr || '')).match(/configuration file at\s+(.+?)\s*$/im)
  if (m) paths.push(m[1].trim())
  const local = process.env.LOCALAPPDATA || path.join(process.env.USERPROFILE || '', 'AppData', 'Local')
  paths.push(path.join(local, 'ngrok', 'ngrok.yml'))
  try {
    const pk = path.join(local, 'Packages')
    for (const d of readdirSync(pk)) {
      if (/^ngrok/i.test(d)) paths.push(path.join(pk, d, 'LocalCache', 'Local', 'ngrok', 'ngrok.yml'))
    }
  } catch {}
  if (process.env.APPDATA) paths.push(path.join(process.env.APPDATA, 'ngrok', 'ngrok.yml'))
  if (process.env.USERPROFILE) paths.push(path.join(process.env.USERPROFILE, '.ngrok2', 'ngrok.yml'))
  for (const p of paths) {
    try { if (tokenFrom(readFileSync(p, 'utf8'))) return true } catch {}
  }
  return false
}
