// Rewrites WATCH-SETTINGS.txt from the bridge's real .env and ngrok domain.
// The Beeper API token is deliberately never displayed or exported to the watch.
import { readFile, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { spawn } from 'node:child_process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.dirname(fileURLToPath(import.meta.url))
const OUT = path.join(ROOT, '..', 'WATCH-SETTINGS.txt')
const read = async name => existsSync(path.join(ROOT, name)) ? readFile(path.join(ROOT, name), 'utf8') : ''
const env = await read('.env')
const readEnv = name => ((env.match(new RegExp('^' + name + '=(.*)$', 'm')) || [])[1] || '').trim().replace(/^['"]|['"]$/g, '')
const key = readEnv('WATCHCHAT_BRIDGE_KEY')
const beeperToken = readEnv('BEEPER_ACCESS_TOKEN')
const domain = (await read('ngrok-domain.txt')).trim()
if (key.length < 32 || !domain) {
  console.log('\nSetup has not finished. Choose Set up or repair WatchChat first.')
  process.exit(1)
}
await writeFile(OUT, [
  'Enter these values in the Zepp app > Devices > your watch > Apps > WatchChat > Settings',
  '',
  'Bridge URL:  https://' + domain,
  'Bridge key:  ' + key,
  '',
  'The Beeper API token is stored privately in bridge\\.env on this PC. Do not enter it in Zepp or share it.',
  'Keep this file private. Anyone with the bridge key can read and send messages through your WhatsApp connection.',
  ''
].join('\r\n'), { mode: 0o600 })
console.log('\nThese are the values the bridge on this PC is using right now:\n')
console.log('  Bridge URL:  https://' + domain)
console.log('  Bridge key:  ' + key)
console.log('\n  The key is ' + key.length + ' characters, using only 0-9 and a-f (all lowercase).')
console.log('  Beeper API token: ' + (beeperToken.length > 0 ? 'configured (hidden)' : 'not configured'))
console.log('  Tip: copy the key and send it to your phone, then paste it into Zepp settings.')
if (process.platform === 'win32') { try { spawn('notepad.exe', [OUT], { detached: true, stdio: 'ignore' }).unref() } catch {} }
