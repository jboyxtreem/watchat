import { createServer } from 'node:http'
import { randomBytes, timingSafeEqual } from 'node:crypto'
import { readFileSync, statSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.dirname(fileURLToPath(import.meta.url))

// Load private configuration without adding a runtime dependency. WatchChat
// deliberately uses its adjacent .env as the single source of truth; inherited
// shell variables can otherwise make the server disagree with the launcher and
// connection checker. Only WatchChat's own settings are read from this file.
const APP_ENV_KEYS = new Set(['PORT', 'WATCHCHAT_BRIDGE_KEY', 'BEEPER_ACCESS_TOKEN', 'BEEPER_API_URL'])
for (const name of APP_ENV_KEYS) delete process.env[name]
try {
  for (const line of readFileSync(path.join(ROOT, '.env'), 'utf8').replace(/^\uFEFF/, '').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$/)
    if (match && APP_ENV_KEYS.has(match[1])) process.env[match[1]] = match[2].replace(/^['"]|['"]$/g, '')
  }
} catch {}

const VERSION = '1.3.0'
const PORT = Number(process.env.PORT || 8080)
const HOST = '127.0.0.1'
const BRIDGE_KEY = String(process.env.WATCHCHAT_BRIDGE_KEY || '')
const BEEPER_TOKEN = String(process.env.BEEPER_ACCESS_TOKEN || '').replace(/^Bearer\s+/i, '').trim()
const BEEPER_BASE = String(process.env.BEEPER_API_URL || 'http://127.0.0.1:23373').replace(/\/+$/, '')
const MAX_BODY = 12000
const MAX_TEXT = 4000
const API_TIMEOUT_MS = 12000
const CHAT_PAGE_SIZE = 200
const MAX_CHAT_CACHE = 10000
const MAX_MESSAGE_CACHE = 6000
const STOP_FLAG = path.join(ROOT, 'stop.flag')
const STARTED = Date.now()
const BRIDGE_SESSION = randomBytes(8).toString('hex')

if (BRIDGE_KEY.length < 32 || BRIDGE_KEY.includes('CHANGE_ME')) {
  throw new Error('WATCHCHAT_BRIDGE_KEY in .env is missing or invalid. Run Setup / Repair.')
}

const beeperBaseUrl = new URL(BEEPER_BASE)
if (!['localhost', '127.0.0.1', '::1'].includes(beeperBaseUrl.hostname)) {
  throw new Error('BEEPER_API_URL must point to a local Beeper Desktop API address.')
}

let connectionState = BEEPER_TOKEN ? 'beeper-unavailable' : 'setup-required'
let lastBeeperError = ''
let accountsCache = []
let accountsCacheAt = 0
let waAccounts = []
let chatItems = []
let chatCursor = ''
let chatHasMore = false
let chatSnapshotAt = 0
let chatAccountKey = ''
let chatRefreshPromise = null
const messageStates = new Map()
const notificationStates = new Map()
const notificationEvents = []
let notificationSeq = 0
let notificationSeeded = false
let notificationScanPromise = null
let stopping = false

const STOP_POLL_MS = 2000

const cleanKey = value => String(value || '').replace(/\s+/g, '').toLowerCase()
function equalSecret(a, b) {
  const x = Buffer.from(cleanKey(a))
  const y = Buffer.from(cleanKey(b))
  return x.length > 0 && x.length === y.length && timingSafeEqual(x, y)
}

function decodeId(value) {
  let result = String(value || '')
  for (let i = 0; i < 3 && /%[0-9a-f]{2}/i.test(result); i++) {
    try { result = decodeURIComponent(result) } catch { break }
  }
  return result
}

function asArray(value) {
  if (Array.isArray(value)) return value
  if (Array.isArray(value?.items)) return value.items
  if (Array.isArray(value?.accounts)) return value.accounts
  return []
}

function apiErrorMessage(status, body) {
  if (status === 401 || status === 403) {
    return 'Beeper rejected the Desktop API token. Recreate the approved connection token in Beeper Settings → Integrations.'
  }
  if (status === 404) return 'The Beeper Desktop API endpoint was not found. Update Beeper Desktop to the latest version.'
  const detail = String(body?.message || body?.error || '').trim()
  return detail ? `Beeper API error (${status}): ${detail.slice(0, 180)}` : `Beeper Desktop API returned HTTP ${status}.`
}

async function beeperRequest(route, options = {}) {
  if (!BEEPER_TOKEN) {
    throw Object.assign(new Error('Beeper Desktop API token is missing. Run Setup / Repair and add your approved connection token.'), { status: 503 })
  }
  const url = new URL(route, BEEPER_BASE + '/')
  const headers = {
    Authorization: `Bearer ${BEEPER_TOKEN}`,
    Accept: 'application/json'
  }
  if (options.body !== undefined) headers['Content-Type'] = 'application/json'
  let response
  try {
    response = await fetch(url, {
      method: options.method || 'GET',
      headers,
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: AbortSignal.timeout(API_TIMEOUT_MS)
    })
  } catch (error) {
    const detail = error?.name === 'TimeoutError'
      ? 'Beeper Desktop did not respond within 12 seconds.'
      : 'Could not reach Beeper Desktop. Make sure the app is open and its Desktop API is enabled.'
    throw Object.assign(new Error(detail), { status: 503 })
  }
  const raw = await response.text()
  let data = {}
  try { data = raw ? JSON.parse(raw) : {} } catch {}
  if (!response.ok) throw Object.assign(new Error(apiErrorMessage(response.status, data)), { status: response.status })
  return data
}

function accountNetwork(account) {
  return String(account?.network || account?.bridge?.type || account?.bridge?.id || '').toLowerCase()
}

function isWhatsAppAccount(account) {
  const network = accountNetwork(account)
  const id = String(account?.accountID || account?.id || '').toLowerCase()
  return network === 'whatsapp' || network.includes('whatsapp') || id.startsWith('local-whatsapp')
}

function usableAccount(account) {
  const status = String(account?.status || '').toLowerCase()
  return !status || status === 'connected' || status === 'backfilling'
}

function getConnectionState(accounts) {
  if (!BEEPER_TOKEN) return 'setup-required'
  if (!accounts.length) return 'not-configured'
  if (accounts.some(usableAccount)) return 'connected'
  if (accounts.some(a => ['connecting', 'backfilling'].includes(String(a?.status || '').toLowerCase()))) return 'connecting'
  return 'disconnected'
}

async function refreshAccounts(force = false) {
  if (!BEEPER_TOKEN) {
    waAccounts = []
    connectionState = 'setup-required'
    lastBeeperError = 'Beeper Desktop API token is not configured.'
    return { accounts: [], state: connectionState, error: lastBeeperError }
  }
  if (!force && Date.now() - accountsCacheAt < 2500) {
    return { accounts: waAccounts, state: connectionState, error: lastBeeperError }
  }
  try {
    const response = await beeperRequest('/v1/accounts')
    accountsCache = asArray(response)
    waAccounts = accountsCache.filter(isWhatsAppAccount)
    connectionState = getConnectionState(waAccounts)
    lastBeeperError = ''
    accountsCacheAt = Date.now()
  } catch (error) {
    connectionState = error.status === 401 || error.status === 403 ? 'auth-error' : 'beeper-unavailable'
    lastBeeperError = error.message
    accountsCacheAt = Date.now()
    waAccounts = []
  }
  return { accounts: waAccounts, state: connectionState, error: lastBeeperError }
}

function requireWhatsApp() {
  if (connectionState === 'connected') return
  const messages = {
    'setup-required': 'Add your Beeper Desktop API access token in WatchChat Setup / Repair.',
    'not-configured': 'No WhatsApp account is connected in Beeper Desktop. Add WhatsApp in Beeper first.',
    'disconnected': 'WhatsApp is disconnected in Beeper. Reconnect it in Beeper Desktop.',
    'connecting': 'Beeper is still connecting WhatsApp. Try again shortly.',
    'auth-error': 'Beeper rejected the API token. Recreate it in Beeper Settings → Integrations and update WatchChat Setup.',
    'beeper-unavailable': 'Beeper Desktop is unavailable. Open Beeper and make sure its Desktop API is enabled.'
  }
  throw Object.assign(new Error(messages[connectionState] || lastBeeperError || 'WhatsApp is not connected in Beeper.'), { status: 503 })
}

function appendQuery(url, key, value) {
  if (value !== undefined && value !== null && value !== '') url.searchParams.append(key, String(value))
}

function dateMs(value) {
  if (typeof value === 'number') return value < 1e11 ? value * 1000 : value
  const parsed = Date.parse(String(value || ''))
  return Number.isFinite(parsed) ? parsed : 0
}

function messageLabel(message) {
  if (message?.isDeleted) return '[deleted message]'
  const text = String(message?.text || '').trim()
  if (text) return text
  const type = String(message?.type || '').toUpperCase()
  const attachment = message?.attachments?.[0] || {}
  if (attachment.isVoiceNote || type === 'VOICE') return '[voice note]'
  if (type === 'IMAGE' || attachment.type === 'img') return '[image]'
  if (type === 'VIDEO' || attachment.type === 'video') return '[video]'
  if (type === 'AUDIO' || attachment.type === 'audio') return '[audio]'
  if (type === 'STICKER' || attachment.isSticker) return '[sticker]'
  if (type === 'FILE' || attachment.fileName) return `[file: ${attachment.fileName || 'attachment'}]`
  if (type === 'LOCATION') return '[location]'
  if (type === 'NOTICE') return '[notice]'
  if (type === 'REACTION') return '[reaction]'
  return '[message]'
}

function messageStatus(message) {
  if (!message?.isSender) return ''
  const status = String(message?.sendStatus?.status || '').toUpperCase()
  if (status === 'PENDING') return 'sending'
  if (status === 'FAIL_RETRIABLE' || status === 'FAIL_PERMANENT') return 'failed'
  if (status === 'SUCCESS') {
    const seen = message.seen
    if (seen === true || (typeof seen === 'string' && seen.length > 0) || (seen && typeof seen === 'object' && Object.values(seen).some(Boolean))) return 'read'
    if (Array.isArray(message.sendStatus?.deliveredToUsers) && message.sendStatus.deliveredToUsers.length) return 'delivered'
    return 'sent'
  }
  return ''
}

function cleanMessage(message) {
  const timestamp = dateMs(message?.timestamp)
  const selfIds = new Set(waAccounts.map(account => String(account?.user?.id || '')).filter(Boolean))
  const groupedReactions = new Map()
  for (const reaction of Array.isArray(message?.reactions) ? message.reactions : []) {
    const key = String(reaction?.reactionKey || '')
    if (!key) continue
    const participantID = String(reaction?.participantID || '')
    const existing = groupedReactions.get(key) || { key, count: 0, mine: false }
    existing.count++
    if (participantID && selfIds.has(participantID)) existing.mine = true
    groupedReactions.set(key, existing)
  }
  return {
    id: String(message?.id || ''),
    text: messageLabel(message),
    senderName: message?.isSender ? 'You' : String(message?.senderName || 'Unknown'),
    isSender: Boolean(message?.isSender),
    timestamp: timestamp ? new Date(timestamp).toISOString() : '',
    ts: timestamp,
    type: String(message?.type || 'TEXT').toUpperCase(),
    status: messageStatus(message),
    reactions: Array.from(groupedReactions.values()).slice(0, 12)
  }
}

function cleanChat(chat) {
  const preview = chat?.preview || {}
  const timestamp = dateMs(chat?.lastActivity || preview.timestamp)
  return {
    id: String(chat?.id || ''),
    title: String(chat?.title || chat?.name || 'Unknown chat'),
    network: 'WhatsApp',
    unreadCount: Math.max(0, Number(chat?.unreadCount || 0)),
    preview: messageLabel(preview),
    lastActivity: timestamp ? new Date(timestamp).toISOString() : '',
    ts: timestamp,
    isGroup: String(chat?.type || '').toLowerCase() === 'group',
    isReadOnly: Boolean(chat?.isReadOnly),
    messageCount: 0
  }
}

function uniqueById(items) {
  const seen = new Set()
  return items.filter(item => {
    const id = String(item?.id || '')
    if (!id || seen.has(id)) return false
    seen.add(id)
    return true
  })
}

// Notification events are derived from Beeper's unread counters and latest
// message timestamps. The first scan seeds the snapshot without notifying for
// old unread chats; later increases/updates become queued events for the phone.
async function scanNotifications() {
  if (notificationScanPromise) return notificationScanPromise
  notificationScanPromise = (async () => {
    const { state } = await refreshAccounts()
    if (state !== 'connected') return { items: [], whatsapp: state }
    const page = await fetchChatPage('')
    for (const chat of page.items) {
      const id = String(chat?.id || '')
      if (!id) continue
      const preview = chat?.preview || {}
      const unreadCount = Math.max(0, Number(chat?.unreadCount || 0))
      const ts = dateMs(chat?.lastActivity || preview?.timestamp)
      const previous = notificationStates.get(id)
      const incomingPreview = preview?.isSender !== true
      const becameUnread = previous && unreadCount > previous.unreadCount
      const newerWhileUnread = previous && unreadCount > 0 && ts > 0 && ts > previous.ts
      const newlySeenUnreadChat = !previous && notificationSeeded && unreadCount > 0

      if (notificationSeeded && incomingPreview && unreadCount > 0 &&
          (becameUnread || newerWhileUnread || newlySeenUnreadChat)) {
        const eventTs = ts || Date.now()
        const event = {
          seq: ++notificationSeq,
          id: id + ':' + eventTs + ':' + unreadCount,
          chatId: id,
          title: String(chat?.title || chat?.name || 'WhatsApp message').slice(0, 90),
          preview: messageLabel(preview).slice(0, 180),
          ts: eventTs,
          unreadCount,
          isGroup: String(chat?.type || '').toLowerCase() === 'group'
        }
        notificationEvents.push(event)
        while (notificationEvents.length > 80) notificationEvents.shift()
      }
      notificationStates.set(id, { unreadCount, ts })
    }
    notificationSeeded = true
    return { items: [], whatsapp: connectionState }
  })()
  try { return await notificationScanPromise }
  finally { notificationScanPromise = null }
}

function currentAccountKey() {
  return waAccounts.map(account => String(account.accountID || account.id || '')).sort().join('|')
}

async function fetchChatPage(cursor = '') {
  const url = new URL('/v1/chats', BEEPER_BASE)
  url.searchParams.set('limit', String(CHAT_PAGE_SIZE))
  for (const account of waAccounts) appendQuery(url, 'accountIDs', account.accountID || account.id)
  if (cursor) {
    url.searchParams.set('cursor', cursor)
    url.searchParams.set('direction', 'before')
  }
  const data = await beeperRequest(url.pathname + url.search)
  return {
    items: asArray(data).filter(chat => {
      const accountID = String(chat?.accountID || '')
      const accountMatch = waAccounts.some(account => String(account.accountID || account.id || '') === accountID)
      return accountMatch || String(chat?.network || '').toLowerCase() === 'whatsapp'
    }),
    cursor: String(data?.oldestCursor || ''),
    hasMore: Boolean(data?.hasMore)
  }
}

async function refreshChatSnapshot() {
  const accountKey = currentAccountKey()
  if (chatRefreshPromise) return chatRefreshPromise
  chatRefreshPromise = (async () => {
    if (chatAccountKey !== accountKey) {
      chatItems = []
      chatCursor = ''
      chatHasMore = false
    }
    const page = await fetchChatPage('')
    chatItems = uniqueById(page.items).slice(0, MAX_CHAT_CACHE)
    chatCursor = page.cursor
    chatHasMore = page.hasMore && Boolean(chatCursor)
    chatAccountKey = accountKey
    chatSnapshotAt = Date.now()
  })()
  try { await chatRefreshPromise } finally { chatRefreshPromise = null }
}

async function ensureChatCount(target) {
  while (chatItems.length < target && chatHasMore && chatCursor) {
    const previousCursor = chatCursor
    const page = await fetchChatPage(previousCursor)
    const existing = new Set(chatItems.map(item => String(item.id)))
    const additions = page.items.filter(item => !existing.has(String(item.id)))
    chatItems.push(...additions)
    chatItems = chatItems.slice(0, MAX_CHAT_CACHE)
    chatCursor = page.cursor || chatCursor
    chatHasMore = page.hasMore && Boolean(chatCursor) && chatCursor !== previousCursor && additions.length > 0
    if (!additions.length || chatCursor === previousCursor) break
  }
}

async function listChatsPage(offset, limit) {
  const { state, error } = await refreshAccounts()
  if (state !== 'connected') {
    return { items: [], hasMore: false, total: 0, offset, limit, whatsapp: state, detail: error || '' }
  }
  if (offset === 0 || !chatSnapshotAt) await refreshChatSnapshot()
  await ensureChatCount(offset + limit)
  const items = chatItems.slice(offset, offset + limit).map(cleanChat)
  return {
    items,
    hasMore: offset + items.length < chatItems.length || chatHasMore,
    total: chatItems.length,
    offset,
    limit,
    whatsapp: connectionState
  }
}

function primaryWhatsAppAccount(requestedID = '') {
  const usable = waAccounts.filter(usableAccount)
  if (requestedID) return usable.find(account => String(account.accountID || account.id || '') === String(requestedID)) || null
  return usable[0] || null
}

function cleanContact(contact, account) {
  return {
    id: String(contact?.id || ''),
    accountID: String(account?.accountID || account?.id || ''),
    fullName: String(contact?.fullName || contact?.name || contact?.username || contact?.phoneNumber || 'WhatsApp contact'),
    username: String(contact?.username || ''),
    phoneNumber: String(contact?.phoneNumber || ''),
    email: String(contact?.email || ''),
    imgURL: String(contact?.imgURL || ''),
    cannotMessage: Boolean(contact?.cannotMessage),
    network: 'WhatsApp'
  }
}

async function listContactsPage({ limit = 100, cursor = '', query = '' } = {}) {
  const { state, error } = await refreshAccounts()
  if (state !== 'connected') {
    return { items: [], hasMore: false, total: 0, nextCursor: '', whatsapp: state, detail: error || '' }
  }
  const account = primaryWhatsAppAccount()
  if (!account) requireWhatsApp()
  const accountID = String(account.accountID || account.id || '')
  if (!accountID) throw Object.assign(new Error('Beeper did not provide a WhatsApp account ID.'), { status: 502 })
  const base = '/v1/accounts/' + encodeURIComponent(accountID) + '/contacts'
  const url = new URL(query ? base : base + '/list', BEEPER_BASE)
  if (query) {
    url.searchParams.set('query', query.slice(0, 120))
  } else {
    url.searchParams.set('limit', String(Math.min(Math.max(Number(limit) || 100, 1), 100)))
    if (cursor) {
      url.searchParams.set('cursor', cursor)
      url.searchParams.set('direction', 'before')
    }
  }
  const data = await beeperRequest(url.pathname + url.search)
  const items = uniqueById(asArray(data).filter(contact => !contact?.isSelf))
    .map(contact => cleanContact(contact, account))
    .filter(contact => contact.id)
  return {
    items,
    hasMore: !query && Boolean(data?.hasMore && data?.oldestCursor),
    nextCursor: !query ? String(data?.oldestCursor || '') : '',
    total: Number(data?.total) || items.length,
    accountID,
    whatsapp: connectionState,
    query: query ? query.slice(0, 120) : ''
  }
}

async function startWhatsAppChat(body) {
  const { state } = await refreshAccounts()
  if (state !== 'connected') requireWhatsApp()
  const accountID = String(body?.accountID || '')
  const account = primaryWhatsAppAccount(accountID)
  if (!account) throw Object.assign(new Error('The selected WhatsApp account is not connected.'), { status: 400 })
  const rawUser = body?.user || {}
  const user = {}
  ;['id', 'fullName', 'email', 'phoneNumber', 'username'].forEach(key => {
    const value = String(rawUser[key] || '').trim()
    if (value) user[key] = value.slice(0, 256)
  })
  if (!Object.keys(user).length) throw Object.assign(new Error('Contact details are missing.'), { status: 400 })
  const result = await beeperRequest('/v1/chats/start', {
    method: 'POST',
    body: { accountID: String(account.accountID || account.id), user, allowInvite: false }
  })
  const id = String(result?.id || result?.chatID || '')
  if (!id) throw Object.assign(new Error('Beeper did not return a conversation ID.'), { status: 502 })
  return {
    id,
    title: String(result?.title || rawUser.fullName || rawUser.phoneNumber || 'WhatsApp contact'),
    network: 'WhatsApp',
    isGroup: false,
    accountID: String(result?.accountID || account.accountID || account.id || '')
  }
}

function messageState(chatID) {
  let state = messageStates.get(chatID)
  if (!state) {
    state = { items: [], oldestCursor: '', newestCursor: '', hasMoreOlder: true, fetched: false, lastPolled: 0, pending: null }
    messageStates.set(chatID, state)
  }
  return state
}

function mergeMessageItems(state, items) {
  const byId = new Map(state.items.map(item => [String(item.id), item]))
  for (const item of items || []) {
    if (item?.id) byId.set(String(item.id), item)
  }
  state.items = [...byId.values()].sort((a, b) => dateMs(a.timestamp) - dateMs(b.timestamp)).slice(-MAX_MESSAGE_CACHE)
}

function messagesRoute(chatID) {
  return '/v1/chats/' + encodeURIComponent(chatID) + '/messages'
}

async function fetchInitialMessages(chatID, state) {
  const data = await beeperRequest(messagesRoute(chatID))
  const items = asArray(data)
  state.items = uniqueById(items).sort((a, b) => dateMs(a.timestamp) - dateMs(b.timestamp))
  state.oldestCursor = String(data?.oldestCursor || '')
  state.newestCursor = String(data?.newestCursor || '')
  state.hasMoreOlder = Boolean(data?.hasMore && state.oldestCursor)
  state.fetched = true
  state.lastPolled = Date.now()
}

async function fetchNewerMessages(chatID, state) {
  if (!state.newestCursor) return
  const url = new URL(messagesRoute(chatID), BEEPER_BASE)
  url.searchParams.set('cursor', state.newestCursor)
  url.searchParams.set('direction', 'after')
  const data = await beeperRequest(url.pathname + url.search)
  mergeMessageItems(state, asArray(data))
  state.newestCursor = String(data?.newestCursor || state.newestCursor)
  state.lastPolled = Date.now()
}

async function fetchOlderMessages(chatID, state) {
  if (!state.hasMoreOlder || !state.oldestCursor) return 0
  const previousCursor = state.oldestCursor
  const url = new URL(messagesRoute(chatID), BEEPER_BASE)
  url.searchParams.set('cursor', previousCursor)
  url.searchParams.set('direction', 'before')
  const data = await beeperRequest(url.pathname + url.search)
  const items = asArray(data)
  const before = state.items.length
  mergeMessageItems(state, items)
  const added = state.items.length - before
  state.oldestCursor = String(data?.oldestCursor || state.oldestCursor)
  state.hasMoreOlder = Boolean(data?.hasMore && state.oldestCursor && state.oldestCursor !== previousCursor && added > 0)
  return Math.max(0, added)
}

async function markChatRead(chatID, state) {
  const latest = state.items[state.items.length - 1]
  const body = latest?.id ? { messageID: String(latest.id) } : {}
  await beeperRequest('/v1/chats/' + encodeURIComponent(chatID) + '/read', { method: 'POST', body })
}

async function getMessagesPage(chatID, limit, offset, shouldMarkRead) {
  const { state: waState } = await refreshAccounts()
  if (waState !== 'connected') requireWhatsApp()
  const state = messageState(chatID)
  if (!state.fetched) await fetchInitialMessages(chatID, state)
  else if (offset === 0 && Date.now() - state.lastPolled > 3000) await fetchNewerMessages(chatID, state)

  const required = offset + limit
  while (state.items.length < required && state.hasMoreOlder) {
    const added = await fetchOlderMessages(chatID, state)
    if (!added) break
  }
  if (shouldMarkRead) {
    try { await markChatRead(chatID, state) }
    catch (error) { console.error('[Beeper] Could not mark chat as read:', error.message) }
  }

  const end = Math.max(0, state.items.length - offset)
  const start = Math.max(0, end - limit)
  const items = state.items.slice(start, end).map(cleanMessage)
  return {
    items,
    hasMore: start > 0 || state.hasMoreOlder,
    typing: false,
    isGroup: false,
    limit,
    offset,
    total: state.items.length
  }
}

function json(res, status, data) {
  const body = Buffer.from(JSON.stringify(data))
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  })
  res.end(body)
}

async function readBody(req) {
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    const part = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += part.length
    if (size > MAX_BODY) throw Object.assign(new Error('Request body too large.'), { status: 413 })
    chunks.push(part)
  }
  const raw = Buffer.concat(chunks).toString('utf8')
  try { return JSON.parse(raw || '{}') }
  catch { throw Object.assign(new Error('Invalid JSON request.'), { status: 400 }) }
}

async function route(req, res) {
  const url = new URL(req.url, `http://${HOST}:${PORT}`)
  if (!equalSecret(req.headers['x-watchchat-key'] || '', BRIDGE_KEY)) {
    await new Promise(resolve => setTimeout(resolve, 350))
    return json(res, 401, { error: 'Invalid WatchChat bridge key.' })
  }

  if (url.pathname === '/health' && req.method === 'GET') {
    return json(res, 200, {
      ok: true,
      version: VERSION,
      backend: 'Beeper Desktop API',
      whatsapp: connectionState,
      accounts: waAccounts.length,
      chats: chatItems.length,
      messages: [...messageStates.values()].reduce((sum, state) => sum + state.items.length, 0),
      detail: lastBeeperError || ''
    })
  }

  if (url.pathname === '/notifications' && req.method === 'GET') {
    try {
      await scanNotifications()
      const clientSession = String(url.searchParams.get('session') || '')
      const requestedAfter = Number(url.searchParams.get('after') || 0)
      const after = clientSession && clientSession !== BRIDGE_SESSION ? 0 : Math.max(0, Number.isFinite(requestedAfter) ? requestedAfter : 0)
      const items = notificationEvents.filter(item => item.seq > after).slice(0, 20)
      return json(res, 200, { session: BRIDGE_SESSION, cursor: notificationSeq, items, whatsapp: connectionState })
    } catch (error) {
      const status = error.status === 401 ? 503 : (error.status || 502)
      return json(res, status, { error: error.message })
    }
  }

  if (url.pathname === '/chats' && req.method === 'GET') {
    const requestedLimit = Number(url.searchParams.get('limit') || 100)
    const requestedOffset = Number(url.searchParams.get('offset') || 0)
    const limit = Number.isInteger(requestedLimit) ? Math.min(Math.max(requestedLimit, 1), 100) : 100
    const offset = Number.isInteger(requestedOffset) ? Math.min(Math.max(requestedOffset, 0), MAX_CHAT_CACHE) : 0
    try {
      const result = await listChatsPage(offset, limit)
      return json(res, 200, result)
    } catch (error) {
      return json(res, error.status === 401 ? 503 : (error.status || 502), { error: error.message })
    }
  }

  if (url.pathname === '/contacts' && req.method === 'GET') {
    const limit = Math.min(Math.max(Number(url.searchParams.get('limit') || 100), 1), 100)
    const cursor = String(url.searchParams.get('cursor') || '')
    const query = String(url.searchParams.get('query') || '').trim()
    try {
      const result = await listContactsPage({ limit, cursor, query })
      return json(res, 200, result)
    } catch (error) {
      const status = error.status === 401 ? 503 : (error.status || 502)
      return json(res, status, { error: error.message })
    }
  }

  if (url.pathname === '/start-chat' && req.method === 'POST') {
    try {
      const body = await readBody(req)
      const chat = await startWhatsAppChat(body)
      return json(res, 200, { chat })
    } catch (error) {
      const status = error.status === 401 ? 503 : (error.status || 502)
      return json(res, status, { error: error.message })
    }
  }

  if (url.pathname === '/messages' && req.method === 'GET') {
    const chatID = decodeId(url.searchParams.get('chat_id'))
    if (!chatID) return json(res, 400, { error: 'Missing chat_id.' })
    const requestedLimit = Number(url.searchParams.get('limit') || 20)
    const requestedOffset = Number(url.searchParams.get('offset') || 0)
    const limit = Number.isInteger(requestedLimit) ? Math.min(Math.max(requestedLimit, 1), 100) : 20
    const offset = Number.isInteger(requestedOffset) ? Math.min(Math.max(requestedOffset, 0), MAX_MESSAGE_CACHE) : 0
    try {
      const result = await getMessagesPage(chatID, limit, offset, url.searchParams.get('read') === '1')
      return json(res, 200, result)
    } catch (error) {
      const status = error.status === 401 ? 503 : (error.status || 502)
      return json(res, status, { error: error.message })
    }
  }

  if (url.pathname === '/message' && req.method === 'GET') {
    const chatID = decodeId(url.searchParams.get('chat_id'))
    const messageID = decodeId(url.searchParams.get('message_id'))
    if (!chatID || !messageID) return json(res, 400, { error: 'Missing chat_id or message_id.' })
    try {
      const { state } = await refreshAccounts()
      if (state !== 'connected') requireWhatsApp()
      const message = await beeperRequest('/v1/chats/' + encodeURIComponent(chatID) + '/messages/' + encodeURIComponent(messageID))
      const cache = messageState(chatID)
      if (cache.fetched) mergeMessageItems(cache, [message])
      return json(res, 200, { item: cleanMessage(message) })
    } catch (error) {
      const status = error.status === 401 ? 503 : (error.status || 502)
      return json(res, status, { error: error.message })
    }
  }

  if (url.pathname === '/history' && req.method === 'POST') {
    const body = await readBody(req)
    const chatID = decodeId(body.chat_id)
    const count = Math.min(200, Math.max(1, Number(body.count) || 50))
    if (!chatID) return json(res, 400, { error: 'Missing chat_id.' })
    try {
      const { state } = await refreshAccounts()
      if (state !== 'connected') requireWhatsApp()
      const cache = messageState(chatID)
      if (!cache.fetched) await fetchInitialMessages(chatID, cache)
      let added = 0
      let pages = 0
      while (added < count && cache.hasMoreOlder && pages < 5) {
        added += await fetchOlderMessages(chatID, cache)
        pages++
      }
      return json(res, 200, { itemsAdded: added, total: cache.items.length, hasMore: cache.hasMoreOlder })
    } catch (error) {
      const status = error.status === 401 ? 503 : (error.status || 502)
      return json(res, status, { error: error.message })
    }
  }

  if (url.pathname === '/send' && req.method === 'POST') {
    const body = await readBody(req)
    const chatID = decodeId(body.chat_id)
    const text = String(body.text || '').trim()
    if (!chatID || !text) return json(res, 400, { error: 'Chat and message text are required.' })
    if (text.length > MAX_TEXT) return json(res, 400, { error: `Message is too long (maximum ${MAX_TEXT} characters).` })
    try {
      const { state } = await refreshAccounts()
      if (state !== 'connected') requireWhatsApp()
      const result = await beeperRequest('/v1/chats/' + encodeURIComponent(chatID) + '/messages', {
        method: 'POST',
        body: { text }
      })
      return json(res, 200, { sent: true, id: String(result?.pendingMessageID || '') })
    } catch (error) {
      const status = error.status === 401 ? 503 : (error.status || 502)
      return json(res, status, { error: error.message })
    }
  }

  if ((url.pathname === '/react' || url.pathname === '/unreact') && req.method === 'POST') {
    const body = await readBody(req)
    const chatID = decodeId(body.chat_id)
    const messageID = decodeId(body.message_id)
    const reactionKey = String(body.reaction_key || '').trim()
    if (!chatID || !messageID || !reactionKey) {
      return json(res, 400, { error: 'Chat, message and reaction are required.' })
    }
    if (reactionKey.length > 64) return json(res, 400, { error: 'Reaction key is too long.' })
    try {
      const { state } = await refreshAccounts()
      if (state !== 'connected') requireWhatsApp()
      const base = '/v1/chats/' + encodeURIComponent(chatID) + '/messages/' + encodeURIComponent(messageID) + '/reactions'
      if (url.pathname === '/react') {
        const result = await beeperRequest(base, {
          method: 'POST',
          body: { reactionKey, transactionID: 'watchchat_' + randomBytes(10).toString('hex') }
        })
        return json(res, 200, { success: true, reactionKey: String(result?.reactionKey || reactionKey) })
      }
      const result = await beeperRequest(base + '/' + encodeURIComponent(reactionKey), { method: 'DELETE' })
      return json(res, 200, { success: true, reactionKey: String(result?.reactionKey || reactionKey) })
    } catch (error) {
      const status = error.status === 401 ? 503 : (error.status || 502)
      return json(res, status, { error: error.message })
    }
  }

  return json(res, 404, { error: 'Unknown bridge endpoint.' })
}

const server = createServer((req, res) => {
  const routePath = (() => { try { return new URL(req.url, 'http://localhost').pathname } catch { return '/' } })()
  const client = String(req.headers['x-watchchat-client'] || 'unknown-client').slice(0, 40)
  console.log('[HTTP] ' + req.method + ' ' + routePath + ' [' + client + ']')
  Promise.resolve(route(req, res)).catch(error => {
    const status = error.status || 502
    json(res, status, { error: status >= 500 ? 'WatchChat could not complete the Beeper operation. Check the PC console.' : error.message })
    console.error('[WatchChat] Request failed:', error.message)
  })
})

server.on('error', error => {
  if (error.code === 'EADDRINUSE') console.error(`Port ${PORT} is already in use. Stop the older WatchChat process before starting this version.`)
  else console.error('Bridge server error:', error.message)
  process.exit(1)
})

server.listen(PORT, HOST, () => {
  console.log(`WatchChat ${VERSION} Beeper bridge listening at http://${HOST}:${PORT}`)
  if (!BEEPER_TOKEN) {
    console.log('Beeper API token is missing. Run Setup / Repair and add an approved connection token.')
  } else {
    console.log('Waiting for Beeper Desktop API at ' + BEEPER_BASE)
    void refreshAccounts(true).then(result => {
      if (result.state === 'connected') console.log(`Beeper connected. WhatsApp account(s): ${result.accounts.length}.`)
      else console.log('Beeper status: ' + result.state + (result.error ? ' — ' + result.error : ''))
    })
  }
})

function stop() {
  if (stopping) return
  stopping = true
  console.log('Shutting down WatchChat bridge...')
  server.close(() => process.exit(0))
  setTimeout(() => process.exit(0), 4000).unref()
}

process.on('unhandledRejection', error => console.error('Unhandled rejection:', error?.message || error))
setInterval(() => {
  try { if (statSync(STOP_FLAG).mtimeMs > STARTED) stop() } catch {}
}, STOP_POLL_MS).unref()
process.on('SIGINT', stop)
process.on('SIGTERM', stop)
