// First-time setup: generates the private bridge key and configures ngrok.
import { readFile, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { randomBytes } from 'node:crypto'
import { createInterface } from 'node:readline/promises'
import { spawn, spawnSync } from 'node:child_process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { hasNgrokToken } from './ngrok-config.mjs'

const ROOT = path.dirname(fileURLToPath(import.meta.url))
const ENV = path.join(ROOT, '.env')
const DOMAIN_FILE = path.join(ROOT, 'ngrok-domain.txt')
const OUT = path.join(ROOT, '..', 'WATCH-SETTINGS.txt')
const rl = createInterface({ input: process.stdin, output: process.stdout })

function run(command, args = [], inherit = false) {
  const result = spawnSync(command, args, {
    shell: false,
    windowsHide: true,
    stdio: inherit ? 'inherit' : 'ignore'
  })
  if (result.error) return { status: null, error: result.error }
  return { status: result.status, error: null }
}

function openUrl(url) {
  if (process.platform === 'win32') {
    return run('cmd.exe', ['/d', '/c', 'start', '', url], false)
  }
  return run('xdg-open', [url], false)
}

function validateDomain(input) {
  let candidate = String(input || '').trim()
  if (!candidate) return null

  if (/^https?:\/\//i.test(candidate)) {
    try {
      const parsed = new URL(candidate)
      if (parsed.protocol !== 'https:' || parsed.username || parsed.password ||
          parsed.port || (parsed.pathname !== '/' && parsed.pathname !== '') ||
          parsed.search || parsed.hash) return null
      candidate = parsed.hostname
    } catch {
      return null
    }
  }

  candidate = candidate.toLowerCase().replace(/\.$/, '')
  if (candidate.length > 253 || !candidate.includes('.') ||
      !/^[a-z0-9.-]+$/.test(candidate)) return null

  const labels = candidate.split('.')
  if (labels.some(label => !label || label.length > 63 ||
      !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(label))) return null
  return candidate
}

function finish(code) {
  rl.close()
  process.exit(code)
}

// 1. Generate or reuse the private bridge key.
let env = existsSync(ENV) ? await readFile(ENV, 'utf8') : ''
let key = (env.match(/^WATCHCHAT_BRIDGE_KEY=(.*)$/m) || [])[1]?.trim() || ''
if (key.length < 32 || key.includes('CHANGE_ME')) {
  key = randomBytes(32).toString('hex')
  env = /^WATCHCHAT_BRIDGE_KEY=/m.test(env)
    ? env.replace(/^WATCHCHAT_BRIDGE_KEY=.*$/m, 'WATCHCHAT_BRIDGE_KEY=' + key)
    : 'WATCHCHAT_BRIDGE_KEY=' + key + '\n' + env
  await writeFile(ENV, env, { mode: 0o600 })
  console.log('\n[ok] A private bridge key has been generated.')
} else {
  console.log('\n[ok] The existing private bridge key will be kept.')
}

// 2. Confirm ngrok is installed.
let ngrokCheck = run('ngrok', ['version'])
if (ngrokCheck.status !== 0) {
  console.log('\nInstalling ngrok with Windows Package Manager...')
  const install = run('winget', [
    'install', 'ngrok', '-s', 'msstore',
    '--accept-source-agreements', '--accept-package-agreements'
  ], true)
  if (install.status !== 0) {
    console.log('\nngrok could not be installed automatically.')
    console.log('Install it from https://ngrok.com/download, then run WatchChat.bat and choose Setup / Repair again.')
    finish(1)
  }
  console.log('\nngrok has been installed. Close and reopen WatchChat.bat, then choose Setup / Repair again.')
  finish(2)
}

// 3. Confirm an authtoken is actually saved. `config check` validates YAML,
// but a valid config file can still be missing the account token entirely.
const hasToken = hasNgrokToken()

if (!hasToken) {
  console.log('\n--- ngrok account ---')
  console.log('A browser page will open. Sign in to ngrok or create a free account.')
  openUrl('https://dashboard.ngrok.com/get-started/your-authtoken')
  const token = (await rl.question('\nPaste your ngrok authtoken and press Enter: ')).trim()
  if (token.length < 20 || /[\r\n\0]/.test(token)) {
    console.log('\nThe authtoken does not look valid. Run Setup / Repair again.')
    finish(1)
  }

  console.log('\nSaving the ngrok authtoken...')
  const tokenResult = run('ngrok', ['config', 'add-authtoken', token], true)
  if (tokenResult.status !== 0) {
    console.log('\nngrok did not accept the authtoken. Check it and run Setup / Repair again.')
    finish(1)
  }
}

const configCheck = run('ngrok', ['config', 'check'], true)
if (configCheck.status !== 0) {
  console.log('\nngrok could not validate its configuration. Run `ngrok config check` in a terminal to see the details, fix the issue, then run Setup / Repair again.')
  finish(1)
}

// 4. Save the free development domain assigned to the ngrok account.
let domain = existsSync(DOMAIN_FILE)
  ? validateDomain(await readFile(DOMAIN_FILE, 'utf8'))
  : null

if (!domain) {
  openUrl('https://dashboard.ngrok.com/domains')
  console.log('\nCopy the free development domain assigned to your account from the ngrok Domains page.')
  domain = validateDomain(await rl.question('Paste the domain (for example, name.ngrok-free.dev or name.ngrok-free.app): '))
  if (!domain) {
    console.log('\nThat domain is not valid. Copy the hostname shown in your ngrok dashboard and run Setup / Repair again.')
    finish(1)
  }
  await writeFile(DOMAIN_FILE, domain + '\n', { mode: 0o600 })
}

// 5. Configure the Beeper Desktop API token. The token stays on this PC and is
// never copied into the Zepp settings file or sent through the public tunnel.
const readEnvValue = (name) => {
  const match = env.match(new RegExp('^' + name + '=(.*)$', 'm'))
  return (match?.[1] || '').trim().replace(/^['"]|['"]$/g, '')
}
let beeperToken = readEnvValue('BEEPER_ACCESS_TOKEN').replace(/^Bearer\s+/i, '').trim()
console.log('\n--- Beeper Desktop setup ---')
console.log('WatchChat uses Beeper instead of connecting to WhatsApp itself.')
console.log('1. Install and open Beeper Desktop for Windows.')
console.log('2. Add WhatsApp in Beeper: Accounts > Add an Account > WhatsApp.')
console.log('3. Scan the QR code shown in Beeper using WhatsApp > Settings > Linked devices > Link a device.')
console.log('4. In Beeper Settings > Integrations, make sure the Desktop API is enabled and running.')
console.log('5. Under Approved connections, click + and create a token for WatchChat.')
console.log('\nBeeper download: https://www.beeper.com/download/windows')
console.log('API instructions: https://developers.beeper.com/desktop-api/')
if (!beeperToken) openUrl('https://www.beeper.com/download/windows')
const tokenPrompt = beeperToken
  ? 'Paste a replacement Beeper API token, or press Enter to keep the saved token: '
  : 'Paste the Beeper Desktop API access token: '
const enteredToken = (await rl.question(tokenPrompt)).trim().replace(/^Bearer\s+/i, '')
if (enteredToken) {
  if (/^[\s]*$/.test(enteredToken) || /[\r\n\0]/.test(enteredToken)) {
    console.log('\nThat token does not look valid. Create an approved connection token in Beeper and run Setup / Repair again.')
    finish(1)
  }
  beeperToken = enteredToken
  env = /^BEEPER_ACCESS_TOKEN=/m.test(env)
    ? env.replace(/^BEEPER_ACCESS_TOKEN=.*$/m, 'BEEPER_ACCESS_TOKEN=' + beeperToken)
    : env.replace(/\s*$/, '') + '\nBEEPER_ACCESS_TOKEN=' + beeperToken + '\n'
  await writeFile(ENV, env, { mode: 0o600 })
  console.log('\n[ok] Beeper access token saved privately on this PC.')
} else if (beeperToken) {
  console.log('\n[ok] The existing Beeper Desktop API token will be kept.')
} else {
  console.log('\nA Beeper API token is required. Run Setup / Repair again after creating one.')
  finish(1)
}

rl.close()

// 6. Write the phone-app settings to a local text file.
await writeFile(OUT, [
  'Enter these values in the Zepp app > Devices > your watch > Apps > WatchChat > Settings',
  '',
  'Bridge URL:  https://' + domain,
  'Bridge key:  ' + key,
  '',
  'Keep this file private. Anyone with the bridge key can read and send messages through your WhatsApp connection. Your Beeper API token stays separately on this PC.',
  ''
].join('\r\n'), { mode: 0o600 })

console.log('\n[ok] Setup is complete. Opening WATCH-SETTINGS.txt.')
if (process.platform === 'win32') {
  try { spawn('notepad.exe', [OUT], { detached: true, stdio: 'ignore', windowsHide: false }).unref() }
  catch { console.log('Open WATCH-SETTINGS.txt in this folder to view the two settings.') }
} else {
  console.log('Your settings are in WATCH-SETTINGS.txt.')
}
