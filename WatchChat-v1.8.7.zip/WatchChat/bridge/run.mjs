// Starts the local WatchChat API first, then starts and verifies its ngrok tunnel.
// This prevents the old launcher from reporting success merely because ngrok's
// process stayed alive while the actual upstream bridge was not ready.
import { spawn } from 'node:child_process'
import { readFile, stat, writeFile, unlink } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = path.dirname(fileURLToPath(import.meta.url))
const ENV_PATH = path.join(ROOT, '.env')
const DOMAIN_PATH = path.join(ROOT, 'ngrok-domain.txt')
const STOP_PATH = path.join(ROOT, 'stop.flag')
const HIDDEN = process.argv.includes('--hidden')
const REUSE_BRIDGE = process.argv.includes('--reuse-bridge')
const PORT = Number(await readEnv('PORT') || 8080)
const KEY = await readEnv('WATCHCHAT_BRIDGE_KEY')
const DOMAIN = await readFile(DOMAIN_PATH, 'utf8').then(value => value.trim()).catch(() => '')
const BASE_URL = `https://${DOMAIN}`
const LOCAL_URL = `http://127.0.0.1:${PORT}`
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

async function readEnv(name) {
  try {
    const text = await readFile(ENV_PATH, 'utf8')
    const match = text.match(new RegExp('^' + name + '=(.*)$', 'm'))
    return (match?.[1] || '').trim().replace(/^['"]|['"]$/g, '')
  } catch { return '' }
}

function log(message) {
  if (!HIDDEN) console.log(message)
}

async function requestHealth(url, timeout = 3500, abortSignal) {
  const healthUrl = String(url).replace(/\/$/, '') + '/health'
  try {
    const signal = abortSignal
      ? AbortSignal.any([abortSignal, AbortSignal.timeout(timeout)])
      : AbortSignal.timeout(timeout)
    const response = await fetch(healthUrl, {
      headers: {
        'X-WatchChat-Key': KEY,
        'ngrok-skip-browser-warning': '1',
        'X-WatchChat-Client': 'pc-startup-check'
      },
      signal
    })
    const body = await response.json().catch(() => ({}))
    return { status: response.status, body }
  } catch (error) {
    return { error: error?.message || String(error) }
  }
}

async function waitForHealth(url, maxMs, child, abortSignal) {
  const end = Date.now() + maxMs
  let last = null
  while (Date.now() < end) {
    if (child?.exitCode !== null && child?.exitCode !== undefined) {
      throw new Error(`The WatchChat bridge process exited with code ${child.exitCode}. Check bridge\server.log.`)
    }
    if (abortSignal?.aborted) throw new Error('The tunnel health check was cancelled.')
    last = await requestHealth(url, 4500, abortSignal)
    if (abortSignal?.aborted) throw new Error('The tunnel health check was cancelled.')
    if (last.status === 200 && last.body?.ok === true) return last.body
    await sleep(750)
  }
  const detail = last?.error || (last?.status ? `HTTP ${last.status}` : 'no response')
  throw new Error(`Could not verify ${url}/health (${detail}). Check the WatchChat bridge logs.`)
}

function spawnChild(command, args, label) {
  const child = spawn(command, args, {
    cwd: ROOT,
    windowsHide: HIDDEN,
    stdio: HIDDEN ? 'ignore' : 'inherit',
    shell: false
  })
  child.on('error', error => log(`[WatchChat] ${label} failed to start: ${error.message}`))
  return child
}

let bridge = null
let ngrok = null
let reusedTunnelUri = ''
let stopping = false
let stopTimer = null
let exitError = null

function stopChildren() {
  stopping = true
  if (stopTimer) clearInterval(stopTimer)
  if (ngrok && ngrok.exitCode === null) {
    try { ngrok.kill('SIGTERM') } catch {}
  }
  if (bridge && bridge.exitCode === null) {
    try { bridge.kill('SIGTERM') } catch {}
  }
}

process.on('SIGINT', stopChildren)
process.on('SIGTERM', stopChildren)

try {
  if (KEY.length < 32) throw new Error('The WatchChat bridge key is missing. Run Setup / Repair.')
  if (!/^[a-z0-9.-]+$/i.test(DOMAIN) || !DOMAIN.includes('.')) throw new Error('The saved ngrok domain is invalid. Run Setup / Repair.')

  // Clear only a stale stop marker before launching this session.
  try { await unlink(STOP_PATH) } catch {}

  if (REUSE_BRIDGE) {
    log('[1/3] Checking the existing local WatchChat bridge...')
    await waitForHealth(LOCAL_URL, 8000, null)
    log('[OK] Existing WatchChat bridge is responding on 127.0.0.1:' + PORT)
  } else {
    log('[1/3] Starting the local WatchChat bridge first...')
    bridge = spawnChild(process.execPath, ['server.mjs'], 'WatchChat bridge')
    if (bridge.pid) await writeFile(path.join(ROOT, 'server.pid'), String(bridge.pid) + '\n')
    await waitForHealth(LOCAL_URL, 15000, bridge)
    log('[OK] Local WatchChat API is responding on 127.0.0.1:' + PORT)
  }

  log('[2/3] Checking the ngrok agent and saved public domain...')
  let agentAvailable = false
  let agentTunnels = []
  try {
    const agentResponse = await fetch('http://127.0.0.1:4040/api/tunnels', { signal: AbortSignal.timeout(2000) })
    if (agentResponse.ok) {
      const agentData = await agentResponse.json().catch(() => ({}))
      agentAvailable = true
      agentTunnels = Array.isArray(agentData.tunnels) ? agentData.tunnels : []
    }
  } catch {}

  const existingTunnel = agentTunnels.find(t => String(t.public_url || '').replace(/\/$/, '') === BASE_URL)
  if (existingTunnel) {
    const upstream = String(existingTunnel.config?.addr || '')
    if (!upstream.includes(':' + PORT)) {
      throw new Error(`The saved ngrok domain is already open, but it forwards to ${upstream || 'an unknown local address'} instead of port ${PORT}. Stop the old ngrok session, then start WatchChat again.`)
    }
    reusedTunnelUri = String(existingTunnel.uri || '')
    log('[OK] Reusing the existing ngrok endpoint for ' + BASE_URL)
  } else if (agentAvailable) {
    const running = agentTunnels.map(t => `${t.public_url || t.name} → ${t.config?.addr || 'unknown upstream'}`).join('; ')
    throw new Error('An ngrok agent is already running on this PC, but it is not serving the saved WatchChat domain. ' + (running ? 'Current endpoint(s): ' + running + '. ' : '') + 'Close the other ngrok session/window, then start WatchChat again.')
  } else {
    log('[2/3] No existing ngrok agent found; starting a new tunnel...')
    ngrok = spawnChild('ngrok', ['http', String(PORT), `--url=${BASE_URL}`], 'ngrok')
    if (ngrok.pid) await writeFile(path.join(ROOT, 'ngrok.pid'), String(ngrok.pid) + '\n')
    const ngrokExit = new Promise((_, reject) => {
      ngrok.once('error', error => { if (!stopping) reject(new Error(`ngrok could not start: ${error.message}`)) })
      ngrok.once('exit', (code, signal) => {
        if (!stopping) reject(new Error(`ngrok exited unexpectedly (code ${code ?? 'unknown'}, signal ${signal || 'none'}). Check the ngrok error shown above.`))
      })
    })
    const tunnelAbort = new AbortController()
    const tunnelTest = waitForHealth(BASE_URL, 35000, null, tunnelAbort.signal)
    try { await Promise.race([tunnelTest, ngrokExit]) }
    finally { tunnelAbort.abort() }
  }
  if (reusedTunnelUri) await waitForHealth(BASE_URL, 12000, null)
  else if (!ngrok) await waitForHealth(BASE_URL, 12000, null)
  log('[OK] Public tunnel verified: ' + BASE_URL + '/health')
  log('[3/3] WatchChat is ready. Open WatchChat on your watch and tap SYNC.')
  log('[INFO] The startup test itself has sent one request through ngrok. Inspect live traffic at http://127.0.0.1:4040. Later watch requests should appear as [zepp-watch] in both the inspector and the PC log.')

  const startedAt = Date.now()
  stopTimer = setInterval(async () => {
    if (stopping) return
    try {
      const marker = await stat(STOP_PATH)
      if (marker.mtimeMs >= startedAt - 1000) stopChildren()
    } catch {}
    if (bridge && bridge.exitCode !== null && !stopping) {
      exitError = new Error(`WatchChat bridge exited unexpectedly with code ${bridge.exitCode}.`)
      stopChildren()
    }
    if (ngrok && ngrok.exitCode !== null && !stopping) {
      exitError = new Error(`ngrok exited unexpectedly with code ${ngrok.exitCode}.`)
      stopChildren()
    }
  }, 500)
  stopTimer.unref()

  await new Promise(resolve => {
    const poll = setInterval(() => {
      if (stopping) { clearInterval(poll); resolve() }
    }, 250)
  })
} catch (error) {
  exitError = error
  stopChildren()
  if (!HIDDEN) {
    console.error('\n[STARTUP FAILED] ' + error.message)
    console.error('Run option 5 (Check connection) for a detailed report.\n')
  }
} finally {
  if (stopTimer) clearInterval(stopTimer)
  if (reusedTunnelUri) {
    try { await fetch('http://127.0.0.1:4040' + reusedTunnelUri, { method: 'DELETE', signal: AbortSignal.timeout(2500) }) } catch {}
  }
  if (ngrok && ngrok.exitCode === null) {
    try { ngrok.kill('SIGTERM') } catch {}
    await Promise.race([new Promise(resolve => ngrok.once('exit', resolve)), sleep(2500)])
  }
  if (bridge && bridge.exitCode === null) {
    try { bridge.kill('SIGTERM') } catch {}
    await Promise.race([new Promise(resolve => bridge.once('exit', resolve)), sleep(2500)])
  }
  try { await unlink(path.join(ROOT, 'ngrok.pid')) } catch {}
  try { await unlink(path.join(ROOT, 'server.pid')) } catch {}
}

if (exitError && !HIDDEN) process.exitCode = 1
