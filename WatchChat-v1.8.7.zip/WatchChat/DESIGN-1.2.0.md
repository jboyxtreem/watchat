# WatchChat v1.2.0 design notes — WhatsApp Frost

## Direction

Keep the familiar WhatsApp visual language, but give the round watch a cooler, restrained depth: translucent rounded list surfaces, a nearly-black blue-green canvas, low-contrast doodle wallpaper, and standard incoming/outgoing chat bubbles with directional tails. No top horizontal band.


## Palette tokens

| Token | Hex | Purpose |
|---|---|---|
| Canvas | `#05090E` | AMOLED background |
| Chat canvas | `#070D12` | Message screen |
| Row surface | `#14202A` at ~86% alpha | Chat/contact/settings rows |
| Unread surface | `#142823` at ~88% alpha | Unread chat rows |
| Pressed surface | `#263A47` | Button pressed state |
| Primary text | `#F2F6F8` | Names and message text |
| Secondary text | `#A4B6C2` | Preview and detail text |
| Muted text | `#738691` | Timestamps and subtle labels |
| WhatsApp accent | `#25D366` | Important actions, unread, active state |
| Incoming bubble | `#1D2B35` at ~90% alpha | Incoming message |
| Outgoing bubble | `#095B4B` at ~91% alpha | Outgoing message |
| Read ticks | `#55BAF1` | Read status |

## Components

- **Chat/contact rows:** full-width 480px image surfaces, rounded capsule shape, subtle outline/top sheen, initials avatar, two-line name/preview, right-aligned time, count in a green badge. Chat rows are 84px, compact 76px; contact rows 88px.
- **Conversation:** full-screen dark doodle wallpaper. Incoming bubble has bottom-left tail; outgoing has bottom-right tail. Rounded corners are softer than pill capsules. Body text and metadata are separated so timestamps/ticks don't overlap the final text line. Message width buckets are 152/232/330px.
- **Composer:** double-layered, softly outlined rounded surface. All controls remain within the lower circular safe zone.
- **Keyboard:** shared theme colours only. Layout, key positions, sizes, hit targets, mode behavior, caps and delete are unchanged.
- **Settings:** translucent rounded list surfaces and a scroll indicator; presets are WhatsApp Frost and WhatsApp Light, plus editable HEX controls.

## Performance and paging

- Initial chats and contacts request up to 100 items, then prefetch 100 more 15 rows before the batch end.
- Scroll-focus loading remains guarded against duplicate requests; the footer remains a manual Load More fallback.
- Scroll indicators are enabled on chat, contact, and settings lists.
- The native `SCROLL_LIST` is updated in place (`UPDATE_DATA`, `on_page: 1`) instead of destroying/recreating it for appended pages.
- Compact-row preference is read once per list data build instead of once per row.
- Unused legacy bubble widths/variants were removed; only 152/232/330 width assets used by the current renderer remain.

