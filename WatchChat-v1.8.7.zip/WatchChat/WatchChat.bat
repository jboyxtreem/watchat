@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "HIDDEN=0"
if /i "%~1"=="--start-hidden" set "HIDDEN=1"
if /i "%~1"=="--start" goto START_BRIDGE
if /i "%~1"=="--start-hidden" goto START_BRIDGE
if /i "%~1"=="--stop" goto STOP_BRIDGE
if /i "%~1"=="--setup" goto SETUP
if /i "%~1"=="--install-watch" goto INSTALL_WATCH
if /i "%~1"=="--doctor" goto DOCTOR

:MENU
cls
title WatchChat
echo.
echo  ==========================================
echo                 WATCHCHAT
echo        WhatsApp via Beeper on Amazfit watches
echo.
echo              Made by Jboyxtreem
echo       Copyright (c) 2026 Jboyxtreem
echo       GitHub: https://github.com/jboyxtreem
echo       Proprietary software - see LICENSE.txt
echo  ==========================================
echo.
echo   1. Set up or repair WatchChat
echo   2. Start WatchChat
echo   3. Install / update the watch app
echo   4. Stop WatchChat
echo   5. Check connection
echo   6. Start WatchChat when Windows starts
echo   7. Disable automatic start
echo   8. Show watch settings ^(Bridge URL and key^)
echo   9. Install tiny connection test app on the watch
echo   0. Exit
echo.
set "CHOICE="
set /p "CHOICE=Choose an option: "
if "%CHOICE%"=="1" goto SETUP
if "%CHOICE%"=="2" goto START_BRIDGE
if "%CHOICE%"=="3" goto INSTALL_WATCH
if "%CHOICE%"=="4" goto STOP_BRIDGE
if "%CHOICE%"=="5" goto DOCTOR
if "%CHOICE%"=="6" goto ENABLE_AUTOSTART
if "%CHOICE%"=="7" goto DISABLE_AUTOSTART
if "%CHOICE%"=="8" goto SHOW_SETTINGS
if "%CHOICE%"=="9" goto INSTALL_TEST
if "%CHOICE%"=="0" exit /b 0
echo.
echo  Please choose one of the options shown.
pause
goto MENU

:SETUP
title WatchChat - setup
echo.
echo  Checking Windows requirements...
where winget >nul 2>&1
if errorlevel 1 (
  echo.
  echo  Windows Package Manager ^(winget^) was not found.
  echo  Install or update App Installer from the Microsoft Store, then run WatchChat.bat again.
  echo  https://aka.ms/getwinget
  pause
  goto MENU
)
set "NODE_ACTION=install"
set "NODE_MAJOR="
where node >nul 2>&1
if errorlevel 1 goto INSTALL_NODE
for /f %%V in ('node -p "Number(process.versions.node.split('.')[0])" 2^>nul') do set "NODE_MAJOR=%%V"
if not defined NODE_MAJOR goto INSTALL_NODE
if %NODE_MAJOR% LSS 22 set "NODE_ACTION=upgrade"
if "%NODE_ACTION%"=="upgrade" goto INSTALL_NODE

if not exist "%~dp0bridge\package-lock.json" (
  echo.
  echo  The bridge package lockfile is missing. Re-extract the WatchChat folder and try again.
  pause
  goto MENU
)

pushd "%~dp0bridge"
echo.
echo  Installing bridge dependencies...
call npm ci --no-audit --no-fund
if errorlevel 1 (
  popd
  echo.
  echo  Dependency installation failed. Check the internet connection and try Setup again.
  pause
  goto MENU
)
echo.
echo  Configuring the secure connection...
node setup.mjs
set "SETUP_CODE=%ERRORLEVEL%"
popd
if "%SETUP_CODE%"=="0" (
  echo.
  echo  Setup is complete.
  pause
  goto MENU
)
if "%SETUP_CODE%"=="2" (
  echo.
  echo  Setup needs one more run after the required program has been installed.
  pause
  goto MENU
)
echo.
echo  Setup did not finish. Review the message above and try again.
pause
goto MENU

:INSTALL_NODE
echo.
if "%NODE_ACTION%"=="upgrade" (
  echo  Updating Node.js to the current LTS release...
  winget upgrade -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
) else (
  echo  Installing the current Node.js LTS release...
  winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
)
if errorlevel 1 (
  echo.
  echo  Node.js could not be installed or updated automatically.
  echo  Install the current LTS version from https://nodejs.org/ and then reopen WatchChat.bat.
  pause
  goto MENU
)
rem Refresh the common Node.js install locations in this window so setup can continue.
if exist "%ProgramFiles%\nodejs\node.exe" set "PATH=%ProgramFiles%\nodejs;%PATH%"
if defined LOCALAPPDATA if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "PATH=%LOCALAPPDATA%\Programs\nodejs;%PATH%"
set "NODE_MAJOR="
for /f %%V in ('node -p "Number(process.versions.node.split('.')[0])" 2^>nul') do set "NODE_MAJOR=%%V"
if not defined NODE_MAJOR goto NODE_RESTART_REQUIRED
if %NODE_MAJOR% LSS 22 goto NODE_RESTART_REQUIRED
echo.
echo  Node.js is ready. Continuing WatchChat setup...
goto SETUP

:NODE_RESTART_REQUIRED
echo.
echo  Node.js was installed or updated, but Windows has not exposed
echo  the new version in this window yet.
echo  Close this window, reopen WatchChat.bat, and choose option 1 again.
pause
goto MENU

:START_BRIDGE
rem WatchChat 1.0.0 has no external bridge npm dependencies. npm ci does not create
rem node_modules for an empty dependency tree, so use real config files to detect setup.
if not exist "%~dp0bridge\.env" (
  if "%HIDDEN%"=="1" exit /b 1
  echo.
  echo  WatchChat has not been set up yet. Choose option 1 first.
  pause
  goto MENU
)
if not exist "%~dp0bridge\ngrok-domain.txt" (
  if "%HIDDEN%"=="1" exit /b 1
  echo.
  echo  WatchChat has not been set up yet. Choose option 1 first.
  pause
  goto MENU
)
where node >nul 2>&1
if errorlevel 1 (
  if "%HIDDEN%"=="1" exit /b 1
  echo  Node.js is not available. Choose Setup / Repair.
  pause
  goto MENU
)
where ngrok >nul 2>&1
if errorlevel 1 (
  if "%HIDDEN%"=="1" exit /b 1
  echo.
  echo  ngrok is not installed. Choose Setup / Repair.
  pause
  goto MENU
)
if not exist "%~dp0bridge\.env" (
  if "%HIDDEN%"=="1" exit /b 1
  echo  The bridge key is missing. Choose Setup / Repair.
  pause
  goto MENU
)
if not exist "%~dp0bridge\ngrok-domain.txt" (
  if "%HIDDEN%"=="1" exit /b 1
  echo  The ngrok domain is missing. Choose Setup / Repair.
  pause
  goto MENU
)

pushd "%~dp0bridge"
set "BRIDGE_ALREADY_RUNNING=0"
rem Distinguish our live bridge from an unrelated process holding port 8080.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; $c=New-Object System.Net.Sockets.TcpClient; try { $c.Connect('127.0.0.1',8080); $c.Close() } catch { exit 0 }; $line=Get-Content -LiteralPath '.env' | Where-Object { $_ -match '^WATCHCHAT_BRIDGE_KEY=' } | Select-Object -First 1; if (-not $line) { exit 20 }; $key=$line.Substring('WATCHCHAT_BRIDGE_KEY='.Length).Trim(); try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:8080/health' -Headers @{ 'X-WatchChat-Key'=$key } -TimeoutSec 3; if ($r.ok -eq $true -and $r.version -eq '1.0.0') { exit 10 } } catch {}; exit 20"
if errorlevel 20 (
  popd
  if "%HIDDEN%"=="1" exit /b 1
  echo.
  echo  Port 8080 is occupied by a different or older bridge process.
  echo  Choose Stop WatchChat first, then choose Start WatchChat again.
  echo  If that does not clear the port, close the older WatchChat window or reboot Windows.
  pause
  goto MENU
)
if errorlevel 10 set "BRIDGE_ALREADY_RUNNING=1"
set "NGROK_DOMAIN="
for /f "usebackq delims=" %%D in ("ngrok-domain.txt") do set "NGROK_DOMAIN=%%D"
if not defined NGROK_DOMAIN (
  popd
  if "%HIDDEN%"=="1" exit /b 1
  echo  The ngrok domain is blank. Choose Setup / Repair.
  pause
  goto MENU
)
if exist stop.flag del /q stop.flag

rem Stop only the ngrok process started by this WatchChat folder.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; if (Test-Path -LiteralPath 'ngrok.pid') { $raw=(Get-Content -Raw -LiteralPath 'ngrok.pid').Trim(); if ($raw -match '^\d+$') { $p=Get-Process -Id ([int]$raw) -ErrorAction SilentlyContinue; if ($p -and $p.ProcessName -eq 'ngrok') { $w=Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $p.Id); if ($w -and $w.CommandLine -like '*ngrok*http*8080*') { Stop-Process -Id $p.Id -Force } } }; Remove-Item -LiteralPath 'ngrok.pid' -Force }" >nul 2>&1

set "RUN_ARGS="
if "%BRIDGE_ALREADY_RUNNING%"=="1" set "RUN_ARGS=--reuse-bridge"
if "%HIDDEN%"=="1" set "RUN_ARGS=%RUN_ARGS% --hidden"
node run.mjs %RUN_ARGS%
set "RUN_CODE=%ERRORLEVEL%"
call :STOP_TUNNEL
popd
if "%HIDDEN%"=="1" exit /b %RUN_CODE%
echo.
if not "%RUN_CODE%"=="0" echo  WatchChat did not start correctly. Choose Check connection for details.
if "%RUN_CODE%"=="0" echo  WatchChat has stopped.
pause
goto MENU

:STOP_BRIDGE
if exist "%~dp0bridge\stop.flag" del /q "%~dp0bridge\stop.flag" >nul 2>&1
>"%~dp0bridge\stop.flag" echo stop
echo.
echo  Stopping WatchChat...
timeout /t 5 /nobreak >nul
pushd "%~dp0bridge"
call :STOP_TUNNEL
popd
echo  WatchChat has been stopped.
pause
goto MENU

:STOP_TUNNEL
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; if (Test-Path -LiteralPath 'ngrok.pid') { $raw=(Get-Content -Raw -LiteralPath 'ngrok.pid').Trim(); if ($raw -match '^\d+$') { $p=Get-Process -Id ([int]$raw) -ErrorAction SilentlyContinue; if ($p -and $p.ProcessName -eq 'ngrok') { $w=Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $p.Id); if ($w -and $w.CommandLine -like '*ngrok*http 8080*') { Stop-Process -Id $p.Id -Force } } }; Remove-Item -LiteralPath 'ngrok.pid' -Force }" >nul 2>&1
exit /b 0

:INSTALL_TEST
set "SRC=%~dp0watch-test"
set "DSTNAME=WatchTestBuild"
set "IDOFFSET=1"
goto INSTALL_WATCH_RUN

:INSTALL_WATCH
set "SRC=%~dp0watch-app"
set "DSTNAME=WatchAppBuild"
set "IDOFFSET=0"

:INSTALL_WATCH_RUN
where node >nul 2>&1
if errorlevel 1 (
  echo.
  echo  Node.js is required. Choose Setup / Repair first.
  pause
  goto MENU
)
set "NODE_MAJOR="
for /f %%V in ('node -p "Number(process.versions.node.split('.')[0])" 2^>nul') do set "NODE_MAJOR=%%V"
if not defined NODE_MAJOR goto WATCH_BUILD_FAILED
if %NODE_MAJOR% LSS 22 (
  echo  Node.js 22 or later is required. Choose Setup / Repair first.
  pause
  goto MENU
)
call :GET_APP_ID
if errorlevel 1 goto WATCH_BUILD_FAILED
set /a WATCHCHAT_APP_ID=%WATCHCHAT_APP_ID%+%IDOFFSET%
set "DST=%LOCALAPPDATA%\WatchChat\%DSTNAME%"
if not exist "%LOCALAPPDATA%\WatchChat" mkdir "%LOCALAPPDATA%\WatchChat"
if exist "%DST%" rmdir /s /q "%DST%"
mkdir "%DST%"
if errorlevel 1 goto WATCH_BUILD_FAILED
xcopy "%SRC%" "%DST%\" /E /I /Y /Q >nul
if errorlevel 1 goto WATCH_BUILD_FAILED
node "%~dp0tools\set-app-id.mjs" "%DST%\app.json" "%WATCHCHAT_APP_ID%"
if errorlevel 1 goto WATCH_BUILD_FAILED
set "PATH=%APPDATA%\npm;%PATH%"
pushd "%DST%"

echo.
echo  Step 1 of 4: npm install
call npm install --no-audit --no-fund
if errorlevel 1 goto WATCH_BUILD_CLEAN_FAIL

echo.
echo  Step 2 of 4: Zepp development tools
where zeus >nul 2>&1
if errorlevel 1 (
  call npm install --global @zeppos/zeus-cli --no-audit --no-fund
  if errorlevel 1 goto WATCH_BUILD_CLEAN_FAIL
)
call zeus -v
if errorlevel 1 goto WATCH_BUILD_CLEAN_FAIL

echo.
echo  Step 3 of 4: zeus login
echo  Sign in with your Zepp account when prompted.
call zeus login
if errorlevel 1 goto WATCH_BUILD_CLEAN_FAIL

echo.
echo  Step 4 of 4: zeus preview
echo  Select your target Amazfit watch. The package includes the listed round and square models.
echo  Then in the Zepp phone app turn on Developer Mode
echo  and scan the QR code. Keep the watch connected and this window open until
echo  the install finishes.
call zeus preview
if errorlevel 1 goto WATCH_BUILD_CLEAN_FAIL

echo.
echo  The watch app preview completed. Open WatchChat on your watch.
popd
pause
goto MENU

:WATCH_BUILD_CLEAN_FAIL
echo.
echo  The watch app installation did not complete. See the error above.
popd
pause
goto MENU

:WATCH_BUILD_FAILED
echo.
echo  The watch app build folder could not be prepared.
echo  Check that Windows has enough free space and that the WatchChat folder is writable.
pause
goto MENU

:GET_APP_ID
rem Preview on your own watch only needs a numeric placeholder ID. Make one once and reuse it.
set "WATCHCHAT_APP_ID="
if exist "%LOCALAPPDATA%\WatchChat\app-id.txt" for /f "usebackq delims=" %%I in ("%LOCALAPPDATA%\WatchChat\app-id.txt") do set "WATCHCHAT_APP_ID=%%I"
powershell -NoProfile -Command "$id=$env:WATCHCHAT_APP_ID; if ($id -match '^[1-9][0-9]{0,9}$' -and [long]$id -le 2147483647) { exit 0 }; $id=Get-Random -Minimum 1000000 -Maximum 9999999; $dir=Join-Path $env:LOCALAPPDATA 'WatchChat'; New-Item -ItemType Directory -Path $dir -Force | Out-Null; Set-Content -LiteralPath (Join-Path $dir 'app-id.txt') -Value $id -NoNewline; exit 0" >nul 2>&1
for /f "usebackq delims=" %%I in ("%LOCALAPPDATA%\WatchChat\app-id.txt") do set "WATCHCHAT_APP_ID=%%I"
if not defined WATCHCHAT_APP_ID exit /b 1
exit /b 0

:SHOW_SETTINGS
where node >nul 2>&1
if errorlevel 1 (
  echo.
  echo  Node.js is not installed. Choose Setup / Repair first.
  pause
  goto MENU
)
pushd "%~dp0bridge"
node show-settings.mjs
popd
echo.
pause
goto MENU

:DOCTOR
where node >nul 2>&1
if errorlevel 1 (
  echo.
  echo  Node.js is not installed. Choose Setup / Repair first.
  pause
  goto MENU
)
pushd "%~dp0bridge"
node doctor.mjs
popd
pause
goto MENU

:ENABLE_AUTOSTART
if not exist "%~dp0bridge\.env" (
  echo  Complete Setup / Repair before enabling automatic start.
  pause
  goto MENU
)
if not exist "%~dp0bridge\ngrok-domain.txt" (
  echo  Complete Setup / Repair before enabling automatic start.
  pause
  goto MENU
)
set "WATCHCHAT_FOLDER=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $startup=[Environment]::GetFolderPath('Startup'); $shell=New-Object -ComObject WScript.Shell; $link=$shell.CreateShortcut((Join-Path $startup 'WatchChat.lnk')); $link.TargetPath=Join-Path $env:WATCHCHAT_FOLDER 'start-hidden.vbs'; $link.WorkingDirectory=$env:WATCHCHAT_FOLDER; $link.Save()"
if errorlevel 1 (
  echo  Windows could not create the startup shortcut.
  pause
  goto MENU
)
echo.
echo  Automatic start is enabled. WatchChat will start when you sign in to Windows.
echo  Use option 7 to disable it.
pause
goto MENU

:DISABLE_AUTOSTART
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path ([Environment]::GetFolderPath('Startup')) 'WatchChat.lnk'; Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue"
echo.
echo  Automatic start has been disabled.
pause
goto MENU
