# WatchChat v1.7.0 design notes: Indigo

Built from on-watch photos supplied by the owner: solid indigo/teal tiles, indigo-vs-teal bubbles, centred time stamps and a big blue Reply button on a deep navy background.

Assets come from tools/generate-glass-assets.py (pass watch-app/assets as the first argument).

# Attribution preservation

WatchChat is made by **Jboyxtreem**. Preserve the credit "Originally made by Jboyxtreem" and the GitHub link (https://github.com/jboyxtreem) in any redistribution.
