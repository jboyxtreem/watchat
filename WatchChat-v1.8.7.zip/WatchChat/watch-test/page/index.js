import { BasePage } from '@zeppos/zml/base-page'
import * as hmUI from '@zos/ui'
import { px } from '@zos/utils'

Page(
  BasePage({
    build() {
      const label = hmUI.createWidget(hmUI.widget.TEXT, {
        x: px(40), y: px(94), w: px(400), h: px(230),
        text: 'This checks only watch ↔ phone messaging. It does NOT test ngrok or the PC bridge.',
        text_size: px(27), color: 0xffffff,
        align_h: hmUI.align.CENTER_H, text_style: hmUI.text_style.WRAP
      })
      hmUI.createWidget(hmUI.widget.BUTTON, {
        x: px(90), y: px(344), w: px(300), h: px(76), radius: px(38),
        normal_color: 0x1f8f4a, press_color: 0x146c37,
        text: 'TEST WATCH ↔ PHONE', text_size: px(26),
        click_func: () => {
          label.setProperty(hmUI.prop.TEXT, 'Testing the watch ↔ phone link...')
          this.request({ method: 'PING', params: {} })
            .then((r) => label.setProperty(hmUI.prop.TEXT, r && r.error ? 'WATCH ↔ PHONE FAILED: ' + r.error : 'WATCH ↔ PHONE OK: ' + JSON.stringify(r) + '\n\nThe main WatchChat app separately tests ngrok and your PC bridge.'))
            .catch((e) => label.setProperty(hmUI.prop.TEXT, 'WATCH ↔ PHONE FAILED: ' + String(e && e.message ? e.message : e)))
        }
      })
    }
  })
)
