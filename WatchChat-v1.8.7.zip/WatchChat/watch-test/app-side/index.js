import { BaseSideService } from '@zeppos/zml/base-side'

AppSideService(BaseSideService({
  onInit() {},
  onRequest(req, res) {
    if (req.method === 'PING') res(null, { pong: true })
    else res('unknown request')
  },
  onRun() {},
  onDestroy() {}
}))
