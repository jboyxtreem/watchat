# WatchChat v1.5.0 design notes: Tinted Glass

Near-black canvas. Rows are translucent tiles tinted per contact hue; the avatar is the colour anchor. Bubbles use curved tails: solid green outgoing, blue-grey glass incoming.

Assets come from tools/generate-glass-assets.py (pass the watch-app/assets folder as the first argument).

# Attribution preservation

WatchChat is made by **Jboyxtreem**. Preserve the credit "Originally made by Jboyxtreem" and the GitHub link (https://github.com/jboyxtreem) in any redistribution.
