## 1.8.7 — Keyboard preview and collapsing chat header

- Keyflow horizontal input preview now keeps the newest characters visible without a leading ellipsis taking up viewport space.
- Added a Wrap text mode for the Keyflow preview; the message itself is preserved and sent in full.
- Added Settings controls for Horizontal scroll / Wrap text.
- Added configurable chat-header collapse: the entire header area (title and status banner contents) hides after user scrolls down and reappears near the top.
- Rebuilt the chat header as one parent container containing its background surface, contact title and status text. The complete container is omitted on collapse rather than hiding only individual text widgets.
- When the header collapses, the message viewport moves to y=0 and expands to use the full space above the composer; when it returns, the viewport restores its normal position and height.
- The banner collapses after any real scroll away from the top (including when the chat initially opens at the latest message); it restores only when scrolling back toward the top, avoiding an immediate reappearance from programmatic viewport resets.
- Default input mode: Horizontal scroll. Default header collapse: On.
- Corrected 1.8.7 package build code to 24 so Zepp can recognise this fixed rebuild as newer than the initial 1.8.7 package (build code 23).
- Physical watch rendering and scrolling require on-device verification.

## 1.8.6: Chat scroll fix, composer spacing and message reactions

- Corrected the conversation viewport offset direction so opening a chat starts at the latest messages instead of jumping into blank space.
- Raised the idle message composer slightly so it is not clipped/too close to the bottom edge.
- Added reaction chips below messages, including grouped counts and a subtle highlight when the watch account is among the reactors.
- Refreshes the conversation when reaction counts or reaction ownership change, even if the message list itself did not grow.
- Added regression checks for scroll offset direction, composer placement, and reaction display/update handling.
- Physical-watch rendering and scrolling still require device verification.

## 1.8.5: Inline composer, fixed Keyflow, independent chat scrolling

- Replaced the Reply button with a message-entry field at the bottom of the conversation.
- Moved the message history into a dedicated Zepp `VIEW_CONTAINER`; while composing, the contact name/header collapses and the message area remains independently scrollable above a fixed keyboard.
- Keyflow sits slightly lower, uses less-rounded keycaps, and now uses the same dark/green palette as the chat bubbles and list rows.
- Added working notification controls to Settings: on/off plus 10, 15, 20 or 30 second phone-side Beeper polling. The default is enabled at 10 seconds.
- Kept the watch's 60-second background queue check as a lower-power fallback when WatchChat is not open; live alerts are forwarded as soon as the phone-side service detects them while the watch app is connected.
- Updated navigation and notification tests. Physical-watch rendering and Beeper/phone notification timing still need on-device verification.

## 1.8.4: Tails, Reply, notifications, settings, contacts

- Bubble tails: replaced the stepped wedge with one squared corner on the last bubble of each run.
- Reply: the keyboard now scrolls the chat to the top and locks scrolling first, so it opens on screen.
- Notifications: new background app-service (alarm every 60 s) asks the phone for queued messages and posts watch notifications while the app is closed. Opens WatchChat once to arm it.
- Settings restyled to match the chat list. Contacts use wider native rows (no PNG surfaces).
- Efficiency: chat polling pauses when the page is hidden, 80-message cap, fewer widgets per bubble, removed page notification timers.
- Not compiled or tested on a watch here; tools/test-watch-navigation and test-keyflow-notifications still assert the old layout.

## 1.3.0 — Fixed Keyflow, swipe settings and message notifications

- Replaces Keyflow's hidden 1×1 widgets and runtime `MORE` repositioning with native buttons created once at fixed final coordinates. Layout changes update only labels and visibility; each key keeps its original click callback and hitbox.
- Fixes the inert Chats and Contacts lists: every visible chat/contact hit area and the Load More/Refresh targets are now explicitly marked `action: true`, as required by Zepp SCROLL_LIST.
- Removes the People, Search and Settings shortcuts from the Chats header while retaining the existing Chats and Contacts list presentation.
- Opens the streamlined Settings page with a left swipe from the Chats screen. Settings now contains only Keyflow and System keyboard choices.
- Adds phone-side polling of the protected PC bridge every 20 seconds, a bounded notification queue, live Side Service delivery when the watch page is connected, and pending-queue retrieval from WatchChat pages.
- Adds Zepp OS system notifications and the `device:os.notification` permission. Queue items are acknowledged only after the notification is accepted; failed notifications remain available for retry.
- Keeps the existing WhatsApp-style directional bubble tails and list layouts.
- Notification delivery depends on Beeper, the PC bridge/tunnel, Zepp Side Service lifecycle and phone/watch connectivity. Delivery while WatchChat is closed is not guaranteed by this version.
- Zepp CLI compilation and physical-watch verification remain outstanding in this environment.

## 1.2.0 — Frosted WhatsApp and bubble-tail redesign

- Replaces flat dark rows with cool, semi-transparent rounded surfaces and subtle outlines.
- Removes the separate top-band treatment; headers float within round-safe areas.
- Contact/chat/settings rows use transparent PNG surface overlays for depth without heavy glass blur.
- Message bubbles now have WhatsApp-style directional tails, softer corners, translucent slate/teal fills and separated metadata.
- Keyboard colours follow the new theme; key positions, sizes, hit areas and behaviour are unchanged.
- Chat and contact initial batches increased to 100, with prefetch 15 rows before the end, native scroll indicators, and a visible Load More fallback.
- Reduced per-row preference reads and generated only the message bubble widths used by the current renderer.
- Bridge behavior is unchanged from 1.1.0.

## 1.1.0 — Round-screen performance and WhatsApp dark UI

- Switched the default appearance to a solid, high-contrast WhatsApp-inspired dark palette with pill-shaped chat/contact rows and chat bubbles.
- Matched Keyflow keyboard colours to the selected app theme without moving keys or changing typing behaviour.
- Reworked chats and contacts to fetch 50-item pages, prefetch ten rows before the end, and update native SCROLL_LIST data in place with `on_page: 1` to preserve scroll position.
- Added shared, tested pagination/deduplication helpers for chat and contact batches.
- Cached message list item configurations and reused the active theme across each message batch.
- Added missing 152/232/330px light and dark message bubble assets to each Balance 2 asset pack.
- Retained Beeper bridge routes and existing message/reaction functionality.
- Zepp CLI compilation and physical-watch verification remain outstanding in this environment.

# Changelog

## 1.8.2: Restored working inbox navigation

- Bumped the Zepp app manifest to version 1.2.1 (version code 17) for a clean app update.

- Restored visible PEOPLE, SEARCH and SETTINGS controls on the Chats screen.
- Controls are action-enabled SCROLL_LIST views, so taps are handled by the same native list that owns the inbox instead of by floating widgets layered over it.
- PEOPLE opens Contacts, SEARCH opens Contacts and automatically presents the search keyboard, and SETTINGS opens Settings.
- Fixed the dormant search-on-entry flag so the keyboard opens after the initial contacts request completes (including when that request returns an error).
- Updated asset/navigation checks to match the 1.8.x lazy-loaded inbox rather than the older 1.2.0 batch layout.

## 1.8.1: Lazy-loaded chat list

- Chat list loads 8 chats first, then fetches the next 8 automatically as you scroll near the bottom (with a tappable "Load more" footer as a fallback). Refreshing re-fetches only what is already loaded, so the list never collapses or jumps.
- Chats are cached for 30 seconds: coming back from a conversation redraws instantly instead of re-syncing every time.
- Opening a chat marks it read locally and (via `read=1`) on the bridge.
- Fixed chat times: this bridge returns `ts`/`lastActivity` instead of the field the old UI expected.
- Everything else in `page/index.js` and `page/chat.js` is the smooth-ui original.

## 1.8.0: Restored smooth-ui

- `page/index.js` and `page/chat.js` are now byte-for-byte the files from `WatchChat-smooth-ui.zip` (the UI the owner wanted back): smooth native list, rounded chat tiles, "N chats" subtitle, day separators, rounded bubbles and the large blue Reply button.
- Uses the same app-side requests (LIST_CHATS, GET_MESSAGES, LOAD_OLDER, SEND_MESSAGE) as this project's bridge, so no app-side changes were needed.
- That chat list has no buttons for Contacts, Settings or Search, so those pages are still in the project but cannot be opened from the list.
- Not compiled or tested on a watch in the authoring environment.

## 1.7.0: Indigo (matches the on-watch reference photos)

- Chat list: plain "WatchChat" title, a "N chats" / "Unread" tab pair, and big solid tiles with no avatars. Read chats are indigo, unread chats are teal with an aqua dot and count.
- Conversation: indigo incoming and teal outgoing bubbles (curved tails kept), centred timestamps between messages ("Today 12:37", "17:48") instead of times inside bubbles, and one large blue Reply button.
- Contacts: same solid indigo tiles, full-screen list.
- New default theme **Indigo**; older Midnight/Glass saved themes migrate automatically. Keyboard layout unchanged (colours only).
- Read ticks and in-bubble times were removed to match the reference. Group sender names now prefix the message text.
- Not compiled or tested on a watch in the authoring environment.

## 1.6.1: Midnight depth pass

- Added neutral depth to the flat design: soft vertical gradients on cards, bubbles, avatars and the composer, plus a fine top-edge highlight. No tint, glass or glow.
- Layout, tails and behaviour unchanged.

## 1.6.0: Midnight

- All glass, tint and glow removed. New flat design on pure black: tonal rounded cards, solid-colour avatars, WhatsApp green as the single accent.
- Message bubbles keep curved tails: green outgoing, dark grey incoming, both flat.
- Cleaner chrome: centred titles, solid green active tab, flat circular buttons, flat composer pill.
- Contacts keep the full-screen list. Keyboard layout unchanged (colours only).
- Default theme renamed **Midnight**; older Glass/Frost saved themes migrate automatically. WhatsApp Light unchanged.
- Not compiled or tested on a watch in the authoring environment.

## 1.5.0: Tinted Glass

- Rows are now colour-tinted glass tiles: each contact gets a hue (matching their avatar) that glows from the left of the row and fades to clear glass. Unread chats glow green.
- Message bubbles bring back tails, redrawn as smooth curved tails. Outgoing is vivid green, incoming is blue-grey glass.
- Cleaner chrome: centred titles, no decorative dots, solid green active tab (All / Unread), sentence-case labels, bigger names.
- Settings rows, composer and avatars restyled to match. Keyboard layout unchanged (colours only).
- Not compiled or tested on a watch in the authoring environment.

## 1.4.0: Glass Noir

- Redesign of the 1.3 glass look into something quieter and more modern: near-black canvas with a faint cool glow at the screen edges, thin hairline glass rows (no milky fills, no heavy outlines), vivid gradient avatars.
- Bubbles are tail-free rounded glass. Yours are solid, vivid green; incoming are blue-grey translucent glass.
- Symmetric bubble padding; timestamps and ticks sit clear of the text.
- Default theme renamed **Glass Noir**; older Liquid Glass / Frost saved themes migrate automatically. WhatsApp Light is unchanged.
- Keyboard layout and behaviour unchanged (colours only). Contacts keep the full-screen list.
- Not compiled or tested on a watch in the authoring environment.

## 1.3.0 — Liquid Glass

- New default theme, **Liquid Glass**: translucent rows, bubbles and composer baked as PNG glass (bright top rim, soft inner light) over a colour-glow backdrop. Zepp OS has no live blur, so the glass is rendered into the assets.
- Message bubbles: outgoing are green-tinted glass, incoming are blue-grey glass; both keep WhatsApp-style tails and separated timestamps.
- Contacts list now uses the whole round screen: the list starts at the top edge, rows are 76px, and the header floats over it with a fade.
- Chat, contact and settings pages share one backdrop image so glass rows sit seamlessly with no flat bands.
- Keyboard layout, key positions, sizes and behaviour are unchanged; it only picks up the new theme colours.
- Old 'WhatsApp Frost' saved themes migrate to Liquid Glass. WhatsApp Light is unchanged.
- Zepp CLI build and on-watch testing were not possible in this environment.

## 1.0.0 — WhatsApp-style chats, contacts and conversations

- Replace the rejected FORM/Pulse Green visual direction with a familiar WhatsApp-inspired light interface: classic green header, white lists, subtle separators, initials avatars, timestamps and unread badges.
- Add a dedicated Select contact screen backed by Beeper's WhatsApp contact directory, cursor pagination and contact search.
- Add direct-chat creation from a selected WhatsApp contact through Beeper's `/v1/chats/start` endpoint. This endpoint requires Beeper Desktop v4.2.808 or later.
- Restyle conversations with a warm, subtle WhatsApp-style wallpaper, pill-shaped white incoming bubbles, pale-green outgoing bubbles, delivery/read ticks and a familiar bottom composer.
- Add warm chat wallpaper image assets for light and dark modes across the included round, square and base asset directories.
- Keep WhatsApp Light as the default with WhatsApp Dark as an alternative; update the Settings editor for the actual list background, conversation wallpaper, text and accent colours.
- Retain first-100 chat loading, incremental prefetch, message reactions and the existing Beeper bridge.
- **Do not modify the keyboard.** `watch-app/lib/keyboard.js` is byte-for-byte identical to v0.9.0; no key positions, hit areas, colours or behaviour were changed.

### Validation

- JavaScript syntax and JSON manifest/lockfile checks passed.
- Local mocked-Beeper integration tests cover account detection, contact pagination, contact search and starting a direct chat.
- All generated avatar, wallpaper and bubble assets were checked for readability and required names in all three asset directories.
- Four circular 480 × 480 preview screens were rendered and visually inspected.
- Keyboard source SHA-256 matches v0.9.0 exactly.
- Zepp CLI compilation, live Beeper/ngrok and physical-watch interaction were not available in this environment; see `RELEASE-AUDIT-1.0.0.txt`.

---

## 0.9.0 — FORM interface redesign

- Replace the card-and-pill visual language with a complete editorial-style messaging UI:
  ink-black canvas, clear title hierarchy, muted graphite surfaces, hairline separators and
  a single vivid green accent (`#A7EF58`).
- Redesign the inbox header, ALL/UNREAD navigation, contact rows, avatars, unread states,
  message previews and lower-screen scrolling layout for the circular 480 × 480 display.
- Redesign the conversation header, wider message bubbles, quick replies, message actions,
  full-message view and reaction picker without changing the bridge or reaction API flow.
- Rebuild Settings as a clean, sectioned preference list with FORM, MOSS and CHROME presets,
  editable accent/background/surface/text colours, compact-row preference and keyboard mode.
- Create new round-screen avatar and message-bubble assets for all target asset folders.
- Separate the application palette from the keyboard palette so changing an app theme does
  not alter Keyflow. `watch-app/lib/keyboard.js` is byte-for-byte unchanged from v0.8.0.
- Keep 100-chat initial loading, automatic pagination, manual fallback, Beeper bridge and
  reaction behaviour unchanged.

### Validation

- JavaScript syntax checks and JSON manifest/lockfile parsing passed.
- Asset audit passed for all avatar initials/unread variants, dividers, message bubbles and
  status indicators across the included watch targets.
- Circular-screen design previews were rendered and visually reviewed at 480 × 480.
- The keyboard source hash matches v0.8.0 exactly.
- Zepp CLI compilation, live Beeper/ngrok and physical-watch interaction were not available
  in this environment; see `RELEASE-AUDIT-0.9.0.txt`.

---

## 0.8.0 — Pulse Green visual identity

- Replace the slate-blue default appearance with Pulse Green: a deep green-black
  canvas, restrained forest surfaces and a vivid lime accent (`#B7F34A`).
- Refresh the contacts header and filter controls for the round 480 × 480 display;
  align the top controls to the circular safe area and add compact initial avatars.
- Refine contact-row density and contrast while retaining full-width scrolling,
  100-chat batches, automatic prefetch and the manual Load Next 100 fallback.
- Restyle the conversation header, quick/reply actions, message actions, reaction
  picker and settings screen to use the same minimal green visual system.
- Recolour the Emerald bubble artwork to match Pulse Green and use dark, legible
  text inside the bright outgoing bubble.
- Add Pulse Green and Deep Forest presets, migrate untouched 0.7.0 default/Emerald
  preferences to Pulse Green, and expose the outgoing-bubble text colour in Settings.
- Refresh the app icon to match the new visual identity.
- **Leave the keyboard unchanged.** `watch-app/lib/keyboard.js` is byte-for-byte
  identical to the 0.7.0 source; its key layout, touch zones and behaviour were not edited.

### Validation

- JavaScript syntax checks passed for the bridge, watch app, watch test app and tools.
- JSON parsing passed for the watch app, bridge and test manifests/lockfiles.
- All 48 Emerald/Pulse bubble assets across the base, round and square asset folders
  were regenerated and checked for PNG readability, RGBA format and expected dimensions.
- Six circular 480 × 480 design previews were rendered and visually inspected.
- Keyboard source SHA-256 remained `ffb8f41c59701ece3a45bd6b6f219c4b1d99cb8ae804a0e3d8b8e8d6a7fd545c`.
- Zepp CLI compilation, live Beeper/ngrok and physical-watch tests were not available
  in this environment; see `RELEASE-AUDIT-0.8.0.txt`.

## 0.7.0 — full round-screen redesign, chat loading and reactions

- Replace the eight-chat default at the Zepp Side Service boundary with a first-page
  request of 100 chats; align the Windows bridge page limit to 100. Beeper itself is
  cursor-paginated in batches of up to 200 and the bridge caches pages, returning 100
  at a time to the watch.
- Add near-end automatic prefetch and keep a visible `LOAD NEXT 100` action as a fallback
  for watch firmware that does not reliably emit list focus events. Deduplicate every batch
  and stop rather than looping on an empty or duplicate-only page.
- Expand the home SCROLL_LIST to the full 480 px width and the full lower display area;
  add ALL/UNREAD filters, empty-unread state and a first-class settings entry.
- Preserve the previous contact-list state when returning from a chat or settings, and
  refresh the home palette when appearance or compact-row settings change.
- Rework chat, message-action and keyboard geometry for the round-screen safe area.
  Reposition the lower reply controls, enlarge the SPACE target and move DELETE alongside
  the third keyboard row.
- Add an on-watch Settings screen with six preset themes, 12 editable interface colour
  values, keyboard choice, compact-row toggle and reset. Preset-specific bubble assets
  keep message bubbles coordinated with the selected theme.
- Add reaction add/remove and single-message refresh through Beeper's documented Desktop
  API. Display grouped reaction keys/counts and expose removal only for reactions whose
  participant ID matches the connected Beeper account identity.
- Update package/app versions to 0.7.0 and add design previews and a release audit.

### Validation

- JavaScript syntax checks passed for the bridge, main watch app and included watch test app.
- Mock Beeper integration passed for authentication rejection, connected health, 237 chats
  returned over 100/100/37 pages, message retrieval, reaction add, reaction refresh and
  reaction removal.
- Asset audit passed for all six bubble palettes in all three target asset directories.
- UI previews were rendered at 480 × 480 and visually inspected.
- Zepp compiler/preview, live Beeper Desktop, ngrok and physical-watch interaction were
  not run in this environment; those still require the target Windows PC and watch.

## 0.6.2 — bridge authentication consistency

- Make `bridge/.env` authoritative when the relay starts, so inherited Windows
  environment variables cannot silently override the saved bridge key or port.
- Make the launcher use the same saved-port precedence as the relay.
- Improve HTTP 401 diagnostics: distinguish a mismatched live process from a missing
  setup, and stop recommending Setup / Repair or key regeneration for this case.
- No watch-side code changes; the watch app remains version 0.6.1.

## 0.6.1 — startup verification and round-screen layout

- Start the local Node bridge before launching ngrok.
- Verify the local `/health` endpoint and the public ngrok `/health` URL before reporting WatchChat ready (fixes the previous root-path probe returning 404).
- Keep visible ngrok startup diagnostics; detect tunnel failures instead of treating a running process as proof of connectivity. Show the local Traffic Inspector URL and distinguish the PC startup probe from watch-originated requests.
- Reflow the chat list, chat page, buttons and Keyflow bottom row to fit the circular Balance 2 display; check all primary controls against the 480 × 480 circular safe area.
- Improve Zepp Side Service error messages and log the public bridge target for debugging.

## 0.6.0 — Beeper Desktop backend

- Replaced the direct Baileys WhatsApp connection with Beeper Desktop API.
- The bridge now uses Beeper's local API for WhatsApp account discovery, chat listing,
  message history, polling for new messages, read receipts and text sending.
- Added cursor-to-offset pagination so the existing watch app can request more chats
  and older messages without needing a new watch-side API.
- Added private Beeper API token setup and diagnostics. The token remains in
  `bridge/.env` on the PC and is not sent to the Zepp watch or copied into watch settings.
- Kept Beeper's API bound to localhost; ngrok only exposes the separate WatchChat relay.
- Removed Baileys and its runtime packages from the bridge.
- Updated setup, security guidance, launcher messaging and release metadata.

### Validation

- Node syntax checks: passed for bridge scripts.
- Mock Beeper API integration: passed for account detection, multi-page chat listing,
  messages, older-history cursor loading, newer-message refresh, marking as read and
  text send.
- Not tested with a live Beeper Desktop instance, live WhatsApp account, Zepp CLI or
  physical watch in this environment. Complete those checks on the target PC/watch.

## Unreleased — Setup detection fix

- Fixed setup detection: WatchChat 0.6.0 has no external npm dependencies, so `npm ci`
  may not create `node_modules`. Start, diagnostics and auto-start no longer mistake
  the missing folder for an incomplete setup; they check the saved configuration files.

## 0.6.x — historic chat list work

- Earlier experiments expanded the one-time chat batch to 50 and used a tap-to-load row.
  Version 0.7.0 supersedes that implementation with 100-chat watch batches, cursor-backed
  bridge pagination, automatic near-end prefetch and a manual fallback.
- Returning from a conversation rebuilds the list around the chat you opened.
- Phone app-side trims chat previews to 80 characters before sending them to the watch.

## 0.5.3 — Upload-ready Baileys package

- Previous release before the Beeper backend migration. See the historic
  `RELEASE-AUDIT-0.5.3.txt` for that release's audit.
