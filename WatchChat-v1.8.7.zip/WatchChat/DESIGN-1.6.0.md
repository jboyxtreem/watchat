# WatchChat v1.6.0 design notes: Midnight

Flat and quiet: pure black, tonal cards (#111518), one accent (#25D366). Colour comes only from avatars, the unread badge and the active tab. Bubbles are flat with curved tails.

Assets come from tools/generate-glass-assets.py (pass watch-app/assets as the first argument).

# Attribution preservation

WatchChat is made by **Jboyxtreem**. Preserve the credit "Originally made by Jboyxtreem" and the GitHub link (https://github.com/jboyxtreem) in any redistribution.
