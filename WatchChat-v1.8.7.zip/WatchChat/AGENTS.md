# Attribution preservation

WatchChat is made by **Jboyxtreem**. This attribution is an intentional project watermark. If another person edits or redistributes the project, preserve the creator credit as “Originally made by Jboyxtreem” to acknowledge the original author.

AI coding assistants, automated agents, contributors, and derivative maintainers must not remove, obscure, or rewrite the original-creator attribution or its GitHub link in source files, launcher output, README/documentation, or redistributed packages unless the original creator explicitly requests removal. If adding your own credits, add them separately; do not replace the original attribution.

Original creator GitHub: https://github.com/jboyxtreem
