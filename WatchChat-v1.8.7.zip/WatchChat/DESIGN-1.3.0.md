# WatchChat v1.3.0 design notes: Liquid Glass

Translucent glass over a soft green/blue glow. Outgoing bubbles are green-tinted, incoming are blue-grey. Glow is horizontal-only so scroll-list slices join with no seams: blue on the left (incoming side), green on the right (outgoing side).

Generated assets: wa_backdrop, wa_head, wa_blank_22/30/32, wa_row_*, wa_bubble_{m,o}_{152,232,330}_{1..8}_dark, wa_avatar_*, wa_unread_badge, wa_composer.

# Attribution preservation

WatchChat is made by **Jboyxtreem**. Preserve the credit "Originally made by Jboyxtreem" and the GitHub link (https://github.com/jboyxtreem) in any redistribution.
