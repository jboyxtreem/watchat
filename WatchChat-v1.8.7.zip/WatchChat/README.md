# WatchChat 1.8.7 — Beeper Update

WatchChat brings WhatsApp text messaging to supported Amazfit watches. It uses Beeper Desktop on your Windows PC, a small WatchChat bridge, and the Zepp phone app to relay messages between the watch and PC.

This is a pretty big update to WatchChat. The PC bridge has moved from WAHA to Beeper, and I've also made improvements to the watch UI, especially when chatting and typing longer messages.

## What's changed

- Switched the backend from WAHA to Beeper.
- Improved the message input so longer messages are easier to see while typing.
- Added horizontal scrolling and text wrapping options for the input.
- Improved chat scrolling and made the entire chat header/banner collapse while scrolling to give messages more room.
- Added settings to control the new input and header behaviour.
- Improved the UI and setup flow.
- Added a licence and copyright notice.

## What you need

- Windows 10 or 11 PC with internet access
- Beeper Desktop for Windows
- WhatsApp or WhatsApp Business linked in Beeper
- iPhone or Android phone with WhatsApp and Zepp, paired to your watch
- A free ngrok account and development domain
- Zepp developer account / Developer Mode
- Node.js 22 or later (setup can install it if needed)

## Quick setup

1. Download and extract the ZIP to a regular folder on your PC. Do not run it from inside the ZIP. It should contain two items side by side: `watchat.bat` and the `WatchChat` folder.
2. Install Beeper Desktop for Windows from [Beeper's download page](https://www.beeper.com/download/windows), then open it.
   **After step 2, you may need to open `watchat.bat` again in a new window. If you do, leave the previous launcher window open—do not close it.**
3. In Beeper, add WhatsApp (`Accounts → Add an Account → WhatsApp`) and link it by scanning the QR code with WhatsApp on your phone (`Settings → Linked devices → Link a device`).
4. In Beeper Desktop, open `Settings → Integrations`. Ensure the Desktop API is enabled and running, then create an approved connection token for WatchChat. Keep this token private.
5. Open the outer `watchat.bat` launcher and select **Set up or repair WatchChat**. Follow the ngrok prompts and enter the Beeper Desktop API token when asked. Setup saves credentials locally in `WatchChat/bridge/.env`.
6. In the launcher, choose **Install / update the watch app** and follow the Zepp developer preview prompts.
7. Copy the Bridge URL and Bridge key from `WATCH-SETTINGS.txt` into WatchChat's settings in the Zepp phone app. Keep this file private.
8. Choose **Start WatchChat** in the launcher. Wait for the local bridge check and public tunnel check to pass. Leave Beeper Desktop open with WhatsApp connected.
9. Open WatchChat on the watch. Use the swipe gesture shown in the setup guide to access Settings and choose your keyboard. Check the PC connection window if troubleshooting is needed.

For detailed setup, update steps, launcher options and troubleshooting, see `READ ME FIRST.txt`. For privacy/security tips, see `SECURITY.md`.


## Updating

Back up your current WatchChat folder first. Stop the existing bridge, then extract the new package and replace the old `WatchChat` folder and outer `watchat.bat`. Keep your existing `bridge/.env`, `bridge/ngrok-domain.txt` and `WATCH-SETTINGS.txt`—they contain your personal connection settings. After replacing files, run the launcher, install/update the watch app, and start the bridge again.


## Launcher options

The launcher provides setup/repair, start, watch app install/update, stop, connection check, autostart enable/disable, watch settings, and a small connection-test app.


## Supported watch families

The package includes targets for the following families (availability and firmware features vary; not all models have been physically tested):

- Amazfit Balance 2, Balance 3, Balance Ultra
- Amazfit Active Max, Active 2 (round and square), Active 3 Premium
- Amazfit Bip 6, Bip Max
- Amazfit T-Rex 3 Pro (44 mm and 48 mm), T-Rex Ultra 2
- Amazfit Cheetah 2 Pro, Cheetah 2 Ultra

WatchChat targets Zepp OS API level 4.2 or later.

## Limitations

- Text messaging only; media messages are shown as labels. Media viewing/sending and voice calls are not implemented.
- Beeper is a third-party messaging client and WhatsApp connection support may change.
- Connection and notification reliability depend on Beeper, ngrok, Zepp and the phone/watch connection.

## Security and privacy

Do not share `WATCH-SETTINGS.txt` or `bridge/.env`. They contain private connection credentials. Each user should run their own setup and use their own Beeper token, tunnel and bridge key. Beeper's Desktop API should remain local; do not enable Beeper Remote Access for WatchChat. Review `SECURITY.md` before sharing logs.


## License and attribution

WatchChat includes a proprietary licence in `LICENSE.txt`. Third-party components remain under their own licences.


**Made by Jboyxtreem** — [GitHub](https://github.com/jboyxtreem)
