@echo off
setlocal
cd /d "%~dp0WatchChat"
call WatchChat.bat
